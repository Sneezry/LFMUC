local _, LFA = ...

LFA.DB.Rules.DispelPoison = {
  spells = LFA.DB.Spells.dispelp,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {
    -- 黑心林地
    "梦魇毒素",
    -- 永茂林地
    "剧毒之爪"
  },
  targetofspell = {}
}