local _, LFG = ...

local function GetAllFilteredUnits(filter)
  if filter.property == "count" then
    local filterUnitCount = #LFG.filteredUnits
    LFG.filteredUnits = LFG.GetAvailableUnits()

    if filter.operator == "=" and filterUnitCount == filter.value
        or filter.operator == "~" and filterUnitCount ~= filter.value
        or filter.operator == "<" and filterUnitCount < filter.value
        or filter.operator == ">" and filterUnitCount > filter.value then
      return true
    end
    
    return nil
  end

  LFG.filteredUnits = LFG.GetFilteredItem(LFG.filteredUnits, filter)
  return LFG.filteredUnits
end

LFG.RegisterGeneralFilterHandler("units", GetAllFilteredUnits)