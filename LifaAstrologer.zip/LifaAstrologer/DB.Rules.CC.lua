local _, LFA = ...

LFA.DB.Rules.CC = {
  spells = LFA.DB.Spells.cc,
  win = ccwin,
  name = {},
  casting = {
    -- 永恒黎明陨落(上)
    "弱化",
    -- 黑鸭堡垒
    "渡鸦的俯冲",
    -- 维克雷斯庄园
    "拔根而起", "死亡棱镜"
  },
  buff = {},
  debuff = {},
  targetofspell = {}
}