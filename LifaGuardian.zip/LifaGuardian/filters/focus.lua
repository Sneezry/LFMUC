local _, LFG = ...

local function GetFilteredFocus(filter)
  return LFG.GetFilteredUnit("focus", filter)
end

LFG.RegisterGeneralFilterHandler("focus", GetFilteredFocus)