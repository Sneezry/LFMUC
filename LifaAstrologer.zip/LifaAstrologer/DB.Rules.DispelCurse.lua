local _, LFA = ...

LFA.DB.Rules.DispelCurse = {
  spells = LFA.DB.Spells.dispelc,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {
    -- 奈萨鲁斯
    "巨龙宝藏诅咒",
    -- 奥达曼
    "羁石诅咒"
  }
}