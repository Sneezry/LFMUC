local _, LFG = ...

local function GetFilteredAffix(filter)
  C_MythicPlus.RequestMapInfo()

  local affixes = C_MythicPlus.GetCurrentAffixes()
  local items = {}

  for _, affix in ipairs(affixes) do
    local name = C_ChallengeMode.GetAffixInfo(affix.id)
    table.insert(items, {id = affix.id, name = name})
  end

  local filteredAffix = LFG.GetFilteredItem(items, filter, true)
  if #filteredAffix == 0 then
    return nil
  else
    return filteredAffix[1]
  end
end

LFG.RegisterGeneralFilterHandler("affix", GetFilteredAffix)
LFG.RegisterGeneralFilterHandler("cizhui", GetFilteredAffix)