local _, LFG = ...

local function GetFilteredTotem(filter)
  local totems, i, now = { }, 1, GetTime()
  local _, totem, start, duration = GetTotemInfo(i)
  
  while totem and totem ~= "" do
    totems[totem] = floor(start + duration - now)
    i = i + 1
    _, totem, start, duration = GetTotemInfo(i)
  end

  local filteredTotems = LFG.GetFilteredItem({ totems }, filter)

  if #filteredTotems == 0 then
    return nil
  else
    return true
  end
end

LFG.RegisterGeneralFilterHandler("totem", GetFilteredTotem)