local _, LFA = ...

LFA.DB.Rules.DispelCurse = {
  spells = LFA.DB.Spells.dispelc,
  casting = {},
  channel = {},
  buff = {},
  debuff = {}
}