local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "channel" or key == "channelid" or key == "channelleft" or key == "channelpast"
  end,
  true,
  function(key, info)
    local channel, _, _, channelStartTime, channelEndTime, _, _, spellId = UnitChannelInfo(info.unit)
    info.channel = channel
    info.channelid = spellId
    info.channelleft = channelEndTime and (channelEndTime/1000 - GetTime()) or 0
    info.channelpast = channelStartTime and (GetTime() - channelStartTime/1000) or 0
  end
)