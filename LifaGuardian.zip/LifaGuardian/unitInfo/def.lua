local _, LFG = ...

function HasDefensiveSpell(unit, classid)
  return LFG.HasCastableSpell(unit, classid, {"defensive", "externalDefensive", "immunity"})
end

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "def"
  end,
  true,
  function(key, info)
    info.def = HasDefensiveSpell(info.unit, info.classid)
  end
)