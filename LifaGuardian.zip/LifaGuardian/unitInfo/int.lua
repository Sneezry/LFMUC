local _, LFG = ...

function HasInterruptSpell(unit, classid)
  return LFG.HasCastableSpell(unit, classid, {"interrupt"})
end

function IsWinnerToInterrupt()
  if not UnitExists("target") then
    return false
  end

  local _, playerClassId = C_PlayerInfo.GetClass(PlayerLocation:CreateFromUnit("player"))
  if not HasInterruptSpell("player", playerClassId) then
    return false
  end

  local units = GetUnitWithSameTarget()
  local unitsCanInterrupt = {}

  for i=1,#units do
    local _, unitClassId = C_PlayerInfo.GetClass(PlayerLocation:CreateFromUnit(units[i]))
    if HasInterruptSpell(units[i], unitClassId) then
      table.insert(unitsCanInterrupt, units[i])
    end
  end

  if #unitsCanInterrupt == 0 then
    return true
  end

  return IsWinnerToTakeAction(unitsCanInterrupt)
end

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "int" or key == "intwin"
  end,
  true,
  function(key, info)
    if key == "intwin" then
      info.intwin = info.unit == "player" and IsWinnerToInterrupt() or false
    else
      info.int = HasInterruptSpell(info.unit, info.classid)
    end
  end
)