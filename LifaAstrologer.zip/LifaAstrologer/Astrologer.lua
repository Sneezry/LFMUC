local _, ns = ...

LFA = ns

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")

local panel = CreateFrame("Frame")
panel.name = "力法神奇占星家"
InterfaceOptions_AddCategory(panel)

local scrollPanel = CreateFrame("ScrollFrame", "LifaAstrologerScrollPanel", panel, "UIPanelScrollFrameTemplate")

local scrollChild = CreateFrame("Frame")

local subscriptionListTitle = scrollChild:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
subscriptionListTitle:SetPoint("TOPLEFT", 16, -16)
subscriptionListTitle:SetText("订阅列表")

local subscriptionList = CreateFrame("Frame", nil, scrollChild)
subscriptionList:SetAllPoints(scrollchild)
subscriptionList:SetPoint("TOPLEFT", 16, -40)
subscriptionList:SetPoint("BOTTOMRIGHT", -32, 16)

local subscribeButtons = {}
local autoSelectButtons = {}
local subscriptionNameFrams = {}

local function updateSubscriptionStatueText(name, frame)
  local specialization = GetSpecialization()
  LF_Astrologer_Subscription[specialization] = LF_Astrologer_Subscription[specialization] or {}
  LF_Astrologer_Subscription[specialization][name] = LF_Astrologer_Subscription[specialization][name] or { subscribed = not frame.defaultDisabled }

  local subscribed = LF_Astrologer_Subscription[specialization][name].subscribed ~= false
  local autoSelectEnabled = LF_Astrologer_Subscription[specialization][name].autoSelect
  local status = subscribed and "|cFF00FF00[已订阅]|r " or "|cFFFF0000[未订阅]|r "
  local autoSelectStatus = autoSelectEnabled and "|cFF00FF00[目标选择已启用]|r " or "|cFFFF0000[目标选择未启用]|r "
  frame:SetText(status..autoSelectStatus..name)
end

local function _subscribe(name)
  local specialization = GetSpecialization()
  LF_Astrologer_Subscription[specialization] = LF_Astrologer_Subscription[specialization] or {}
  LF_Astrologer_Subscription[specialization][name] = LF_Astrologer_Subscription[specialization][name] or {}
  LF_Astrologer_Subscription[specialization][name].subscribed = true
  ns.RulesBuilder()
end

local function _unsubscribe(name)
  local specialization = GetSpecialization()
  LF_Astrologer_Subscription[specialization] = LF_Astrologer_Subscription[specialization] or {}
  LF_Astrologer_Subscription[specialization][name] = LF_Astrologer_Subscription[specialization][name] or {}
  LF_Astrologer_Subscription[specialization][name].subscribed = false
  ns.RulesBuilder()
end

local function subscribe(frame)
  local specialization = GetSpecialization()
  local name = frame.name
  if LF_Astrologer_Subscription[specialization][name] and LF_Astrologer_Subscription[specialization][name].subscribed ~= false then
    _unsubscribe(name)
    frame:SetText("订阅")
  else
    _subscribe(name)
    frame:SetText("退订")
  end

  updateSubscriptionStatueText(name, frame.nameFrame)
end

local function _enableAutoSelect(name)
  local specialization = GetSpecialization()
  LF_Astrologer_Subscription[specialization] = LF_Astrologer_Subscription[specialization] or {}
  LF_Astrologer_Subscription[specialization][name] = LF_Astrologer_Subscription[specialization][name] or { subscribed = true }
  LF_Astrologer_Subscription[specialization][name].autoSelect = true
  ns.RulesBuilder()
end

local function _disableAutoSelect(name)
  local specialization = GetSpecialization()
  LF_Astrologer_Subscription[specialization] = LF_Astrologer_Subscription[specialization] or {}
  LF_Astrologer_Subscription[specialization][name] = LF_Astrologer_Subscription[specialization][name] or { subscribed = true }
  LF_Astrologer_Subscription[specialization][name].autoSelect = false
  ns.RulesBuilder()
end

local function enableAutoSelect(frame)
  local specialization = GetSpecialization()
  local name = frame.name
  if LF_Astrologer_Subscription[specialization][name] and LF_Astrologer_Subscription[specialization][name].autoSelect then
    _disableAutoSelect(name)
    frame:SetText("启用目标选择")
  else
    _enableAutoSelect(name)
    frame:SetText("禁用目标选择")
  end

  updateSubscriptionStatueText(name, frame.nameFrame)
end

local function createSubscriptionLine(index, name, parentFrame, defaultDisabled)
  local subscriptionName = parentFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  table.insert(subscriptionNameFrams, subscriptionName)

  subscriptionName:SetPoint("TOPLEFT", 198, -16 - 24 * index)
  subscriptionName.name = name
  subscriptionName.defaultDisabled = defaultDisabled
  updateSubscriptionStatueText(name, subscriptionName)

  local subscriptionButton = CreateFrame("Button", nil, parentFrame, "UIPanelButtonTemplate")
  table.insert(subscribeButtons, subscriptionButton)

  subscriptionButton:SetPoint("TOPLEFT", 16, -16 - 24 * index)
  subscriptionButton:SetSize(50, 20)
  subscriptionButton.name = name
  subscriptionButton.nameFrame = subscriptionName
  subscriptionButton.defaultDisabled = defaultDisabled
  subscriptionButton:SetScript("OnClick", subscribe)

  local autoSelectButton = CreateFrame("Button", nil, parentFrame, "UIPanelButtonTemplate")
  table.insert(autoSelectButtons, autoSelectButton)

  autoSelectButton:SetPoint("TOPLEFT", 74, -16 - 24 * index)
  autoSelectButton:SetSize(116, 20)
  autoSelectButton.name = name
  autoSelectButton.nameFrame = subscriptionName
  autoSelectButton.defaultDisabled = defaultDisabled
  autoSelectButton:SetScript("OnClick", enableAutoSelect)

  local specialization = GetSpecialization()
  LF_Astrologer_Subscription[specialization] = LF_Astrologer_Subscription[specialization] or {}
  LF_Astrologer_Subscription[specialization][name] = LF_Astrologer_Subscription[specialization][name] or { subscribed = not defaultDisabled }

  local subscribed = LF_Astrologer_Subscription[specialization][name].subscribed ~= false
  local autoSelectEnabled = LF_Astrologer_Subscription[specialization][name].autoSelect
  if subscribed then
    subscriptionButton:SetText("退订")
  else
    subscriptionButton:SetText("订阅")
  end

  if autoSelectEnabled then
    autoSelectButton:SetText("禁用目标选择")
  else
    autoSelectButton:SetText("启用目标选择")
  end
end

local function initSubscriptionList()
  local index = 1
  for _, v in pairs(ns.Subscription) do
    if v.parent == nil then
      createSubscriptionLine(index, v.name, subscriptionList, v.defaultdisabled)
      index = index + 1
    end
  end

  local scrollbar = _G["LifaAstrologerScrollPanelScrollBar"]
  local scrollupbutton = _G["LifaAstrologerScrollPanelScrollBarScrollUpButton"]
  local scrolldownbutton = _G["LifaAstrologerScrollPanelScrollBarScrollDownButton"]
  scrollupbutton:ClearAllPoints()
  scrollupbutton:SetPoint("TOPRIGHT", scrollPanel, "TOPRIGHT", -2, -2)

  scrolldownbutton:ClearAllPoints()
  scrolldownbutton:SetPoint("BOTTOMRIGHT", scrollPanel, "BOTTOMRIGHT", -2, 2)

  scrollbar:ClearAllPoints();
  scrollbar:SetPoint("TOP", scrollupbutton, "BOTTOM", 0, -2)
  scrollbar:SetPoint("BOTTOM", scrolldownbutton, "TOP", 0, 2)

  scrollPanel:SetScrollChild(scrollChild)
  scrollPanel:SetAllPoints(panel)
  scrollChild:SetSize(500, index * 24 + 80)

  ns.RulesBuilder()
end

local function updateSubscriptionList()
  local specialization = GetSpecialization()

  for i=1,#subscribeButtons do
    local subscriptionButton = subscribeButtons[i]
    local name = subscriptionButton.name

    LF_Astrologer_Subscription[specialization] = LF_Astrologer_Subscription[specialization] or {}
    LF_Astrologer_Subscription[specialization][name] = LF_Astrologer_Subscription[specialization][name] or { subscribed = not subscriptionButton.defaultDisabled }

    local subscribed = LF_Astrologer_Subscription[specialization][name].subscribed ~= false
    local autoSelectEnabled = LF_Astrologer_Subscription[specialization][name].autoSelect

    if subscribed then
      subscriptionButton:SetText("退订")
    else
      subscriptionButton:SetText("订阅")
    end
  end

  for i=1,#autoSelectButtons do
    local autoSelectButton = autoSelectButtons[i]
    local name = autoSelectButton.name

    LF_Astrologer_Subscription[specialization] = LF_Astrologer_Subscription[specialization] or {}
    LF_Astrologer_Subscription[specialization][name] = LF_Astrologer_Subscription[specialization][name] or { subscribed = not autoSelectButton.defaultDisabled }

    local subscribed = LF_Astrologer_Subscription[specialization][name].subscribed ~= false
    local autoSelectEnabled = LF_Astrologer_Subscription[specialization][name].autoSelect

    if autoSelectEnabled then
      autoSelectButton:SetText("禁用目标选择")
    else
      autoSelectButton:SetText("启用目标选择")
    end
  end

  for i=1,#subscriptionNameFrams do
    local subscriptionName = subscriptionNameFrams[i]
    local name = subscriptionName.name

    updateSubscriptionStatueText(name, subscriptionName)
  end

  ns.RulesBuilder()
end

function frame:OnEvent(event, arg)
  if event == "ADDON_LOADED" and arg == "LifaAstrologer" then
    self:UnregisterEvent("ADDON_LOADED")

    if LF_Astrologer_Subscription == nil then
      LF_Astrologer_Subscription = {}
    end
  elseif event == "PLAYER_ENTERING_WORLD" then
    self:UnregisterEvent("PLAYER_ENTERING_WORLD")

    initSubscriptionList()
  elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
    updateSubscriptionList()
  end
end

frame:SetScript("OnEvent", frame.OnEvent)