local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "resource"
  end,
  true,
  function(key, info)
    -- https://wowpedia.fandom.com/wiki/Enum.PowerType
    -- https://www.wowhead.com/resources
    info.resource = max(UnitPower(info.unit, 4), -- 连击点数，盗贼、猫德
      UnitPower(info.unit, 5),                   -- 符文，DK
      UnitPower(info.unit, 7),                   -- 灵魂碎片，术士
      UnitPower(info.unit, 9),                   -- 神圣能量，圣骑士
      UnitPower(info.unit, 12),                  -- 真气，武僧
      UnitPower(info.unit, 16),                  -- 奥术充能，奥法
      UnitPower(info.unit, 19))                  -- 精华，小龙人
  end
)