local _, LFA = ...

LFA.DB.Rules.FreedomEntangled = {
  spells = LFA.DB.Spells.freedom,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {"缠绕"},
  targetofspell = {}
}