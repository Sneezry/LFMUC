local _, LFA = ...

LFA.DB.Rules.IncorporealCC = {
  spells = LFA.DB.Spells.incorporealcc,
  casting = {"失衡"},
  channel = {},
  buff = {},
  debuff = {}
}