local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")

local panel = CreateFrame("Frame")
panel.name = "力法神奇搬仓鼠"
InterfaceOptions_AddCategory(panel)

local scrollPanel = CreateFrame("ScrollFrame", "LifaHamsterScrollPanel", panel, "UIPanelScrollFrameTemplate")

local scrollChild = CreateFrame("Frame")

local waListTitle = scrollChild:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
waListTitle:SetPoint("TOPLEFT", 16, -16)
waListTitle:SetText("WA 列表")

local waButtons = {}

local waClearButton = CreateFrame("Button", nil, scrollChild, "UIPanelButtonTemplate")
waClearButton:SetPoint("TOPLEFT", 500, -16)
waClearButton:SetSize(110, 20)
waClearButton.name = name
waClearButton:SetText("清除所有备份")

local waList = CreateFrame("Frame", nil, scrollChild)
waList:SetAllPoints(scrollchild)
waList:SetPoint("TOPLEFT", 16, -40)
waList:SetPoint("BOTTOMRIGHT", -32, 16)
-- waListScroll:SetClipsChildren(true)

local function _backupWa(name)
  LF_Hamster_WeakAurasSaved[name] = WeakAurasSaved.displays[name]
  if WeakAurasSaved.displays[name].controlledChildren ~= nil then
    for _, child in pairs(WeakAurasSaved.displays[name].controlledChildren) do
      _backupWa(child, WeakAurasSaved.displays[child])
    end
  end
end

local function backupWa(frame)
  local name = frame.name
  _backupWa(name)
  frame:SetText("清除")
  frame:SetScript("OnClick", clearWa)
end

local function _restoreWa(name)
  WeakAurasSaved.displays[name] = LF_Hamster_WeakAurasSaved[name]
  if LF_Hamster_WeakAurasSaved[name].controlledChildren ~= nil then
    for _, child in pairs(LF_Hamster_WeakAurasSaved[name].controlledChildren) do
      _restoreWa(child)
    end
  end
end

local function restoreWa(frame)
  local name = frame.name
  _restoreWa(name)
  frame:SetText("清除")
  frame:SetScript("OnClick", clearWa)
end

local function _clearWa(name)
  LF_Hamster_WeakAurasSaved[name] = nil
  if WeakAurasSaved.displays[name].controlledChildren ~= nil then
    for _, child in pairs(WeakAurasSaved.displays[name].controlledChildren) do
      _clearWa(child)
    end
  end
end

local function clearWa(frame)
  local name = frame.name
  _clearWa(name)
  frame:SetText("备份")
  frame:SetScript("OnClick", backupWa)
end

waClearButton:SetScript("OnClick", function() for _, v in pairs(waButtons) do clearWa(v) end end)

local function createWaLine(index, name, parentFrame)
  local waName = parentFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  waName:SetPoint("TOPLEFT", 74, -16 - 24 * index)
  waName:SetText(name)

  local waButton = CreateFrame("Button", nil, parentFrame, "UIPanelButtonTemplate")
  table.insert(waButtons, waButton)

  waButton:SetPoint("TOPLEFT", 16, -16 - 24 * index)
  waButton:SetSize(50, 20)
  waButton.name = name
  if LF_Hamster_WeakAurasSaved[name] == nil then
    waButton:SetText("备份")
    waButton:SetScript("OnClick", backupWa)
  elseif WeakAurasSaved.displays[name] == nil then
    waButton:SetText("还原")
    waButton:SetScript("OnClick", restoreWa)
  elseif WeakAurasSaved.displays[name].uid ~= LF_Hamster_WeakAurasSaved[name].uid then
    waButton:SetText("覆盖")
    waButton:SetScript("OnClick", restoreWa)
  else
    waButton:SetText("清除")
    waButton:SetScript("OnClick", clearWa)
  end
end

local function initWaList()
  local index = 1
  for k, v in pairs(LF_Hamster_WeakAurasSaved) do
    if v.parent == nil then
      createWaLine(index, k, waList)
      index = index + 1
    end
  end

  for k, v in pairs(WeakAurasSaved.displays) do
    if v.parent == nil and LF_Hamster_WeakAurasSaved[k] == nil then
      createWaLine(index, k, waList)
      index = index + 1
    end
  end

  local scrollbar = _G["LifaHamsterScrollPanelScrollBar"]
  local scrollupbutton = _G["LifaHamsterScrollPanelScrollBarScrollUpButton"]
  local scrolldownbutton = _G["LifaHamsterScrollPanelScrollBarScrollDownButton"]
  scrollupbutton:ClearAllPoints()
  scrollupbutton:SetPoint("TOPRIGHT", scrollPanel, "TOPRIGHT", -2, -2)

  scrolldownbutton:ClearAllPoints()
  scrolldownbutton:SetPoint("BOTTOMRIGHT", scrollPanel, "BOTTOMRIGHT", -2, 2)

  scrollbar:ClearAllPoints();
  scrollbar:SetPoint("TOP", scrollupbutton, "BOTTOM", 0, -2)
  scrollbar:SetPoint("BOTTOM", scrolldownbutton, "TOP", 0, 2)

  scrollPanel:SetScrollChild(scrollChild)
  scrollPanel:SetAllPoints(panel)
  scrollChild:SetSize(500, index * 24 + 80)
end

function frame:OnEvent(event, arg)
  if event == "ADDON_LOADED" and arg == "LifaHamster" then
    self:UnregisterEvent("ADDON_LOADED")

    if LF_Hamster_WeakAurasSaved == nil then
      LF_Hamster_WeakAurasSaved = {}
    end
    initWaList()
  end
end

frame:SetScript("OnEvent", frame.OnEvent)
