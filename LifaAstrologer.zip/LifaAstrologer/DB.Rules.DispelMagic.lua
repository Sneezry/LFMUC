local _, LFA = ...

LFA.DB.Rules.DispelMagic = {
  spells = LFA.DB.Spells.dispelm,
  casting = {},
  channel = {},
  buff = {},
  debuff = {
    -- 注能大厅
    "熔火隐没","冰霜震击",
    -- 蕨皮山谷
    "腐朽感官",
    -- 旋云之巅
    "呼啸劲风"
  }
}