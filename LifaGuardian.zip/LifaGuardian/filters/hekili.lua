local _, LFG = ...

local function GetAllFilteredHekili(filter)
  local recomendation = Hekili and Hekili.DisplayPool.Primary and Hekili.DisplayPool.Primary.Recommendations[1]

  if recomendation then
    recomendation.spell = GetSpellInfo(recomendation.actionID);
    recomendation.spellid = recomendation.actionID;
    recomendation.key = recomendation.keybind;
    recomendation.targetswap = recomendation.indicator == "cycle"
    recomendation.enemycount = recomendation.caption
  end

  local items = { recomendation }

  local filteredHekili = LFG.GetFilteredItem(items, filter)
  if #filteredHekili == 0 then
    return nil
  else
    return filteredHekili[1]
  end
end

LFG.RegisterGeneralFilterHandler("hekili", GetAllFilteredHekili)