local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "mana"
  end,
  true,
  function(key, info)
    info.mana = UnitPower(info.unit) * 100 / UnitPowerMax(info.unit)
  end
)