local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "role"
  end,
  true,
  function(key, info)
    local role = string.lower(UnitGroupRolesAssigned(info.unit))
    info.role = role
  end
)