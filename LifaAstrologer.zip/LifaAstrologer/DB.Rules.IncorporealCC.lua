local _, LFA = ...

LFA.DB.Rules.IncorporealCC = {
  spells = LFA.DB.Spells.incorporealcc,
  name = {},
  casting = {"失衡"},
  channel = {"密闭射线"},
  buff = {},
  debuff = {}
}