local _, LFG = ...

local function GetFilteredKnownSpell(filter)
  local equal = filter.value == IsPlayerSpell(filter.property)

  if filter.operator == "=" and equal or filter.operator == "~" and not equal then
    return { filter.property }
  end

  return nil
end

LFG.RegisterGeneralFilterHandler("knownspell", GetFilteredKnownSpell)