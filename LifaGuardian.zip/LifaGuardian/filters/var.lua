local _, LFG = ...

local function GetAllFilteredVar(filter)
  local items = { LFG.LFG_VAR }
  local filteredVar = LFG.GetFilteredItem(items, filter)
  if #filteredVar == 0 then
    return nil
  else
    return filteredVar[1]
  end
end

LFG.RegisterGeneralFilterHandler("var", GetAllFilteredVar)