local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "isfocus"
  end,
  true,
  function(key, info)
    info.isfocus = UnitIsUnit(info.unit, "focus")
  end
)