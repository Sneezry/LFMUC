local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "icon"
  end,
  true,
  function(key, info)
    info.icon = GetRaidTargetIndex(info.unit)
  end
)