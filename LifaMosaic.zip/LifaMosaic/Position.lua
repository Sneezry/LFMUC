function LifaMosaicGetPosition()
  local unit = C_Map.GetBestMapForUnit("player");
  local pos = C_Map.GetPlayerMapPosition(unit, "player");
  local mapId = C_Map.GetBestMapForUnit("player");
  local command = string.format("position::%d,%.1f,%.1f", mapId, pos.x * 100, pos.y * 100);
  LifaMosaicUpdateCanvas(command);
end

LFMGP = LifaMosaicGetPosition;