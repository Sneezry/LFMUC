local frame = CreateFrame("FRAME");
frame:RegisterEvent("ADDON_LOADED");

local panel = CreateFrame("FRAME")
panel.name = "力法神奇指挥官"
InterfaceOptions_AddCategory(panel)

local channelCheckButtons = {}
local channelInfo = {
  {"团队频道", {1, 0.5, 0, 1}},
  {"小队频道", {0.67, 0.67, 1, 1}},
  {"公会频道", {0.25, 0.75, 0.25, 1}},
  {"私聊频道", {1, 0.5, 1, 1}}
}

local watchTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
watchTitle:SetPoint("TOPLEFT", 16, -16)
watchTitle:SetText("监视频道")

local keystoneTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
keystoneTitle:SetPoint("TOPLEFT", 16, -96)
keystoneTitle:SetText("钥石查询")

local encryptedSyncTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
encryptedSyncTitle:SetPoint("TOPLEFT", 16, -176)
encryptedSyncTitle:SetText("加密怪同步")

local commandTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
commandTitle:SetPoint("TOPLEFT", 16, -256)
commandTitle:SetText("指令集")

local commandTableTitleString = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
commandTableTitleString:SetPoint("TOPLEFT", 16, -280)
commandTableTitleString:SetText("指令字符串")

local commandTableTitleFuzzy = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
commandTableTitleFuzzy:SetPoint("TOPLEFT", 216, -280)
commandTableTitleFuzzy:SetText("模糊匹配")

local commandTableTitleKey = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
commandTableTitleKey:SetPoint("TOPLEFT", 376, -280)
commandTableTitleKey:SetText("指令按键")

local buttonFrame = CreateFrame("Frame", "LifaCommanderButton", UIParent)
urhRelicButton = CreateFrame("Button", "LFCommander_UrhRelic", buttonFrame, 'SecureActionButtonTemplate')
urhRelicButton:SetAllPoints()
urhRelicButton:SetAttribute("type1", "macro")
urhRelicButton:SetAttribute("macrotext", "/target 尤型圣物")
SetOverrideBindingClick(buttonFrame, true, "ALT-CTRL-SHIFT-U", "LFCommander_UrhRelic")

vyRelicButton = CreateFrame("Button", "LFCommander_VyRelic", buttonFrame, 'SecureActionButtonTemplate')
vyRelicButton:SetAllPoints()
vyRelicButton:SetAttribute("type1", "macro")
vyRelicButton:SetAttribute("macrotext", "/target 维型圣物")
SetOverrideBindingClick(buttonFrame, true, "ALT-CTRL-SHIFT-V", "LFCommander_VyRelic")

WoRelicButton = CreateFrame("Button", "LFCommander_WoRelic", buttonFrame, 'SecureActionButtonTemplate')
WoRelicButton:SetAllPoints()
WoRelicButton:SetAttribute("type1", "macro")
WoRelicButton:SetAttribute("macrotext", "/target 沃型圣物")
SetOverrideBindingClick(buttonFrame, true, "ALT-CTRL-SHIFT-W", "LFCommander_WoRelic")

local commandLines = {}
local commandLineCount = 0

local lastLineId = 0

local function GetKey(frame)
  local key = frame:GetText()
  if key == NOT_BOUND then
    key = nil
  end
  return key
end

local function UpdateCommands()
  local newCommands = {}
  local index = 1
  for i, command in ipairs(commandLines) do
    if command[1]:IsVisible() then
      newCommands[index] = {
        command[1]:GetText(),
        command[2]:GetChecked(),
        GetKey(command[3])
      }
      index = index + 1
    end
  end
  LF_Commander_Commands = newCommands
end

local function ChannelCheckBoxOnClick(channel)
  local i = channel.channelIndex
  local code = bit.lshift(1, i - 1)
  if channel:GetChecked() then
    LF_Commander_WatchChannel = bit.bor(LF_Commander_WatchChannel, code)
  else
    code = bit.bnot(code)
    LF_Commander_WatchChannel = bit.band(LF_Commander_WatchChannel, code)
  end
end

local function keystoneCheckBoxOnClick(keystone)
  if keystone:GetChecked() then
    LF_Commander_WatchKeystone = 1
  else
    LF_Commander_WatchKeystone = 0
  end
end

local function encryptedSyncCheckBoxOnClick(encryptedSync)
  if encryptedSync:GetChecked() then
    LF_Commander_EncryptedSync = 1
  else
    LF_Commander_EncryptedSync = 0
  end
end

local function clearKeybindingFocus()
  for i, command in ipairs(commandLines) do
    local f = command[3]
    f:EnableKeyboard(false)
    f:EnableMouseWheel(false)
    f:UnlockHighlight()
    f.waitingForKey = nil
  end
end

panel.okay = clearKeybindingFocus
panel.cancel = clearKeybindingFocus

local function KeybindingOnClick(frame, button)
  for i, command in ipairs(commandLines) do
    command[1]:ClearFocus()
  end

  local waitForKey = frame.waitingForKey

  clearKeybindingFocus()

  if button == "LeftButton" or button == "RightButton" then
    if not waitForKey then
      frame:EnableKeyboard(true)
      frame:EnableMouseWheel(true)
      frame:LockHighlight()
      frame.waitingForKey = true
    end
  end
end

local ignoreKeys = {
  ["BUTTON1"] = true, ["BUTTON2"] = true,
  ["UNKNOWN"] = true,
  ["LSHIFT"] = true, ["LCTRL"] = true, ["LALT"] = true,
  ["RSHIFT"] = true, ["RCTRL"] = true, ["RALT"] = true,
}

local function SetKey(frame, key)
  if (key or "") == "" then
    frame:SetText(NOT_BOUND)
    frame:SetNormalFontObject("GameFontNormal")
  else
    frame:SetText(key)
    frame:SetNormalFontObject("GameFontHighlight")
  end
  UpdateCommands()
end

local function KeybindingOnKeyDown(frame, key)
  if frame.waitingForKey then
    local keyPressed = key
    if keyPressed == "ESCAPE" then
      keyPressed = ""
    else
      if ignoreKeys[keyPressed] then return end
      if keyPressed:find("^NUMPAD") then keyPressed = "N" .. keyPressed:sub(7) end
    end

    frame:EnableKeyboard(false)
    frame:EnableMouseWheel(false)
    frame:UnlockHighlight()
    frame.waitingForKey = nil

    SetKey(frame, keyPressed)
  end
end

local function DeleteCommandLine(frame)
  local deleteIndex = frame.commandIndex
  for i=deleteIndex,#commandLines,1 do
    if i == #commandLines or not commandLines[i+1][1]:IsVisible() then
      commandLines[i][1]:Hide()
      commandLines[i][2]:Hide()
      commandLines[i][3]:Hide()
      commandLines[i][4]:Hide()
      break
    end
    commandLines[i][1]:SetText(commandLines[i+1][1]:GetText())
    commandLines[i][2]:SetChecked(commandLines[i+1][2]:GetChecked())
    commandLines[i][3]:SetText(commandLines[i+1][3]:GetText())
  end
  clearKeybindingFocus()
  commandLineCount = commandLineCount - 1
  UpdateCommands()
end

local function addNewCommand(command, fuzzy, key)
  local i = commandLineCount + 1
  if commandLines[i] == nil then
    commandLines[i] = {}
    commandLines[i][1] = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
    commandLines[i][1]:SetAutoFocus(false)
    commandLines[i][1]:SetMultiLine(false)
    commandLines[i][1]:SetWidth(170)
    commandLines[i][1]:SetHeight(30)
    commandLines[i][1]:SetFontObject("ChatFontNormal")
    commandLines[i][1]:SetScript("OnTextChanged", UpdateCommands)
    commandLines[i][1]:SetPoint("TOPLEFT", commandTableTitleString, "BOTTOMLEFT", 2, -8 - (i - 1) * 36)

    commandLines[i][2] = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
    commandLines[i][2]:SetPoint("TOPLEFT", commandTableTitleString, "BOTTOMLEFT", 216, -8 - (i - 1) * 36)
    commandLines[i][2]:SetScript("OnClick", UpdateCommands)

    commandLines[i][3] = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    commandLines[i][3]:SetSize(60, 30)
    commandLines[i][3]:RegisterForClicks("AnyDown")
    commandLines[i][3]:SetScript("OnClick", KeybindingOnClick)
    commandLines[i][3]:SetScript("OnKeyDown", KeybindingOnKeyDown)
    commandLines[i][3]:SetPoint("TOPLEFT", commandTableTitleString, "BOTTOMLEFT", 360, -8 - (i - 1) * 36)
    commandLines[i][3]:EnableKeyboard(false)

    commandLines[i][4] = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    commandLines[i][4]:SetSize(60, 30)
    commandLines[i][4]:SetText("删除")
    commandLines[i][4].commandIndex = i
    commandLines[i][4]:SetScript("OnClick", DeleteCommandLine)
    commandLines[i][4]:SetPoint("TOPLEFT", commandTableTitleString, "BOTTOMLEFT", 460, -8 - (i - 1) * 36)
  end

  commandLines[i][1]:SetText(command)
  commandLines[i][1]:SetCursorPosition(0)
  commandLines[i][2]:SetChecked(fuzzy)
  if key == nil or key == "" then
    commandLines[i][3]:SetText(NOT_BOUND)
  else
    commandLines[i][3]:SetText(key)
  end
  
  commandLines[i][1]:Show()
  commandLines[i][2]:Show()
  commandLines[i][3]:Show()
  commandLines[i][4]:Show()

  commandLineCount = i
end

local function addNewEmptyCommand()
  addNewCommand("", false, nil)
end

local commandNewButton = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
commandNewButton:SetSize(60, 30)
commandNewButton:SetPoint("TOPLEFT", 100, -250)
commandNewButton:SetText("添加")
commandNewButton:SetScript("OnClick", addNewEmptyCommand)

local function getKeyFromMsg(msg)
  for _, command in ipairs(LF_Commander_Commands) do
    local commandString = command[1]
    local fuzzy = command[2]
    local key = command[3]
    if fuzzy and string.find(msg:lower(), commandString:lower()) or msg == commandString then
      return key
    end
  end
  return nil
end

local function messageWatcher(self, event, msg, sender, languageName, channelName, playerName2, specialFlags, zoneChannelID, channelIndex, channelBaseName, unused, lineID)
  if lastLineId >= lineID then
    return nil
  end
  
  lastLineId = lineID

  local channels = {}
  channels["CHAT_MSG_RAID"] = 1
  channels["CHAT_MSG_RAID_LEADER"] = 1
  channels["CHAT_MSG_PARTY"] = 2
  channels["CHAT_MSG_PARTY_LEADER"] = 2
  channels["CHAT_MSG_GUILD"] = 4
  channels["CHAT_MSG_OFFICER"] = 4
  channels["CHAT_MSG_WHISPER"] = 8

  if bit.band(LF_Commander_WatchChannel, channels[event]) > 0 then
    local key = getKeyFromMsg(msg)
    if key == nil and msg == "!lfv" and LF_Commander_EncryptedSync == 1 then
      key = "ACSV"
      SendChatMessage("力法指挥官报告：正在关注【维型圣物】", "PARTY")
    elseif key == nil and msg == "!lfu" and LF_Commander_EncryptedSync == 1 then
      key = "ACSU"
      SendChatMessage("力法指挥官报告：正在关注【尤型圣物】", "PARTY")
    elseif key == nil and msg == "!lfw" and LF_Commander_EncryptedSync == 1 then
      key = "ACSW"
      SendChatMessage("力法指挥官报告：正在关注【沃型圣物】", "PARTY")
    end

    if key ~= nil then
      local player, realm = strsplit("-", sender, 2)
      if realm == GetRealmName() then
        LFCLC = player
      else
        LFCLC = sender
      end
      info=(UnitGUID("player") and C_BattleNet.GetAccountInfoByGUID(UnitGUID("player")) or nil)
      LFMUC("key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404") .. ":key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404") .. ":key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404"), 1)
    end

    if msg == "!lfkeys" and LF_Commander_WatchKeystone == 1 then
      for bag=0,NUM_BAG_SLOTS do
        for slot=1,GetContainerNumSlots(bag) do
          local icon, _, _, _, _, _, link = GetContainerItemInfo(bag,slot)
          if icon == 4352494 then
            local channelNames = {}
            channelNames[1] = "RAID"
            channelNames[2] = "PARTY"
            channelNames[4] = "GUILD"
            if channels[event] < 8 then
              SendChatMessage("力法指挥官报告：" .. link, channelNames[channels[event]])
            else
              SendChatMessage("力法指挥官报告：" .. link, "WHISPER", nil, sender)
            end
          end
        end
      end
    end
  end
end

function frame:OnEvent(event, arg)
  if event == "ADDON_LOADED" and arg == "LifaCommander" then
    self:UnregisterEvent("ADDON_LOADED")

    if LF_Commander_WatchChannel == nil then
      LF_Commander_WatchChannel = 15;
    end

    for i, channel in ipairs(channelInfo) do
      channelCheckButtons[i] = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
      channelCheckButtons[i]:SetScript("OnClick", ChannelCheckBoxOnClick)
      channelCheckButtons[i]:SetChecked(bit.band(LF_Commander_WatchChannel, bit.lshift(1, i - 1)) > 0)
      channelCheckButtons[i].channelIndex = i
      channelCheckButtons[i].Text:SetText(channel[1])
      channelCheckButtons[i].Text:SetTextColor(channel[2][1], channel[2][2], channel[2][3], channel[2][4])
      channelCheckButtons[i]:SetPoint("TOPLEFT", watchTitle, "BOTTOMLEFT", (i - 1) * 120, -8)
    end

    if LF_Commander_WatchKeystone == nil then
      LF_Commander_WatchKeystone = 1
    end

    if LF_Commander_EncryptedSync == nil then
      LF_Commander_EncryptedSync = 1
    end

    keystoneCheckButton = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
    keystoneCheckButton:SetScript("OnClick", keystoneCheckBoxOnClick)
    keystoneCheckButton:SetChecked(LF_Commander_WatchKeystone == 1)
    keystoneCheckButton.Text:SetText("监视钥石查询 !lfkeys")
    keystoneCheckButton:SetPoint("TOPLEFT", keystoneTitle, "BOTTOMLEFT", 0, -8)

    encryptedSyncCheckButton = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
    encryptedSyncCheckButton:SetScript("OnClick", encryptedSyncCheckBoxOnClick)
    encryptedSyncCheckButton:SetChecked(LF_Commander_EncryptedSync == 1)
    encryptedSyncCheckButton.Text:SetText("加密怪同步")
    encryptedSyncCheckButton:SetPoint("TOPLEFT", encryptedSyncTitle, "BOTTOMLEFT", 0, -8)

    if LF_Commander_Commands == nil then
      LF_Commander_Commands = {}
    end

    for _, command in ipairs(LF_Commander_Commands) do
      addNewCommand(command[1], command[2], command[3])
    end

    ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID", messageWatcher);
    ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID_LEADER", messageWatcher);
    ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY", messageWatcher);
    ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY_LEADER", messageWatcher);
    ChatFrame_AddMessageEventFilter("CHAT_MSG_GUILD", messageWatcher);
    ChatFrame_AddMessageEventFilter("CHAT_MSG_OFFICER", messageWatcher);
    ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", messageWatcher);
  end
end
frame:SetScript("OnEvent", frame.OnEvent);

function LFCDUMP()
  return LF_Commander_Commands
end