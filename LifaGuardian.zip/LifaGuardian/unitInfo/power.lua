local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "power"
  end,
  true,
  function(key, info)
    info.power = max(UnitPower(info.unit, 1), -- 怒气，战士、猫德
      UnitPower(info.unit, 2),                -- 集中值，猎人
      UnitPower(info.unit, 3),                -- 能量，盗贼
      UnitPower(info.unit, 6),                -- 符文能量，DK
      UnitPower(info.unit, 8),                -- 星界能量，鸟德
      UnitPower(info.unit, 11),               -- 漩涡，萨满
      UnitPower(info.unit, 13),               -- 狂乱值，暗牧
      UnitPower(info.unit, 17))               -- 恶魔之怒，DH
  end
)