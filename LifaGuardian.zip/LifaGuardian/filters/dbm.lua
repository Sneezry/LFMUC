local _, LFG = ...

local DBM_TIMER = {}

local function DBMEventsHandler(event, ...)
  if event == "DBM_TimerStart" then
    local timerId, text, duration, icon, timerType, spellId = ...
    if not timerId then return end

    local spellName = GetSpellInfo(spellId)
    DBM_TIMER[timerId] = {
      text = text,
      expirationTime = GetTime() + duration,
      spellId = tostring(spellId),
      spellName = spellName,
      source = "DBM",
    }
  elseif event == "DBM_TimerUpdate" then
    local timerId, elapsed, duration = ...
    if not timerId then return end

    DBM_TIMER[timerId].expirationTime = GetTime() + duration - elapsed
  elseif event=="DBM_TimerStop" then
    local timerId = ...
    if not timerId then return end

    DBM_TIMER[timerId] = nil
  end

  for k,v in pairs(DBM_TIMER) do
    if v.expirationTime + 5 < GetTime() then
      DBM_TIMER[k] = nil
    end
  end
end

local function BWEventsHandler(event, ...)
  if event == "BigWigs_StartBar" then
    local addon, spellId, text, duration = ...
    local expirationTime = GetTime() + duration
    local spellName = GetSpellInfo(spellId)

    DBM_TIMER[text] = {
      text = text,
      expirationTime = GetTime() + duration,
      spellId = tostring(spellId),
      spellName = spellName,
      source = "BW"
    }
  elseif event == "BigWigs_StopBar" then
    local plugin, text = ...
    DBM_TIMER[text] = nil
  elseif event == "BigWigs_StopBars" then
    for k,v in pairs(DBM_TIMER) do
      if v.source == "BW" then
        DBM_TIMER[k] = nil
      end
    end
  end

  for k,v in pairs(DBM_TIMER) do
    if v.expirationTime + 5 < GetTime() then
      DBM_TIMER[k] = nil
    end
  end
end

local function GetFilteredDBM(filter)
  local spellIdOrName = nil
  local text = nil

  if string.sub(filter.property, 1, 6) == "spell:" then
    spellIdOrName = string.sub(filter.property, 7)
  elseif string.sub(filter.property, 1, 5) == "text:" then
    text = string.sub(filter.property, 6)
  end

  if spellIdOrName or text then
    for k,v in pairs(DBM_TIMER) do
      if spellIdOrName ~= nil and (tostring(v.spellId) == spellIdOrName or v.spellName == spellIdOrName)
          or text ~= nil and v.text == text then
        local leftTime = ceil((v.expirationTime - GetTime()) * 10) / 10

        if leftTime >= 0 then
          if filter.operator == "=" and leftTime == filter.value
            or filter.operator == "~" and leftTime ~= filter.value
            or filter.operator == "<" and leftTime < filter.value
            or filter.operator == ">" and leftTime > filter.value then
            return true
          end
        end
      end
    end
  end

  return nil
end

if DBM then
  DBM:RegisterCallback("DBM_TimerStart", DBMEventsHandler)
  DBM:RegisterCallback("DBM_TimerUpdate", DBMEventsHandler)
  DBM:RegisterCallback("DBM_TimerStop", DBMEventsHandler)
end

if BigWigsLoader then
  local plugin = {}
  BigWigsLoader.RegisterMessage(plugin, "BigWigs_StartBar", BWEventsHandler)
  BigWigsLoader.RegisterMessage(plugin, "BigWigs_StopBar", BWEventsHandler)
  BigWigsLoader.RegisterMessage(plugin, "BigWigs_StopBars", BWEventsHandler)
end

LFG.RegisterGeneralFilterHandler("dbm", GetFilteredDBM)