local _, LFA = ...

LFA.DB.Rules.DispelDisease = {
  spells = LFA.DB.Spells.dispeld,
  casting = {},
  channel = {},
  buff = {},
  debuff = {}
}