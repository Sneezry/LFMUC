local _, LFA = ...

LFA.DB.Rules.Protection = {
  spells = LFA.DB.Spells.protection,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {
    -- 蕨皮山谷
    "屠戮标记"
  }
}