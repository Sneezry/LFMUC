local _, LFA = ...

LFA.DB.Rules.MouseoverIncorporealCC = {
  spells = LFA.DB.Spells.incorporealcc,
  template = "action,action.key=鼠标指向%s,instance.type=party|group.type=party,spell.%s=true,mouseover.casting=失衡",
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {}
}