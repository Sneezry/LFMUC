local _, LFG = ...

local function GetFilteredPlayer(filter)
  return LFG.GetFilteredUnit("player", filter)
end

LFG.RegisterGeneralFilterHandler("player", GetFilteredPlayer)