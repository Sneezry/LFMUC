local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "canassist"
  end,
  true,
  function(key, info)
    info.canassist = UnitCanAssist("player", info.unit)
  end
)