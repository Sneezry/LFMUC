local frame = CreateFrame("FRAME")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterEvent("PLAYER_TARGET_CHANGED")
frame:RegisterEvent("UNIT_SPELLCAST_SENT")
frame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
frame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
frame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
frame:RegisterEvent("NAME_PLATE_UNIT_REMOVED")

local panel = CreateFrame("FRAME")
panel.name = "力法神奇守护者"
InterfaceOptions_AddCategory(panel)

local classColor = {
  {0.78, 0.61, 0.43}, --Warrior
  {0.96, 0.55, 0.73}, --Paladin
  {0.67, 0.83, 0.45}, --Hunter
  {1.00, 0.96, 0.41}, --Rogue
  {1.00, 1.00, 1.00}, --Priest
  {0.77, 0.12, 0.23}, --Death Knight
  {0.00, 0.44, 0.87}, --Shaman
  {0.25, 0.78, 0.92}, --Mage
  {0.53, 0.53, 0.93}, --Warlock
  {0.00, 1.00, 0.60}, --Monk
  {1.00, 0.49, 0.04}, --Druid
  {0.64, 0.19, 0.79}, --Demon Hunter
  {0.20, 0.58, 0.50}, --Evoker
}

local keybindings = {
  player = "ALT-CTRL-NUMPAD0",
  party1 = "ALT-CTRL-NUMPAD1",
  party2 = "ALT-CTRL-NUMPAD2",
  party3 = "ALT-CTRL-NUMPAD3",
  party4 = "ALT-CTRL-NUMPAD4",
  raid1 = "ALT-CTRL-NUMPAD5",
  raid2 = "ALT-CTRL-NUMPAD6",
  raid3 = "ALT-CTRL-NUMPAD7",
  raid4 = "ALT-CTRL-NUMPAD8",
  raid5 = "ALT-CTRL-NUMPAD9",
  raid6 = "ALT-CTRL-F1",
  raid7 = "ALT-CTRL-F2",
  raid8 = "ALT-CTRL-F3",
  raid9 = "ALT-CTRL-F5",
  raid10 = "ALT-CTRL-F6",
  raid11 = "ALT-CTRL-F7",
  raid12 = "ALT-CTRL-F8",
  raid13 = "ALT-CTRL-F9",
  raid14 = "ALT-CTRL-F10",
  raid15 = "ALT-CTRL-F11",
  raid16 = "ALT-CTRL-F12",
  raid17 = "ALT-SHIFT-F1",
  raid18 = "ALT-SHIFT-F2",
  raid19 = "ALT-SHIFT-F3",
  raid20 = "ALT-SHIFT-F5",
  raid21 = "ALT-SHIFT-F6",
  raid22 = "ALT-SHIFT-F7",
  raid23 = "ALT-SHIFT-F8",
  raid24 = "ALT-SHIFT-F9",
  raid25 = "ALT-SHIFT-F10",
  raid26 = "ALT-SHIFT-F11",
  raid27 = "ALT-SHIFT-F12",
  raid28 = "CTRL-SHIFT-F1",
  raid29 = "CTRL-SHIFT-F2",
  raid30 = "CTRL-SHIFT-F3",
  raid31 = "CTRL-SHIFT-F4",
  raid32 = "CTRL-SHIFT-F5",
  raid33 = "CTRL-SHIFT-F6",
  raid34 = "CTRL-SHIFT-F7",
  raid35 = "CTRL-SHIFT-F8",
  raid36 = "CTRL-SHIFT-F9",
  raid37 = "CTRL-SHIFT-F10",
  raid38 = "CTRL-SHIFT-F11",
  raid39 = "CTRL-SHIFT-F12",
  raid40 = "CTRL-SHIFT-=",
  nextEnemy = "Tab",
}

local wasounds = {
  ["Batman Punch"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BatmanPunch.ogg",
  ["Bike Horn"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BikeHorn.ogg",
  ["Boxing Arena Gong"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BoxingArenaSound.ogg",
  ["Bleat"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Bleat.ogg",
  ["Cartoon Hop"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\CartoonHop.ogg",
  ["Cat Meow"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\CatMeow2.ogg",
  ["Kitten Meow"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\KittenMeow.ogg",
  ["Robot Blip"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\RobotBlip.ogg",
  ["Sharp Punch"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\SharpPunch.ogg",
  ["Water Drop"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\WaterDrop.ogg",
  ["Air Horn"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AirHorn.ogg",
  ["Applause"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Applause.ogg",
  ["Banana Peel Slip"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BananaPeelSlip.ogg",
  ["Blast"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Blast.ogg",
  ["Cartoon Voice Baritone"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\CartoonVoiceBaritone.ogg",
  ["Cartoon Walking"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\CartoonWalking.ogg",
  ["Cow Mooing"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\CowMooing.ogg",
  ["Ringing Phone"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\RingingPhone.ogg",
  ["Roaring Lion"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\RoaringLion.ogg",
  ["Shotgun"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Shotgun.ogg",
  ["Squish Fart"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\SquishFart.ogg",
  ["Temple Bell"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\TempleBellHuge.ogg",
  ["Torch"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Torch.ogg",
  ["Warning Siren"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\WarningSiren.ogg",
  ["Sheep Blerping"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\SheepBleat.ogg",
  ["Rooster Chicken Call"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\RoosterChickenCalls.ogg",
  ["Goat Bleeting"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\GoatBleating.ogg",
  ["Acoustic Guitar"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AcousticGuitar.ogg",
  ["Synth Chord"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\SynthChord.ogg",
  ["Chicken Alarm"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\ChickenAlarm.ogg",
  ["Xylophone"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Xylophone.ogg",
  ["Drums"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Drums.ogg",
  ["Tada Fanfare"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\TadaFanfare.ogg",
  ["Squeaky Toy Short"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\SqueakyToyShort.ogg",
  ["Error Beep"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\ErrorBeep.ogg",
  ["Oh No"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\OhNo.ogg",
  ["Double Whoosh"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\DoubleWhoosh.ogg",
  ["Brass"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Brass.mp3",
  ["Glass"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Glass.mp3",
  ["Tank In Danger"] = "Interface\\AddOns\\LifaGuardian\\Media\\Sounds\\TankInDanger.ogg"
}

local msgQueue = {}
local lastLineId = 0
local UNIT_CACHE = {}
local CACHE_DURATION = 0.25
local OPERATIONS = {}
local DBM_TIMER = {}
local NEXT_KEY_OVERRIDE = {}
local CACHED_NAME_PLATE_UNITS = {}
local CURRENT_LINE = 0
local SUCCEED_LINE = 0
local CURRENT_QUEUE_LINE = nil
local CURRENT_QUEUE_START = nil
local CURRENT_QUEUE_TYPE = nil
local KEY_BIND_CACHE = {}

LFG_VAR = {}

local defaultProfile = [[
unit,unit.health>0,unit.health<100,unit.health=min
unit,unit.isplayer=true
]]

local defaultDpsProfile = [[
action,action.key=hekili
]]

local lastChangeTargetTime = 0
local changeTargetTimeCooldown = 0.1
local recomendedUnit = nil
local frameDuration = 0.1
local filteredUnits = {}
local filteredEnemies = {}
local lastSoundPlayedTime = 0
local soundHandler = nil
local soundRepeatDuration = 3
local nowTime = GetTime()
local unitInfoCalledCount = 0
local unitInfoCacheMissedCount = 0
local nextKeyOverrideTimeout = 2

local playerName = UnitName("player")

local L = {
  ["按键"] = "key",
  ["警报"] = "alarm",
  ["报警"] = "alarm",
  ["队友"] = "unit",
  ["动作"] = "action",
  ["敌人"] = "enemy",
  ["名称"] = "name",
  ["姓名"] = "name",
  ["声音"] = "sound",
  ["技能"] = "spell",
  ["队伍"] = "group",
  ["副本"] = "instance",
  ["类型"] = "type",
  ["物品"] = "item",
  ["饰品"] = "sp",
  ["玩家"] = "player",
  ["我"] = "player",
  ["目标"] = "target",
  ["目标的目标"] = "targettarget",
  ["焦点"] = "focus",
  ["鼠标指向"] = "mouseover",
  ["鼠标指向的目标"] = "mouseover",
  ["图腾"] = "totem",
  ["所有队友"] = "units",
  ["所有人"] = "units",
  ["所有敌人"] = "enemies",
  ["所有怪"] = "enemies",
  ["职业"] = "class",
  ["在线"] = "online",
  ["忽略"] = "ignore",
  ["忽视"] = "ignore",
  ["是玩家"] = "isplayer",
  ["是我自己"] = "isplayer",
  ["是我"] = "isplayer",
  ["是boss"] = "isboss",
  ["职责"] = "role",
  ["生命值"] = "health",
  ["血量"] = "health",
  ["有可被移除debuff"] = "hasremovabledebuff",
  ["法力值"] = "mana",
  ["蓝"] = "mana",
  ["死亡"] = "isdead",
  ["死了"] = "isdead",
  ["战斗中"] = "incombat",
  ["进战"] = "incombat",
  ["敌方单位"] = "canattack",
  ["是怪"] = "canattack",
  ["友方单位"] = "canassist",
  ["是队友"] = "canassist",
  ["在移动"] = "ismoving",
  ["移动中"] = "ismoving",
  ["在动"] = "ismoving",
  ["移动"] = "ismoving",
  ["资源"] = "resource",
  ["豆"] = "resource",
  ["能量"] = "power",
  ["正在释放"] = "casting",
  ["在释放"] = "casting",
  ["正在放"] = "casting",
  ["正在读"] = "casting",
  ["施法剩余时间"] = "castingleft",
  ["读条剩余时间"] = "castingleft",
  ["读条还剩"] = "castingleft",
  ["施法已过时间"] = "castingpast",
  ["读条已过时间"] = "castingpast",
  ["是焦点"] = "isfocus",
  ["减伤可用"] = "def",
  ["有减伤"] = "def",
  ["技能范围内"] = "spellinrange",
  ["buff剩余时间"] = "buffleft",
  ["buff持续时间"] = "buffpast",
  ["来自玩家的buff"] = "bufffromplayer",
  ["来自我的buff"] = "bufffromplayer",
  ["我上的buff"] = "bufffromplayer",
  ["来自玩家的buff剩余时间"] = "bufffromplayerleft",
  ["来自我的buff剩余时间"] = "bufffromplayerleft",
  ["我上的buff剩余时间"] = "bufffromplayerleft",
  ["来自玩家的buff持续时间"] = "bufffromplayerpast",
  ["来自我的buff持续时间"] = "bufffromplayerpast",
  ["我上的buff持续时间"] = "bufffromplayerpast",
  ["debuff剩余时间"] = "debuffleft",
  ["debuff持续时间"] = "debuffpast",
  ["来自玩家的debuff"] = "debufffromplayer",
  ["来自我的debuff"] = "debufffromplayer",
  ["我上的debuff"] = "debufffromplayer",
  ["来自玩家的debuff剩余时间"] = "debufffromplayerleft",
  ["来自我的debuff剩余时间"] = "debufffromplayerleft",
  ["我上的debuff剩余时间"] = "debufffromplayerleft",
  ["来自玩家的debuff持续时间"] = "debufffromplayerpast",
  ["来自我的debuff持续时间"] = "debufffromplayerpast",
  ["我上的debuff持续时间"] = "debufffromplayerpast",
  ["小队"] = "party",
  ["团队"] = "raid",
  ["团"] = "raid",
  ["坦克"] = "tank",
  ["治疗"] = "healer",
  ["消息"] = "msg",
  ["队伍消息"] = "msg_group",
  ["团队消息"] = "msg_raid",
  ["小队消息"] = "msg_party",
  ["公会消息"] = "msg_guild",
  ["密语"] = "msg_whisper",
  ["说"] = "msg_say",
  ["大喊"] = "msg_yell",
  ["文字"] = "text",
  ["数量"] = "count",
}

local function StringHash(text)
  local counter = 1
  local len = string.len(text)
  for i = 1, len, 3 do
    counter = math.fmod(counter*8161, 4294967279) + -- 2^32 - 17: Prime!
  	  (string.byte(text,i)*16776193) +
  	  ((string.byte(text,i+1) or (len-i+256))*8372226) +
  	  ((string.byte(text,i+2) or (len-i+256))*3932164)
  end
  return math.fmod(counter, 4294967291) -- 2^32 - 5: Prime (and different from the prime in the loop)
end

local function GetUnitWithSameTarget()
  local units = {}

  for i=1,4 do
    if UnitExists("party"..i) and UnitIsUnit("target", "party"..i.."target") then
      table.insert(units, "party"..i)
    end
  end

  for i=1,40 do
    if UnitExists("raid"..i) and UnitIsUnit("target", "raid"..i.."target") and not UnitIsUnit("player", "raid"..i) then
      table.insert(units, "raid"..i)
    end
  end

  return units
end

local function GetUnitTargetHash(unit)
  local targetGUID = UnitGUID("target")
  local unitGUID = UnitGUID(unit)

  if targetGUID == nil then
    return -1
  end

  return bit.bxor(StringHash(targetGUID), StringHash(unitGUID))
end

local function IsWinnerToTakeAction(units)
  local playerTargetHash = GetUnitTargetHash("player")

  for i=1,#units do
    local unitTargetHash = GetUnitTargetHash(units[i])

    if unitTargetHash > playerTargetHash then
      return false
    end
  end

  return true
end

function LFGHEKILISPELLDISABLE(spell)
  local abilityInfo = GetAbilityInfo(spell)
  
  if abilityInfo == nil then
    return
  end

  abilityInfo.disabled = true
end

function LFGHEKILISPELLENABLE(spell)
  local abilityInfo = GetAbilityInfo(spell)
  
  if abilityInfo == nil then
    return
  end

  abilityInfo.disabled = false
end

function LFGGETHEKILISPELLDISABLED(spell)
  local abilityInfo = GetAbilityInfo(spell)
  
  if abilityInfo == nil then
    return
  end

  return abilityInfo.disabled
end

local function GetUnitHealPercentage(unit)
  local incomingHeals = UnitGetIncomingHeals(unit)
  return (UnitHealth(unit) + (incomingHeals == nil and 0 or incomingHeals)) * 100 / UnitHealthMax(unit)
end

local function GetUnitHealLost(unit)
  local incomingHeals = UnitGetIncomingHeals(unit)
  return UnitHealthMax(unit) - (UnitHealth(unit) + (incomingHeals == nil and 0 or incomingHeals))
end

local function GetUnitBuff(unit)
  local buffs, i = { }, 1
  local buff, _, count, _, duration, expTime, caster, _, _, spellId = UnitBuff(unit, i)

  while buff do
    local leftTime = expTime == 0 and 86400 or expTime - GetTime()
    local pastTime = expTime == 0 and 86400 or (GetTime() - (expTime - duration))
    buffs["buff:" .. buff] = math.max(count, 1)
    buffs["buffleft:" .. buff] = leftTime
    buffs["buffpast:" .. buff] = pastTime
    buffs["buff:" .. tostring(spellId)] = math.max(count, 1)
    buffs["buffleft:" .. tostring(spellId)] = leftTime
    buffs["buffpast:" .. tostring(spellId)] = pastTime
    if caster == "player" then
      buffs["bufffromplayer:" .. buff] = math.max(count, 1)
      buffs["bufffromplayerleft:" .. buff] = leftTime
      buffs["bufffromplayerpast:" .. buff] = pastTime
      buffs["bufffromplayer:" .. tostring(spellId)] = math.max(count, 1)
      buffs["bufffromplayerleft:" .. tostring(spellId)] = leftTime
      buffs["bufffromplayerpast:" .. tostring(spellId)] = pastTime
    end
    i = i + 1
    buff, _, count, _, _, expTime, caster = UnitBuff(unit, i)
  end

  return buffs
end

local function GetUnitDebuff(unit)
  local debuffs, i = { }, 1
  local debuff, _, count, _, duration, expTime, caster, _, _, spellId = UnitDebuff(unit, i)

  while debuff do
    local leftTime = expTime == 0 and 86400 or floor(expTime - GetTime())
    local pastTime = expTime == 0 and 86400 or (GetTime() - (expTime - duration))
    debuffs["debuff:" .. debuff] = math.max(count, 1)
    debuffs["debuffleft:" .. debuff] = leftTime
    debuffs["debuffpast:" .. debuff] = pastTime
    debuffs["debuff:" .. tostring(spellId)] = math.max(count, 1)
    debuffs["debuffleft:" .. tostring(spellId)] = leftTime
    debuffs["debuffpast:" .. tostring(spellId)] = pastTime
    if caster == "player" then
      debuffs["debufffromplayer:" .. debuff] = math.max(count, 1)
      debuffs["debufffromplayerleft:" .. debuff] = leftTime
      debuffs["debufffromplayerpast:" .. debuff] = pastTime
      debuffs["debufffromplayer:" .. tostring(spellId)] = math.max(count, 1)
      debuffs["debufffromplayerleft:" .. tostring(spellId)] = leftTime
      debuffs["debufffromplayerpast:" .. tostring(spellId)] = pastTime
    end
    i = i + 1
    debuff, _, count, _, _, expTime, caster = UnitDebuff(unit, i)
  end

  return debuffs
end

local function HasRemovableDebuff(unit)
  if UnitDebuff(unit, 1, true) then
    return true
  end

  return false
end

function Includes(table, value)
  for i=1,#table do
    if table[i] == value then
      return true
    end
  end

  return false
end

function HasCastableSpell(unit, classid, types, ids)
  if not OmniCD or not OmniCD[1] or not OmniCD[1].spell_db
      or not OmniCD[1].Party or not OmniCD[1].Party.groupInfo then return nil end

  local spells = OmniCD[1].spell_db[classid]
  for _, info in pairs(OmniCD[1].Party.groupInfo) do
    if unit == info.unit or UnitIsUnit(unit, info.unit) then
      for i=1,#spells do
        if (types and Includes(types, spells[i].type) or ids and Includes(ids, spells[i].spellID)) then
          local active = info.active[spells[i].spellID]
          if not active then
            return true
          end

          local endTime = 0
          local modRate = active.iconModRate
          if modRate then
            now = now or GetTime()
            local newTime = now - (now - active.startTime) / modRate
            endTime = newTime + active.duration / modRate
          else
            endTime = active.startTime + active.duration
          end

          if endTime < GetTime() then
            return true
          end
        end
      end

      return false
    end
  end

  return nil
end

function HasDefensiveSpell(unit, classid)
  return HasCastableSpell(unit, classid, {"defensive", "externalDefensive", "immunity"})
end

function HasInterruptSpell(unit, classid)
  return HasCastableSpell(unit, classid, {"interrupt"})
end

function HasCCSpell(unit, classid)
  return HasCastableSpell(unit, classid, nil, {408, 2094, 1776, 5211, 853, 115750, 360806, 221562, 19577, 115078, 88625, 64044, 107570, 305483, 6789, 211881})
end

function IsWinnerToInterrupt()
  if not UnitExists("target") then
    return false
  end

  local _, playerClassId = C_PlayerInfo.GetClass(PlayerLocation:CreateFromUnit("player"))
  if not HasInterruptSpell("player", playerClassId) then
    return false
  end

  local units = GetUnitWithSameTarget()
  local unitsCanInterrupt = {}

  for i=1,#units do
    local _, unitClassId = C_PlayerInfo.GetClass(PlayerLocation:CreateFromUnit(units[i]))
    if HasInterruptSpell(units[i], unitClassId) then
      table.insert(unitsCanInterrupt, units[i])
    end
  end

  if #unitsCanInterrupt == 0 then
    return true
  end

  return IsWinnerToTakeAction(unitsCanInterrupt)
end

function IsWinnerToCC()
  if not UnitExists("target") then
    return false
  end

  local _, playerClassId = C_PlayerInfo.GetClass(PlayerLocation:CreateFromUnit("player"))
  if not HasCCSpell("player", playerClassId) then
    return false
  end

  local units = GetUnitWithSameTarget()
  local unitsCanCC = {}

  for i=1,#units do
    local _, unitClassId = C_PlayerInfo.GetClass(PlayerLocation:CreateFromUnit(units[i]))
    if HasCCSpell(units[i], unitClassId) then
      table.insert(unitsCanCC, units[i])
    end
  end

  if #unitsCanCC == 0 then
    return true
  end

  return IsWinnerToTakeAction(unitsCanCC)
end

local function GetUnitInfoValue(info, key)
  if info[key] ~= nil then
    return info[key]
  end

  unitInfoCacheMissedCount = unitInfoCacheMissedCount + 1
  if key == "role" then
    local role = string.lower(UnitGroupRolesAssigned(info.unit))
    info.role = role
  elseif key == "health" then
    info.health = GetUnitHealPercentage(info.unit)
  elseif key == "hasremovabledebuff" then
    info.hasremovabledebuff = HasRemovableDebuff(info.unit)
  elseif key == "mana" then
    info.mana = UnitPower(info.unit) * 100 / UnitPowerMax(info.unit)
  elseif key == "isdead" then
    info.isdead = UnitIsDead(info.unit) or GetUnitInfoValue(info, "buff:炉脉幻想") ~= nil or GetUnitInfoValue(info, "buff:救赎之魂") ~= nil
  elseif key == "incombat" then
    info.incombat = UnitAffectingCombat(info.unit)
  elseif key == "canattack" then
    info.canattack = UnitCanAttack("player", info.unit)
  elseif key == "canassist" then
    info.canassist = UnitCanAssist("player", info.unit)
  elseif key == "ismoving" then
    info.ismoving = GetUnitSpeed(info.unit) > 0
  elseif key == "resource" then
    -- https://wowpedia.fandom.com/wiki/Enum.PowerType
    -- https://www.wowhead.com/resources
    info.resource = max(UnitPower(info.unit, 4), -- 连击点数，盗贼、猫德
      UnitPower(info.unit, 5),                   -- 符文，DK
      UnitPower(info.unit, 7),                   -- 灵魂碎片，术士
      UnitPower(info.unit, 9),                   -- 神圣能量，圣骑士
      UnitPower(info.unit, 12),                  -- 真气，武僧
      UnitPower(info.unit, 16),                  -- 奥术充能，奥法
      UnitPower(info.unit, 19))                  -- 精华，小龙人
  elseif key == "power" then
    info.power = max(UnitPower(info.unit, 1), -- 怒气，战士、猫德
      UnitPower(info.unit, 2),                -- 集中值，猎人
      UnitPower(info.unit, 3),                -- 能量，盗贼
      UnitPower(info.unit, 6),                -- 符文能量，DK
      UnitPower(info.unit, 8),                -- 星界能量，鸟德
      UnitPower(info.unit, 11),               -- 漩涡，萨满
      UnitPower(info.unit, 13),               -- 狂乱值，暗牧
      UnitPower(info.unit, 17))               -- 恶魔之怒，DH

  elseif key == "casting" or key == "castingleft" or key == "castingpast" then
    local casting, _, _, castingStartTime, castingEndTime = UnitCastingInfo(info.unit)
    info.casting = casting
    info.castingleft = castingEndTime and (castingEndTime/1000 - GetTime()) or 0
    info.castingpast = castingStartTime and (GetTime() - castingStartTime/1000) or 0
  elseif key == "channel" or key == "channelleft" or key == "channelpast" then
    local channel, _, _, channelStartTime, channelEndTime = UnitChannelInfo(info.unit)
    info.channel = channel
    info.channelleft = channelEndTime and (channelEndTime/1000 - GetTime()) or 0
    info.channelpast = channelStartTime and (GetTime() - channelStartTime/1000) or 0
  elseif key == "isfocus" then
    info.isfocus = UnitIsUnit(info.unit, "focus")
  elseif string.sub(key, 1, 4) == "buff" and info.buffcached ~= 1 then
    local buff = GetUnitBuff(info.unit)
    for k,v in pairs(buff) do info[k] = v end
    info.buffcached = 1
  elseif string.sub(key, 1, 6) == "debuff" and info.debuffcached ~= 1 then
    local debuff = GetUnitDebuff(info.unit)
    for k,v in pairs(debuff) do info[k] = v end
    info.debuffcached = 1
  elseif key == "msg" or key == "msgchannel" then
    for i=1,#msgQueue do
      local msg = msgQueue[i]
      if msg.time >= GetTime() - 1 and msg.sender == fullname then
        info["msg"] = msg.msg
        info["msgchannel"] = msg.channel
        break
      end
    end
  elseif key == "def" then
    info.def = HasDefensiveSpell(info.unit, info.classid)
  elseif key == "int" then
    info.int = HasInterruptSpell(info.unit, info.classid)
  elseif key == "intwin" then
    info.intwin = info.unit == "player" and IsWinnerToInterrupt() or false
  elseif key == "ccwin" then
    info.ccwin = info.unit == "player" and IsWinnerToCC() or false
  elseif key == "icon" then
    info.icon = GetRaidTargetIndex(info.unit)
  elseif string.sub(key, 1, 13) == "spellinrange:" then
    local spellName = string.sub(key, 14)
    info[key] = IsSpellInRange(spellName, info.unit) == 1
  else
    unitInfoCacheMissedCount = unitInfoCacheMissedCount - 1
  end

  return info[key]
end

local function UnitIsBoss(unit)
  for i=1,5 do
    if UnitIsUnit(unit, "boss" .. i) then
      return true
    end
  end

  return false
end

local function GetUnitInfo(unit)
  if unit == "target" then
    local unitPrefix = "party"
    local groupSize = 4

    if IsInRaid() then
      unitPrefix = "raid"
      groupSize = 40
    end

    for i=1,groupSize do
      local groupUnit = unitPrefix .. i
      if UnitIsUnit(groupUnit, "target") then
        unit = groupUnit
        break
      end
    end

    if unit == "target" and UnitIsUnit(unit, "player") then
      unit = "player"
    end
  end

  unitInfoCalledCount = unitInfoCalledCount + 1

  if UNIT_CACHE[unit] and nowTime - UNIT_CACHE[unit].cacheTime < CACHE_DURATION then
    return UNIT_CACHE[unit]
  end

  local exists = UnitExists(unit)
  if not exists then
    UNIT_CACHE[unit] = nil
    return nil
  end

  local player = PlayerLocation:CreateFromUnit(unit)
  local name, realm = UnitName(unit)
  local className, classId, class = C_PlayerInfo.GetClass(player)
  local online = UnitIsConnected(unit)
  local fullname = realm == nil and name or name .. "-" .. realm
  local isplayer = playerName == fullname
  local ignore = string.sub(unit, 1, 4) == "raid" and LF_Guardian_WatchRaid[fullname] or LF_Guardian_WatchParty[fullname]

  local info = {
    unit = unit,
    color = classColor[class] or {0.62, 0.62, 0.62},
    class = className,
    classid = classId,
    name = name,
    fullname = fullname,
    online = online,
    ignore = ignore,
    isplayer = isplayer,
    isboss = UnitIsBoss(unit),
    keybinding = keybindings[unit],
    GetValue = GetUnitInfoValue,
    cacheTime = GetTime()
  }

  UNIT_CACHE[unit] = info
  return UNIT_CACHE[unit]
end

local function InitializeTargetButtons()
  local buttonFrame = CreateFrame("Frame", "LifaGuardianButton", UIParent)
  buttonFrame:SetSize(50, 50)
  buttonFrame:SetFrameStrata("BACKGROUND")
  buttonFrame:SetFrameLevel(10000)
  buttonFrame:SetPoint("TOPLEFT", UIParent, -100, 100)

  local MasaicTexture = buttonFrame:CreateTexture(nil, "BACKGROUND")
  MasaicTexture:SetPoint("TOPLEFT", buttonFrame, 0, 0)
  MasaicTexture:SetSize(50, 50)
  MasaicTexture:SetColorTexture(1, 0, 0)
  MasaicTexture:Show()

  for i=1,5 do
    local unit = i == 1 and "player" or "party" .. (i - 1)
    local macro = "/target " .. unit
    local button = CreateFrame("Button", "LFGuardian_" .. unit, buttonFrame, 'SecureActionButtonTemplate')
    button:RegisterForClicks("AnyUp", "AnyDown")
    button:SetAllPoints()
    button:SetAttribute("type1", "macro")
    button:SetAttribute("macrotext", macro)
    SetOverrideBindingClick(buttonFrame, true, keybindings[unit], "LFGuardian_" .. unit)
  end

  for i=1,40 do
    local unit = "raid" .. i
    local macro = "/target " .. unit
    local button = CreateFrame("Button", "LFGuardian_" .. unit, buttonFrame, 'SecureActionButtonTemplate')
    button:RegisterForClicks("AnyUp", "AnyDown")
    button:SetAllPoints()
    button:SetAttribute("type1", "macro")
    button:SetAttribute("macrotext", macro)
    SetOverrideBindingClick(buttonFrame, true, keybindings[unit], "LFGuardian_" .. unit)
  end
end

local watchTop = -16
local watchTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
watchTitle:SetPoint("TOPLEFT", 16, watchTop)
watchTitle:SetText("守护目标")

local watchPartyTop = -8
local watchPartyTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
watchPartyTitle:SetTextColor(0.67, 0.67, 1, 1)
watchPartyTitle:SetPoint("TOPLEFT", watchTitle, "BOTTOMLEFT", 0, watchPartyTop)
watchPartyTitle:SetText("小队目标")

local watchRaidTop = -40
local watchRaidTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
watchRaidTitle:SetTextColor(1, 0.5, 0, 1)
watchRaidTitle:SetPoint("TOPLEFT", watchPartyTitle, "BOTTOMLEFT", 0, watchRaidTop)
watchRaidTitle:SetText("团队目标")

local profileTop = -416
local profileTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
profileTitle:SetPoint("TOPLEFT", 16, profileTop)
profileTitle:SetText("守护规则")

local profileFrameTop = -8
local profileFrame = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
profileFrame:SetSize(550, 100)
profileFrame:SetPoint("TOPLEFT", profileTitle, "BOTTOMLEFT", 0, profileFrameTop)

local profileEditBox = CreateFrame("EditBox", nil, profileFrame)
profileEditBox:SetMultiLine(true)
profileEditBox:SetAutoFocus(false)
profileEditBox:SetFontObject(ChatFontNormal)
profileEditBox:SetWidth(525)
profileEditBox:SetScript("OnTextChanged", function(_, userInput)
  if not userInput then return end
  local specialization = GetSpecialization()
  LF_Guardian_Specialization_Profile[specialization] = profileEditBox:GetText()
end)

profileFrame:SetScrollChild(profileEditBox)

local partyCheckButtons = {}
local raidCheckButtons = {}

local function IsHealer()
  local player = PlayerLocation:CreateFromUnit("player")
  local _, _, class = C_PlayerInfo.GetClass(player)
  local specialization = GetSpecialization()

  if class == 2 and specialization == 1
    or class == 5 and specialization == 1
    or class == 5 and specialization == 2
    or class == 7 and specialization == 3
    or class == 10 and specialization == 2
    or class == 11 and specialization == 4 
    or class == 13 and specialization == 2 then
    return true
  end

  return false
end

local function UpdateProfileUI()
  local specialization = GetSpecialization()

  local profile = LF_Guardian_Specialization_Profile[specialization] or LF_Guardian_Profile
  if profile == nil then
    if IsHealer() then
      LF_Guardian_Specialization_Profile[specialization] = defaultProfile
    else
      LF_Guardian_Specialization_Profile[specialization] = defaultDpsProfile
    end
  elseif LF_Guardian_Specialization_Profile[specialization] == nil then
    if IsHealer() then
      LF_Guardian_Specialization_Profile[specialization] = LF_Guardian_Profile
    else
      LF_Guardian_Specialization_Profile[specialization] = defaultDpsProfile
    end
  end

  -- LF_Guardian_Profile = nil
  profile = LF_Guardian_Specialization_Profile[specialization]

  profileEditBox:SetText(profile)
end

local function StringSplit(inputstr, sep)
  if sep == nil then
    sep = "%s"
  end

  local t={}

  for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
    table.insert(t, str)
  end

  return t
end

function Trim(s)
  return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function GetStrWidth(str)
  local realByteCount = #str
  local length = 0
  local curBytePos = 1

  while(true) do
    local step = 1
    local byteVal = string.byte(str, curBytePos)
    if byteVal > 239 then
      step = 4
    elseif byteVal > 223 then
      step = 3
    elseif byteVal > 191 then
      step = 2
    else
      step = 1
    end
    curBytePos = curBytePos + step
    length = length + (step == 1 and 1 or 2)
    if curBytePos > realByteCount then
      break
    end
  end
  return length
end

local function CutString(str, maxWidth)
  local realByteCount = #str
  local length = 0
  local curBytePos = 1
  local endPos = 1
  local step = 1

  while(true) do
    local byteVal = string.byte(str, curBytePos)
    if byteVal > 239 then
      step = 4
    elseif byteVal > 223 then
      step = 3
    elseif byteVal > 191 then
      step = 2
    else
      step = 1
    end
    
    curBytePos = curBytePos + step
    length = length + (step == 1 and 1 or 2)
    if length > maxWidth then
      break
    end

    endPos = curBytePos - 1

    if curBytePos > realByteCount then
      break
    end
  end
  
  local newStr = endPos == 1 and step > 1 and "" or string.sub(str, 1, endPos)
  return #str == #newStr and str or newStr .. "..."
end

local function GetDisplayName(name)
  if GetStrWidth(name) > 10 then
    name = CutString(name, 9)
  end

  return name
end

local function UpdateCheckbox(index, checked, playerInfo, checkButton)
  if playerInfo == nil then
    checkButton:SetChecked(false)
    checkButton.Text:SetText("<未指定>")
    checkButton.tooltipText = "<未指定>"
    checkButton.Text:SetTextColor(0.62, 0.62, 0.62, 1)
    checkButton:Disable()
  else
    local role = CreateAtlasMarkup("roleicon-tiny-dps")
    if playerInfo.role == "tank" then
      role = CreateAtlasMarkup("roleicon-tiny-tank")
    elseif playerInfo.role == "healer" then
      role = CreateAtlasMarkup("roleicon-tiny-healer")
    end

    if playerInfo.online then
      checkButton:SetChecked(checked)
      checkButton.Text:SetTextColor(playerInfo.color[1], playerInfo.color[2], playerInfo.color[3], 1)
      checkButton:Enable()
    else
      checkButton:SetChecked(false)
      checkButton.Text:SetTextColor(0.62, 0.62, 0.62, 1)
      checkButton:Disable()
    end
    
    checkButton.Text:SetText(role .. " " .. GetDisplayName(playerInfo.name))
    checkButton.tooltipText = playerInfo.name
  end
end

local function PartyCheckBoxOnClick(party)
  local i = party.partyIndex
  local unit = "player"

  if i > 1 then
    unit = "party" .. (i - 1)
  end

  local playInfo = GetUnitInfo(unit)
  local fullname = playInfo.fullname
  
  if party:GetChecked() then
    LF_Guardian_WatchParty[fullname] = nil
  else
    LF_Guardian_WatchParty[fullname] = true
  end
end

local function RaidCheckBoxOnClick(raid)
  local i = raid.raidIndex
  local unit = "raid" .. i

  local playInfo = GetUnitInfo(unit)
  local fullname = playInfo.fullname
  
  if raid:GetChecked() then
    LF_Guardian_WatchParty[fullname] = nil
  else
    LF_Guardian_WatchParty[fullname] = true
  end
end

local function UpdateParty()
  local isInParty = IsInGroup()
  for i=1,5 do
    local playerInfo
    if not isInParty then
      playerInfo = nil
    else
      local unit = i == 1 and "player" or "party" .. (i - 1)
      playerInfo = GetUnitInfo(unit)
    end

    local checked = playerInfo and not playerInfo.ignore or false

    UpdateCheckbox(i, checked, playerInfo, partyCheckButtons[i])
  end
end

local function InitializePartyCheckButtons()
  for i=1,5 do
    partyCheckButtons[i] = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
    partyCheckButtons[i]:SetScript("OnClick", PartyCheckBoxOnClick)
    partyCheckButtons[i].partyIndex = i
    partyCheckButtons[i]:SetPoint("TOPLEFT", watchPartyTitle, "BOTTOMLEFT", (i - 1) * 120, -8)
  end

  UpdateParty()
end

local function UpdateRaid()
  local isInRaid = IsInRaid()
  for i=1,8 do
    for j=1,5 do
      local playerInfo
      if not isInRaid then
        playerInfo = nil
      else
        local unit = "raid" .. ((i - 1) * 5 + j)
        playerInfo = GetUnitInfo(unit)
      end

      local checked = playerInfo and not playerInfo.ignore or false

      UpdateCheckbox((i - 1) * 5 + j, checked, playerInfo, raidCheckButtons[(i - 1) * 5 + j])
    end
  end
end

local function InitializeRaidCheckButtons()
  for i=1,8 do
    for j=1,5 do
      raidCheckButtons[(i - 1) * 5 + j] = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
      raidCheckButtons[(i - 1) * 5 + j]:SetScript("OnClick", RaidCheckBoxOnClick)
      raidCheckButtons[(i - 1) * 5 + j].raidIndex = i
      raidCheckButtons[(i - 1) * 5 + j]:SetPoint("TOPLEFT", watchRaidTitle, "BOTTOMLEFT", (j - 1) * 120, -8 - 36 * (i - 1))
    end
  end

  UpdateRaid()
end

local function GetPlayerRaidUnit()
  for i=1,40 do
    local unitInfo = GetUnitInfo("raid" .. i)
    if unitInfo.fullname == playerName then
      return "raid" .. i
    end
  end
end

local function GetAvailableUnits()
  local groupSize = GetNumGroupMembers()
  local unitPrefix = "party"

  local units = {}

  if IsInRaid() then
    unitPrefix = "raid"
    groupSize = 40
  elseif IsInGroup() then
    groupSize = groupSize - 1
    table.insert(units, GetUnitInfo("player"))
  else
    table.insert(units, GetUnitInfo("player"))
  end

  for i=1,groupSize do
    local unit = unitPrefix .. i
    local info = GetUnitInfo(unit)

    if info ~= nil then
      local inRange, checkedRange = UnitInRange(unit)

      if info and not info.ignore and info.online and inRange and checkedRange then
        table.insert(units, info)
      end
    end
  end

  return units
end

local function GetAllEnemies()
  local items = {}

  for unit,_ in pairs(CACHED_NAME_PLATE_UNITS) do
    table.insert(items, GetUnitInfo(unit))
  end

  return items
end

local function SmartTypeParse(value)
  local numberValue = tonumber(value)
  local booleanValue = nil
  if value == "true" then
    booleanValue = true
  elseif value == "false" then
    booleanValue = false
  end

  if numberValue ~= nil then
    return numberValue
  elseif booleanValue ~= nil then
    return booleanValue
  end

  if value == "nil" then
    return nil
  end

  return value
end

local function GetNonNullableValue(item, key)
  local value = item[key]

  if value == nil and item.GetValue ~= nil then
    value = item.GetValue(item, key)
  end

  if value == nil then
    return 0
  end
  
  return value
end

local function GetMinValueItem(items, key)
  local minValue = nil
  local item = nil

  for i=1,#items do
    if minValue == nil or GetNonNullableValue(items[i], key) < minValue then
      item = items[i]
      minValue = GetNonNullableValue(items[i], key)
    end
  end
  return item
end

local function GetMaxValueItem(items, key)
  local maxValue = nil
  local item = nil

  for i=1,#items do
    if maxValue == nil or GetNonNullableValue(items[i], key) > maxValue then
      item = items[i]
      maxValue = GetNonNullableValue(items[i], key)
    end
  end

  return item
end

local function GetValueLessThanItems(items, key, value)
  local filteredItems = {}

  if key == count then
    local allUnits = GetAvailableUnits()
    if items ~= nil and #item < value or #allUnits == #item then
      return items
    end

    return {}
  end

  for i=1,#items do
    if GetNonNullableValue(items[i], key) < value then
      table.insert(filteredItems, items[i])
    end
  end

  return filteredItems
end

local function GetValueGreaterThanItems(items, key, value)
  local filteredItems = {}

  if key == count then
    if items ~= nil and #item > value then
      return items
    end

    return {}
  end

  for i=1,#items do
    if GetNonNullableValue(items[i], key) > value then
      table.insert(filteredItems, items[i])
    end
  end

  return filteredItems
end

local function ParseFilter(filter)
  local operator = "="

  if string.find(filter, "=") then
    operator = "="
  elseif string.find(filter, "~") then
    operator = "~"
  elseif string.find(filter, "<") then
    operator = "<"
  elseif string.find(filter, ">") then
    operator = ">"
  end

  local str = StringSplit(filter, operator)
  local key = StringSplit(str[1], ".")

  local value = str[2]
  if string.sub(value, 1, 4) == "var:" and string.len(value) > 4 then
    value = LFG_VAR[string.sub(value, 5)]
  end
  value = SmartTypeParse(value)

  local object = L[key[1]] or key[1]
  local propertyComponent = StringSplit(key[2], ":")
  local property = L[propertyComponent[1]] or propertyComponent[1]
  if #propertyComponent > 1 then
    property = property .. ":" .. propertyComponent[2]
  end

  return {
    object = object,
    property = property,
    operator = operator,
    value = value
  }
end

local function GetMsgFilterUnits(items, msg, channel)
  for i=1,#items do
    if msgExists(tostring(msg), items[i].fullname, channel) then
      return { items[i] }
    end
  end

  return {}
end

local function GetFilteredItem(items, filter)
  if filter.value == "min" then
    local item = GetMinValueItem(items, filter.property)
    return { item }
  end

  if filter.value == "max" then
    local item = GetMaxValueItem(items, filter.property)
    return { item }
  end

  if filter.operator == "<" then
    return GetValueLessThanItems(items, filter.property, filter.value)
  end

  if filter.operator == ">" then
    return GetValueGreaterThanItems(items, filter.property, filter.value)
  end

  if filter.property == count then
    if filter.operator == "=" and #items == count
        or filter.operator == "~" and #items ~= count then
      return items
    else
      return {}
    end
  end

  if filter.property == "msg" and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "any")
  end

  if filter.property == "msg_group" and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "group")
  end

  if (filter.property == "msg_raid" or filter.property == "msg_i") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "raid")
  end

  if (filter.property == "msg_party" or filter.property == "msg_p") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "party")
  end

  if (filter.property == "msg_guild" or filter.property == "msg_g") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "guild")
  end

  if (filter.property == "msg_whisper" or filter.property == "msg_w") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "whisper")
  end

  if (filter.property == "msg_say" or filter.property == "msg_s") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "say")
  end

  if (filter.property == "msg_yell" or filter.property == "msg_y") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "yell")
  end

  local filteredItems = {}

  for i=1,#items do
    if filter.operator == "=" and GetNonNullableValue(items[i], filter.property) == filter.value
        or filter.operator == "~" and GetNonNullableValue(items[i], filter.property) ~= filter.value then
      table.insert(filteredItems, items[i])
    end
  end

  return filteredItems
end

local function GetFilteredUnit(unit, filter)
  local player = GetUnitInfo(unit)
  local items = { player }
  local filteredPlayer = GetFilteredItem(items, filter)

  if #filteredPlayer == 0 then
    return nil
  else
    return filteredPlayer[1]
  end
end

local function GetAllFilteredUnits(filter)
  if filter.property == "count" then
    local filterUnitCount = #filteredUnits
    filteredUnits = GetAvailableUnits()

    if filter.operator == "=" and filterUnitCount == filter.value
        or filter.operator == "~" and filterUnitCount ~= filter.value
        or filter.operator == "<" and filterUnitCount < filter.value
        or filter.operator == ">" and filterUnitCount > filter.value then
      return true
    end
    
    return nil
  end

  filteredUnits = GetFilteredItem(filteredUnits, filter)
  return filteredUnits
end

local function GetFilteredDBM(filter)
  local spellIdOrName = nil
  local text = nil

  if string.sub(filter.property, 1, 6) == "spell:" then
    spellIdOrName = string.sub(filter.property, 7)
  elseif string.sub(filter.property, 1, 5) == "text:" then
    text = string.sub(filter.property, 6)
  end

  if spellIdOrName or text then
    for k,v in pairs(DBM_TIMER) do
      if spellIdOrName ~= nil and (tostring(v.spellId) == spellIdOrName or v.spellName == spellIdOrName)
          or text ~= nil and v.text == text then
        local leftTime = ceil((v.expirationTime - GetTime()) * 10) / 10

        if leftTime >= 0 then
          if filter.operator == "=" and leftTime == filter.value
            or filter.operator == "~" and leftTime ~= filter.value
            or filter.operator == "<" and leftTime < filter.value
            or filter.operator == ">" and leftTime > filter.value then
            return true
          end
        end
      end
    end
  end

  return nil
end

local function GetAllFilteredEnemies(filter)
  if filter.property == "count" then
    local filteredEnemyCount = #filteredEnemies
    filteredEnemies = GetAllEnemies()

    if filter.operator == "=" and filteredEnemyCount == filter.value
        or filter.operator == "~" and filteredEnemyCount ~= filter.value
        or filter.operator == "<" and filteredEnemyCount < filter.value
        or filter.operator == ">" and filteredEnemyCount > filter.value then
      return true
    end
    
    return nil
  end

  filteredEnemies = GetFilteredItem(filteredEnemies, filter)
  return filteredEnemies
end

local function GetAllFilteredHekili(filter)
  local recomendation = Hekili and Hekili.DisplayPool.Primary and Hekili.DisplayPool.Primary.Recommendations[1]

  if recomendation then
    recomendation.spell = GetSpellInfo(recomendation.actionID);
    recomendation.spellid = recomendation.actionID;
    recomendation.key = recomendation.keybind;
    recomendation.targetswap = recomendation.indicator == "cycle"
    recomendation.enemycount = recomendation.caption
  end

  local items = { recomendation }

  local filteredHekili = GetFilteredItem(items, filter)
  if #filteredHekili == 0 then
    return nil
  else
    return filteredHekili[1]
  end
end

local function GetAllFilteredVar(filter)
  local items = { LFG_VAR }
  local filteredVar = GetFilteredItem(items, filter)
  if #filteredVar == 0 then
    return nil
  else
    return filteredVar[1]
  end
end

local function GetFilteredPlayer(filter)
  return GetFilteredUnit("player", filter)
end

local function GetFilteredTarget(filter)
  return GetFilteredUnit("target", filter)
end

local function GetFilteredTargettarget(filter)
  return GetFilteredUnit("targettarget", filter)
end

local function GetFilteredMouseover(filter)
  return GetFilteredUnit("mouseover", filter)
end

local function GetFilteredFocus(filter)
  return GetFilteredUnit("focus", filter)
end

local function IsSpellReady(spellName)
  local _, duration = GetSpellCooldown(spellName)
  if duration == nil then
    return false
  end

  local _, gcdDuration = GetSpellCooldown(61304)
  local castable =(duration - gcdDuration) <= 0

  return castable
end

local function GetFilteredSpell(filter)
  local _, duration = GetSpellCooldown(filter.property)
  local _, gcdDuration = GetSpellCooldown(61304)
  local useable = IsUsableSpell(filter.property)
  local castable = useable and ((duration - gcdDuration) <= 0 and not IsHealer() or duration == 0 and IsHealer())
  local inRange = IsSpellInRange(filter.property, "target") ~= 0
  local channelingSpell, _, _, _, _, _, _, channelingspellId, _, totalStage = UnitChannelInfo("player")
  local isChanneling = totalStage and (filter.property == channelingspellId or filter.property == channelingSpell)

  if filter.value == nil then
    if not useable and filter.operator == "=" or useable and filter.operator == "~" then
      return { filter.property }
    else
      return nil
    end
  end

  if( castable and inRange or isChanneling) and filter.value or not (castable or isChanneling) and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  return nil
end

local function GetFilteredKnownSpell(filter)
  local equal = filter.value == IsPlayerSpell(filter.property)

  if filter.operator == "=" and equal or filter.operator == "~" and not equal then
    return { filter.property }
  end

  return nil
end

local function GetItemId(itemName)
  for bag=0,NUM_BAG_SLOTS do
    for slot=1,C_Container.GetContainerNumSlots(bag) do
      local link = C_Container.GetContainerItemLink(bag, slot)
      if link ~= nil and GetItemInfo(link) == itemName then
          return C_Container.GetContainerItemID(bag, slot)
      end
    end
  end
  return nil
end

local function GetFilteredContainerItem(filter)
  local id = GetItemId(filter.property)
  if id == nil and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  local spellName, spellId = GetItemSpell(id)

  if spellId == nil then
    if filter.operator == "=" then
      return not filter.value and { filter.property } or nil
    else
      return filter.value and { filter.property } or nil
    end
  end

  local _, duration = GetSpellCooldown(spellId)

  local useable = IsUsableSpell(spellId) and duration == 0
  if useable and filter.value or not useable and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  return nil
end

local function GetTrinketInfo(slot)
  local id = GetInventoryItemID("player", slot)
  if id == nil then
    return nil, nil
  end

  local name = GetItemInfo(id)
  return name, id
end

local function GetFilteredTrinket(filter)
  local name13, id13 = GetTrinketInfo(13)
  local name14, id14 = GetTrinketInfo(14)

  if name13 ~= filter.property and name14 ~= filter.property and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  if name13 ~= filter.property and name14 ~= filter.property and filter.value then
    if filter.operator == "=" then
      return nil
    else
      return { filter.property }
    end
  end

  local id = name13 == filter.property and id13 or id14
  local _, duration, enable = GetItemCooldown(id)

  local useable = enable and duration == 0
  if useable and filter.value or not useable and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  return nil
end

local function GetFilteredTotem(filter)
  local totems, i, now = { }, 1, GetTime()
  local _, totem, start, duration = GetTotemInfo(i)
  
  while totem and totem ~= "" do
    totems[totem] = floor(start + duration - now)
    i = i + 1
    _, totem, start, duration = GetTotemInfo(i)
  end

  local filteredTotems = GetFilteredItem({ totems }, filter)

  if #filteredTotems == 0 then
    return nil
  else
    return true
  end
end

local function GetFilteredGroup(filter)
  if filter.property ~= "type" then
    return nil
  end

  local isInRaid = IsInRaid()
  local isInGroup = IsInGroup()

  if filter.operator == "=" and filter.value == "raid" and isInRaid
      or filter.operator == "~" and filter.value == "raid" and not isInRaid
      or filter.operator == "=" and filter.value == "party" and not isInRaid and isInGroup
      or filter.operator == "~" and filter.value == "party" and (isInRaid or not isInGroup) then
    return true
  end

  return nil
end

local function GetFilteredInstance(filter)
  if filter.property ~= "type" then
    return nil
  end

  local _, instanceType = IsInInstance()

  if filter.operator == "=" and filter.value == instanceType
      or filter.operator == "~" and filter.value ~= instanceType then
    return true
  end

  return nil
end

local function GetGeneralFiltered(filter)
  if filter.object == "player" and GetFilteredPlayer(filter) == nil then
    return false
  end

  if filter.object == "target" and GetFilteredTarget(filter) == nil then
    return false
  end

  if filter.object == "targettarget" and GetFilteredTargettarget(filter) == nil then
    return false
  end

  if filter.object == "mouseover" and GetFilteredMouseover(filter) == nil then
    return false
  end

  if filter.object == "focus" and GetFilteredFocus(filter) == nil then
    return false
  end

  if filter.object == "spell" and GetFilteredSpell(filter) == nil then
    return false
  end

  if filter.object == "knownspell" and GetFilteredKnownSpell(filter) == nil then
    return false
  end

  if filter.object == "item" and GetFilteredContainerItem(filter) == nil then
    return false
  end

  if (filter.object == "trinket" or filter.object == "sp") and GetFilteredTrinket(filter) == nil then
    return false
  end

  if filter.object == "totem" and GetFilteredTotem(filter) == nil then
    return false
  end

  if filter.object == "units" and GetAllFilteredUnits(filter) == nil then
    return false
  end

  if filter.object == "group" and GetFilteredGroup(filter) == nil then
    return false
  end

  if filter.object == "instance" and GetFilteredInstance(filter) == nil then
    return false
  end

  if filter.object == "dbm" and GetFilteredDBM(filter) == nil then
    return false
  end

  if filter.object == "enemies" and GetAllFilteredEnemies(filter) == nil then
    return false
  end

  if filter.object == "hekili" and GetAllFilteredHekili(filter) == nil then
    return false
  end

  if filter.object == "var" and GetAllFilteredVar(filter) == nil then
    return false
  end

  return true
end

local function GetFilteredActions(actions, filter)
  if not GetGeneralFiltered(filter) then
    -- Current line has shown successfully, move to the next line
    if SUCCEED_LINE == CURRENT_LINE and CURRENT_QUEUE_LINE == CURRENT_LINE then
      CURRENT_QUEUE_LINE = CURRENT_LINE + 1
    -- Skip the current line if it has failed, but continue the current queue
    elseif CURRENT_QUEUE_TYPE == "skip" and CURRENT_QUEUE_LINE == CURRENT_LINE then
      CURRENT_QUEUE_LINE = CURRENT_LINE + 1
    -- Hold here. Any change at this moment should be reset
    elseif CURRENT_QUEUE_TYPE == "hold" and CURRENT_QUEUE_LINE == CURRENT_LINE then
      -- Hold mode queue header failed, ignore the queue
      if CURRENT_QUEUE_START == CURRENT_LINE then
        CURRENT_QUEUE_LINE = nil
        CURRENT_QUEUE_TYPE = nil
        CURRENT_QUEUE_START = nil

        return {}
      end
      return {
        { key = nil }
      }
    -- Reset the queue pos and type since we want to break the current queue
    elseif CURRENT_QUEUE_TYPE == "break" and CURRENT_QUEUE_LINE == CURRENT_LINE then
      CURRENT_QUEUE_LINE = nil
      CURRENT_QUEUE_TYPE = nil
      CURRENT_QUEUE_START = nil
    end

    return {}
  end

  if filter.object == "action" and filter.property == "key" then
    if (filter.value == "hekili" or filter.value == "Hekili" or filter.value == "HEKILI") and
      not (Hekili and Hekili.DisplayPool.Primary and Hekili.DisplayPool.Primary.Recommendations[1]
        and Hekili.DisplayPool.Primary.Recommendations[1].keybind) then
      return actions
    end
    
    table.insert(actions, { key = filter.value })
  end

  if filter.object == "action" and filter.property == "queue" then
    -- Skip previous queue item before current queue ends
    if CURRENT_QUEUE_LINE ~= nil and CURRENT_QUEUE_LINE > CURRENT_LINE then
      return {}
    -- First queue header
    elseif CURRENT_QUEUE_LINE == nil and (filter.value == "skip" or filter.value == "hold" or filter.value == "break") then
      CURRENT_QUEUE_LINE = CURRENT_LINE
      CURRENT_QUEUE_START = CURRENT_LINE
      CURRENT_QUEUE_TYPE = filter.value
    -- Skip remaining queue items if queue pos reset (break mode)
    elseif filter.value == true and CURRENT_QUEUE_LINE == nil then
      CURRENT_QUEUE_LINE = nil
      CURRENT_QUEUE_TYPE = nil
      CURRENT_QUEUE_START = nil
      return {}
    end
  end

  return actions
end

local function GetFilteredHekiliOptions(options, filter)
  if filter.object == "hekili" then
    table.insert(options, { spell = filter.property, enabled = filter.value })
  elseif not GetGeneralFiltered(filter) then
    return {}
  end

  return options
end

local function GetFilteredAlarms(alarms, filter)
  if not GetGeneralFiltered(filter) then
    return {}
  end

  if filter.object == "alarm" and filter.property == "sound" then
    table.insert(alarms, { sound = filter.value })
  end

  return alarms
end

local function GetKeyDefinitions(definitions, filter)
  if filter.object == "key" then
    definitions[filter.property] = filter.value
  end

  return definitions
end

local function GetFilteredUnits(units, filter)
  if not GetGeneralFiltered(filter) then
    return {}
  end

  if filter.object == "unit" then
    return GetFilteredItem(units, filter)
  else
    return units
  end
end

local function GetFilteredEnemies(units, filter)
  if not GetGeneralFiltered(filter) then
    return {}
  end

  if filter.object == "enemy" then
    return GetFilteredItem(units, filter)
  else
    return units
  end
end

local function GetFilteredItems(command, items, filter)
  if command == "unit" then
    return GetFilteredUnits(items, filter)
  end

  if command == "enemy" then
    return GetFilteredEnemies(items, filter)
  end

  if command == "action" then
    return GetFilteredActions(items, filter)
  end

  if command == "alarm" then
    return GetFilteredAlarms(items, filter)
  end

  if command == "key" then
    return GetKeyDefinitions(items, filter)
  end

  if command == "hekili" then
    return GetFilteredHekiliOptions(items, filter)
  end

  return {}
end

local function LineParse(line, context, filteredCommand)
  local args = StringSplit(line, ",")
  local command = L[args[1]] or args[1]

  if filteredCommand ~= nil and command ~= filteredCommand and not (filteredCommand == "action" and command == "key") then
    return nil
  end

  if command == "action" then
    CURRENT_LINE = CURRENT_LINE + 1
  end

  local items = {}
  filteredUnits = GetAvailableUnits()
  filteredEnemies = GetAllEnemies()

  if command ~= "key" and context[command] ~= nil then
    return nil
  end

  if command == "key" then
    items = context[command] or {}
  end

  if command == "unit" then
    items = GetAvailableUnits()
  end

  if command == "enemy" then
    items = GetAllEnemies()
  end

  local queueAction = false

  for i=2,#args do
    local tempItems = {}
    local _args = StringSplit(args[i], "|")
    for j=1,#_args do
      local filter = ParseFilter(_args[j])
      if command == "action" and filter.object == "action" and filter.property == "queue" then
        queueAction = true
      end

      local _items = GetFilteredItems(command, items, filter)

      for k,v in pairs(_items) do
        if command == "key" then
          tempItems[k] = v
        else
          table.insert(tempItems, v)
        end
      end
    end
    items = tempItems

    if #items == 0 and command ~= "key" then
      -- if LFGDEBUG and DLAPI then DLAPI.DebugLog("LifaGuardian", "[失败]" .. line .. ' 不满足条件 ' .. args[i]) end
      args[i] = "|cFFFF0000" .. args[i] .. "|r"
      return table.concat(args, ",")
    end
  end

  if #items > 0 and command ~= "enemy" and command ~= "hekili" then
    context[command] = items[1]

    if command == "action" and items[1].key ~= nil then
      SUCCEED_LINE = CURRENT_LINE
    end

    if command == "action" and CURRENT_QUEUE_LINE ~= nil and CURRENT_QUEUE_LINE <= CURRENT_LINE and not queueAction then
      CURRENT_QUEUE_TYPE = nil
      CURRENT_QUEUE_LINE = nil
      CURRENT_QUEUE_START = nil
    end

    -- if LFGDEBUG and DLAPI then DLAPI.DebugLog("LifaGuardian", "[成功] " .. line) end
    return "|cFF00FF00" .. line .. "|r"
  elseif command == "key" or command == "enemy" or command == "hekili" then
    context[command] = items
  end

  return nil
end

local function GetKey(key, context)
  if key == nil then
    return nil
  end

  local keybindMap = context and context.key or KEY_BIND_CACHE

  if keybindMap and keybindMap[key] then
    return keybindMap[key]
  end

  local spellKey = Hekili and Hekili.Class.abilities[key] and Hekili.Class.abilities[key].key

  if spellKey and Hekili.KeybindInfo[spellKey] then
    local info = Hekili.KeybindInfo[spellKey].upper

    for _, v in pairs(info) do
      if v ~= nil then
          return v
      end
    end
  end

  return key
end

local function MergeAstrologerSubscriptions(rule)
  if not LFA or not LFA.Rules then
    return rule
  end

  local defaultPositionSubscriptions = {}

  for name,subscriptionRule in pairs(LFA.Rules) do
    if string.find(rule, "#"..name.."#") then
      rule = string.gsub(rule, "#"..name.."#", subscriptionRule)
    else
      table.insert(defaultPositionSubscriptions, subscriptionRule)
    end
  end

  if #defaultPositionSubscriptions > 0 then
    rule = table.concat(defaultPositionSubscriptions, "\n") .. "\n" .. rule
  end

  return rule
end

local function RuleParse(rule, filteredCommand)
  if filteredCommand ~= "hekili" then
    rule = MergeAstrologerSubscriptions(rule)
  end

  local lines = StringSplit(rule, "\n")
  local context = {}
  local operations = {}
  CURRENT_LINE = 0

  for i=1,#lines do
    local str = Trim(lines[i])
    if str ~= "" then
      local operationRes = LineParse(str, context, filteredCommand)
      if filteredCommand == "action" and operationRes ~= nil then
        table.insert(operations, operationRes)
      end
    end
  end

  if context.key then
    KEY_BIND_CACHE = context.key
  end

  if context.action ~= nil then
    if type(context.action.key) == "number" then
      context.action.key = tostring(context.action.key)
    end
    if context.action.key == "hekili" or context.action.key == "Hekili" or context.action.key == "HEKILI" then
      context.action.key = Hekili.DisplayPool.Primary.Recommendations[1].keybind
    elseif context.action.key ~= nil then
      local key, stage = strsplit(":", context.action.key)
      context.action.key = GetKey(key, context)
      context.action.stage = stage
    else
      context.action = nil
    end
    OPERATIONS = operations
  end

  return context
end

local function GetRecommendation(filteredCommand)
  local specialization = GetSpecialization()
  nowTime = GetTime()
  local context = RuleParse(LF_Guardian_Specialization_Profile and LF_Guardian_Specialization_Profile[specialization] or LF_Guardian_Profile, filteredCommand)
  return context
end

local function GetRecommendationTarget()
  local context = GetRecommendation("unit")
  return context.unit
end

local function GetRecommendationEnemy()
  local context = GetRecommendation("enemy")
  return context.enemy
end

local function GetRecommendationAction()
  local context = GetRecommendation("action")
  
  if NEXT_KEY_OVERRIDE ~= nil and NEXT_KEY_OVERRIDE.spellName ~= nil and NEXT_KEY_OVERRIDE.key ~= nil then
    if GetTime() - NEXT_KEY_OVERRIDE.time > nextKeyOverrideTimeout or not IsSpellReady(NEXT_KEY_OVERRIDE.spellName) then
      NEXT_KEY_OVERRIDE = {}
    else
      context.action = {
        key = GetKey(NEXT_KEY_OVERRIDE.key, context)
      }
    end
  end
  
  return context.action
end

local function GetRecommendationAlarm()
  local context = GetRecommendation("alarm")
  return context.alarm
end

local function GetRecommendationHekiliOptions()
  local context = GetRecommendation("hekili")
  return context.hekili
end

local function getPlayerChannelStage(startTime, totalStage)
  local lastFinish = 0
  for i=2,totalStage do
    startTime = startTime + GetUnitEmpowerStageDuration("player", i - 2)
    if GetTime() * 1000 < startTime + 500 then
      return i  - 1
    end
  end

  return totalStage
end

local function ShowKeyInfo(key, stage)
  local cSpell, _, _, startTime, _, _, _, spellId, _, totalStage = UnitChannelInfo("player")

  if cSpell and spellId ~= 115175 and spellId ~= 15407 and (not totalStage or (not stage or getPlayerChannelStage(startTime, totalStage) < stage)) then
    LFMUC("")
    return
  end

  local info=(UnitGUID("player") and C_BattleNet.GetAccountInfoByGUID(UnitGUID("player")) or nil)
  LFMUC("key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404") .. ":key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404") .. ":key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404"))
end

local function GetNextRecomendationTarget()
  if not LFGRTDISABLED and LFHENABLED and GetTime() - lastChangeTargetTime > changeTargetTimeCooldown then
    recomendedEnemy = GetRecommendationEnemy()
    if recomendedEnemy ~= nil then
      local recomendedEnemyIsCurrentTarget = false
      for i=1,#recomendedEnemy do
        if UnitIsUnit(recomendedEnemy[i].unit, "target") then
          recomendedEnemyIsCurrentTarget = true;
          recomendedUnit = nil
          break;
        end
      end

      if not recomendedEnemyIsCurrentTarget then
        ShowKeyInfo(keybindings["nextEnemy"])
      end
      
      C_Timer.After(frameDuration, GetNextRecomendationTarget)
      return
    end

    recomendedUnit = GetRecommendationTarget()
    if recomendedUnit == nil then
      C_Timer.After(frameDuration, GetNextRecomendationTarget)
      return
    end
    
    local currentUnitInfo = GetUnitInfo("target")

    if not (recomendedUnit and currentUnitInfo and recomendedUnit.fullname == currentUnitInfo.fullname) then
      local key = keybindings[recomendedUnit.unit]:gsub("ALT", "A"):gsub("CTRL", "C"):gsub("SHIFT", "S"):gsub("NUMPAD", "N"):gsub("-", "")
      ShowKeyInfo(key)
    end
  end

  C_Timer.After(frameDuration, GetNextRecomendationTarget)
end

local function GetNextRecomendationAction()
  if LFHENABLED then
    local action = GetRecommendationAction()
    local currentUnitInfo = GetUnitInfo("target")
    
    if LFGRTDISABLED or not recomendedUnit or (recomendedUnit and currentUnitInfo and recomendedUnit.fullname == currentUnitInfo.fullname) then
      if action == nil then
        LFMUC("")
      else
        local key = action.key
        local stage = action.stage and tonumber(action.stage)
        ShowKeyInfo(key, stage)
      end
    end
  end

  C_Timer.After(frameDuration, GetNextRecomendationAction)
end

local function GetNextRecomendationAlarm()
  if LFHENABLED then
    local alarm = GetRecommendationAlarm()
    if alarm == nil then
      lastSoundPlayedTime = 0

      if soundHandle ~= nil then
        StopSound(soundHandle)
        soundHandle = nil
      end
    elseif alarm ~= nil and wasounds[alarm.sound] ~= nil then
      if (GetTime() - lastSoundPlayedTime) >= soundRepeatDuration then
        lastSoundPlayedTime = GetTime()
        soundHandler = PlaySoundFile(wasounds[alarm.sound], "Master")
      end
    end
  end

  C_Timer.After(frameDuration, GetNextRecomendationAlarm)
end

local function GetNextRecomendationHekiliOptions()
  local options = GetRecommendationHekiliOptions()

  if options ~= nil then
    for i=1,#options do
      if options[i].enabled then
        LFGHEKILISPELLENABLE(options[i].spell)
      else
        LFGHEKILISPELLDISABLE(options[i].spell)
      end
    end
  end

  C_Timer.After(frameDuration, GetNextRecomendationHekiliOptions)
end

local function UpdateGroup()
  UpdateParty()
  UpdateRaid()
end

function msgQueueHandler(msg, sender, channel)
  local now = GetTime()

  table.insert(msgQueue, {
    time = now,
    msg = msg,
    sender = sender,
    channel = channel
  })

  for i=#msgQueue,1,-1 do
    local msg = msgQueue[i]
    if msg.time < now - 3 then
      table.remove(msgQueue, i)
    end
  end
end

function msgEventHandler(self, event, msg, sender, languageName, channelName, playerName2, specialFlags, zoneChannelID, channelIndex, channelBaseName, unused, lineID)
  if lastLineId >= lineID then
    return nil
  end

  lastLineId = lineID
  local channel = event

  local player, realm = strsplit("-", sender, 2)
  if realm == GetRealmName() then
    sender = player
  end

  if event == "CHAT_MSG_RAID" or event == "CHAT_MSG_RAID_LEADER" then
    channel = "raid"
  elseif event == "CHAT_MSG_PARTY" or event == "CHAT_MSG_PARTY_LEADER" then
    channel = "party"
  elseif event == "CHAT_MSG_GUILD" or event == "CHAT_MSG_OFFICER" then
    channel = "guild"
  elseif event == "CHAT_MSG_WHISPER" then
    channel = "whisper"
  elseif event == "CHAT_MSG_SAY" then
    channel = "say"
  elseif event == "CHAT_MSG_YELL" then
    channel = "yell"
  end

  msgQueueHandler(msg, sender, channel)
end

function msgEventRegister()
  ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID_LEADER", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY_LEADER", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_GUILD", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_OFFICER", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_YELL", msgEventHandler)
end

function msgExists(content, sender, channel)
  for i=1,#msgQueue do
    local msg = msgQueue[i]
    local _msg = msg.msg
    if msg.time >= GetTime() - 3 and msg.msg == content and msg.sender == sender and 
        (msg.channel == channel or channel == "any" or
            (msg.channel == "raid" or msg.channel == "party") and channel == "group") then
      return true
    end
  end

  return false
end

function LFGDUMP()
  print(GetRecommendationTarget())
end

function LFGUICR()
  print("UNIT_INFO_CALLED - " .. unitInfoCalledCount)
  print("UNIT_INFO_CACHE_MISSED - " .. unitInfoCacheMissedCount)
  print("UNIT_INFO_CACHE_HIT_RATE - " .. tostring((unitInfoCalledCount - unitInfoCacheMissedCount) / unitInfoCalledCount))
end

function LFGENEMY()
  for k,v in pairs(CACHED_NAME_PLATE_UNITS) do
    print(k, v.name)
  end
end

function GetAbilityInfo(spell)
  local info = Hekili.Class.abilities[spell]
  local key = info and info.key or nil

  if key == nil then
    return
  end

  local spec = GetSpecialization()
  local specId = spec and GetSpecializationInfo(spec) or nil

  if specId == nil then
    return
  end

  local specInfo = Hekili.DB.profile.specs[specId]
  
  if specInfo == nil then
    return
  end
  
  local abilityInfo = specInfo.abilities[key]
  
  if abilityInfo == nil then
    return
  end

  return abilityInfo
end

LFGHSD = LFGHEKILISPELLDISABLE
LFGHSE = LFGHEKILISPELLENABLE
LFGGHSD = LFGGETHEKILISPELLDISABLED
LFGKEY = GetKey

function DBMEventsHandler(event, ...)
  if event == "DBM_TimerStart" then
    local timerId, text, duration, icon, timerType, spellId = ...
    if not timerId then return end

    local spellName = GetSpellInfo(spellId)
    DBM_TIMER[timerId] = {
      text = text,
      expirationTime = GetTime() + duration,
      spellId = tostring(spellId),
      spellName = spellName,
      source = "DBM",
    }
  elseif event == "DBM_TimerUpdate" then
    local timerId, elapsed, duration = ...
    if not timerId then return end

    DBM_TIMER[timerId].expirationTime = GetTime() + duration - elapsed
  elseif event=="DBM_TimerStop" then
    local timerId = ...
    if not timerId then return end

    DBM_TIMER[timerId] = nil
  end

  for k,v in pairs(DBM_TIMER) do
    if v.expirationTime + 5 < GetTime() then
      DBM_TIMER[k] = nil
    end
  end
end

function BWEventsHandler(event, ...)
  if event == "BigWigs_StartBar" then
    local addon, spellId, text, duration = ...
    local expirationTime = GetTime() + duration
    local spellName = GetSpellInfo(spellId)

    DBM_TIMER[text] = {
      text = text,
      expirationTime = GetTime() + duration,
      spellId = tostring(spellId),
      spellName = spellName,
      source = "BW"
    }
  elseif event == "BigWigs_StopBar" then
    local plugin, text = ...
    DBM_TIMER[text] = nil
  elseif event == "BigWigs_StopBars" then
    for k,v in pairs(DBM_TIMER) do
      if v.source == "BW" then
        DBM_TIMER[k] = nil
      end
    end
  end

  for k,v in pairs(DBM_TIMER) do
    if v.expirationTime + 5 < GetTime() then
      DBM_TIMER[k] = nil
    end
  end
end

function frame:OnEvent(event, arg, ...)
  if event == "ADDON_LOADED" and arg == "LifaGuardian" then
    self:UnregisterEvent("ADDON_LOADED")

    if LF_Guardian_WatchParty == nil then
      LF_Guardian_WatchParty = {}
    end

    if LF_Guardian_WatchRaid == nil then
      LF_Guardian_WatchRaid = {}
    end

    if LF_Guardian_Specialization_Profile == nil then
      LF_Guardian_Specialization_Profile = {}
    end

    C_Timer.After(1, function()
      UpdateProfileUI()

      InitializeTargetButtons()
      InitializePartyCheckButtons()
      InitializeRaidCheckButtons()

      if not LFHENABLED then
        CURRENT_QUEUE_LINE = nil
        CURRENT_QUEUE_TYPE = nil
        CURRENT_QUEUE_START = nil
      end

      GetNextRecomendationTarget()
      GetNextRecomendationAction()
      GetNextRecomendationAlarm()
      GetNextRecomendationHekiliOptions()
    end)
  end

  if event == "PLAYER_SPECIALIZATION_CHANGED" then
    UpdateProfileUI()
  end

  if event == "GROUP_ROSTER_UPDATE" then
    C_Timer.After(1, UpdateGroup)
  end

  if event == "PLAYER_TARGET_CHANGED" then
    lastChangeTargetTime = GetTime()
  end

  if event == "UNIT_SPELLCAST_SENT" and arg == "player" then
    if LFGDEBUG and DLAPI then
      DLAPI.DebugLog("LifaGuardian", "===== LIFA GUARDIAN DEBUG =====")
      for i=1,#OPERATIONS do
        DLAPI.DebugLog("LifaGuardian", OPERATIONS[i])
      end
    end
  end

  if event == "UNIT_SPELLCAST_SUCCEEDED" and arg == "player" then
    local _, _, spellId = ...
    local spellName = GetSpellInfo(spellId)

    if NEXT_KEY_OVERRIDE ~= nil and NEXT_KEY_OVERRIDE.spellName == spellName then
      NEXT_KEY_OVERRIDE = {}
    end
  end

  if event == "NAME_PLATE_UNIT_ADDED" then
    UNIT_CACHE[arg] = nil
    CACHED_NAME_PLATE_UNITS[arg] = true
  end

  if event == "NAME_PLATE_UNIT_REMOVED" then
    CACHED_NAME_PLATE_UNITS[arg] = nil
    UNIT_CACHE[arg] = nil
  end
end
frame:SetScript("OnEvent", frame.OnEvent)
msgEventRegister()

if DBM then
  DBM:RegisterCallback("DBM_TimerStart", DBMEventsHandler)
  DBM:RegisterCallback("DBM_TimerUpdate", DBMEventsHandler)
  DBM:RegisterCallback("DBM_TimerStop", DBMEventsHandler)
end

if BigWigsLoader then
  local plugin = {}
  BigWigsLoader.RegisterMessage(plugin, "BigWigs_StartBar", BWEventsHandler)
  BigWigsLoader.RegisterMessage(plugin, "BigWigs_StopBar", BWEventsHandler)
  BigWigsLoader.RegisterMessage(plugin, "BigWigs_StopBars", BWEventsHandler)
end

SLASH_LIFAGUARDIAN1 = "/lfg"
SlashCmdList["LIFAGUARDIAN"] = function (args)
  local _args = StringSplit(args, " ")
  local spellName = _args[1]
  local key = _args[2]

  if NEXT_KEY_OVERRIDE == nil or NEXT_KEY_OVERRIDE.spellName ~= spellName or NEXT_KEY_OVERRIDE.key ~= key then
    NEXT_KEY_OVERRIDE = {
      spellName = spellName,
      key = key,
      time = GetTime()
    }
  end
end
