local frame = CreateFrame("FRAME")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterEvent("PLAYER_TARGET_CHANGED")
frame:RegisterEvent("UNIT_SPELLCAST_SENT")
frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
frame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")

local panel = CreateFrame("FRAME")
panel.name = "力法神奇守护者"
InterfaceOptions_AddCategory(panel)

local classColor = {
  {0.78, 0.61, 0.43}, --Warrior
  {0.96, 0.55, 0.73}, --Paladin
  {0.67, 0.83, 0.45}, --Hunter
  {1.00, 0.96, 0.41}, --Rogue
  {1.00, 1.00, 1.00}, --Priest
  {0.77, 0.12, 0.23}, --Death Knight
  {0.00, 0.44, 0.87}, --Shaman
  {0.25, 0.78, 0.92}, --Mage
  {0.53, 0.53, 0.93}, --Warlock
  {0.00, 1.00, 0.60}, --Monk
  {1.00, 0.49, 0.04}, --Druid
  {0.64, 0.19, 0.79}, --Demon Hunter
  {0.20, 0.58, 0.50}, --Evoker
}

local keybindings = {
  player = "ALT-CTRL-NUMPAD0",
  party1 = "ALT-CTRL-NUMPAD1",
  party2 = "ALT-CTRL-NUMPAD2",
  party3 = "ALT-CTRL-NUMPAD3",
  party4 = "ALT-CTRL-NUMPAD4",
  raid1 = "ALT-CTRL-NUMPAD5",
  raid2 = "ALT-CTRL-NUMPAD6",
  raid3 = "ALT-CTRL-NUMPAD7",
  raid4 = "ALT-CTRL-NUMPAD8",
  raid5 = "ALT-CTRL-NUMPAD9",
  raid6 = "ALT-CTRL-F1",
  raid7 = "ALT-CTRL-F2",
  raid8 = "ALT-CTRL-F3",
  raid9 = "ALT-CTRL-F5",
  raid10 = "ALT-CTRL-F6",
  raid11 = "ALT-CTRL-F7",
  raid12 = "ALT-CTRL-F8",
  raid13 = "ALT-CTRL-F9",
  raid14 = "ALT-CTRL-F10",
  raid15 = "ALT-CTRL-F11",
  raid16 = "ALT-CTRL-F12",
  raid17 = "ALT-SHIFT-F1",
  raid18 = "ALT-SHIFT-F2",
  raid19 = "ALT-SHIFT-F3",
  raid20 = "ALT-SHIFT-F5",
  raid21 = "ALT-SHIFT-F6",
  raid22 = "ALT-SHIFT-F7",
  raid23 = "ALT-SHIFT-F8",
  raid24 = "ALT-SHIFT-F9",
  raid25 = "ALT-SHIFT-F10",
  raid26 = "ALT-SHIFT-F11",
  raid27 = "ALT-SHIFT-F12",
  raid28 = "CTRL-SHIFT-F1",
  raid29 = "CTRL-SHIFT-F2",
  raid30 = "CTRL-SHIFT-F3",
  raid31 = "CTRL-SHIFT-F4",
  raid32 = "CTRL-SHIFT-F5",
  raid33 = "CTRL-SHIFT-F6",
  raid34 = "CTRL-SHIFT-F7",
  raid35 = "CTRL-SHIFT-F8",
  raid36 = "CTRL-SHIFT-F9",
  raid37 = "CTRL-SHIFT-F10",
  raid38 = "CTRL-SHIFT-F11",
  raid39 = "CTRL-SHIFT-F12",
  raid40 = "CTRL-SHIFT-="
}

local wasounds = {
  ["Batman Punch"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BatmanPunch.ogg",
  ["Bike Horn"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BikeHorn.ogg",
  ["Boxing Arena Gong"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BoxingArenaSound.ogg",
  ["Bleat"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Bleat.ogg",
  ["Cartoon Hop"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\CartoonHop.ogg",
  ["Cat Meow"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\CatMeow2.ogg",
  ["Kitten Meow"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\KittenMeow.ogg",
  ["Robot Blip"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\RobotBlip.ogg",
  ["Sharp Punch"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\SharpPunch.ogg",
  ["Water Drop"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\WaterDrop.ogg",
  ["Air Horn"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AirHorn.ogg",
  ["Applause"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Applause.ogg",
  ["Banana Peel Slip"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BananaPeelSlip.ogg",
  ["Blast"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Blast.ogg",
  ["Cartoon Voice Baritone"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\CartoonVoiceBaritone.ogg",
  ["Cartoon Walking"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\CartoonWalking.ogg",
  ["Cow Mooing"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\CowMooing.ogg",
  ["Ringing Phone"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\RingingPhone.ogg",
  ["Roaring Lion"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\RoaringLion.ogg",
  ["Shotgun"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Shotgun.ogg",
  ["Squish Fart"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\SquishFart.ogg",
  ["Temple Bell"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\TempleBellHuge.ogg",
  ["Torch"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Torch.ogg",
  ["Warning Siren"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\WarningSiren.ogg",
  ["Sheep Blerping"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\SheepBleat.ogg",
  ["Rooster Chicken Call"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\RoosterChickenCalls.ogg",
  ["Goat Bleeting"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\GoatBleating.ogg",
  ["Acoustic Guitar"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\AcousticGuitar.ogg",
  ["Synth Chord"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\SynthChord.ogg",
  ["Chicken Alarm"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\ChickenAlarm.ogg",
  ["Xylophone"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Xylophone.ogg",
  ["Drums"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Drums.ogg",
  ["Tada Fanfare"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\TadaFanfare.ogg",
  ["Squeaky Toy Short"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\SqueakyToyShort.ogg",
  ["Error Beep"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\ErrorBeep.ogg",
  ["Oh No"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\OhNo.ogg",
  ["Double Whoosh"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\DoubleWhoosh.ogg",
  ["Brass"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Brass.mp3",
  ["Glass"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Glass.mp3",
  ["Tank In Danger"] = "Interface\\AddOns\\LifaGuardian\\Media\\Sounds\\TankInDanger.ogg"
}

local msgQueue = {}
local lastLineId = 0
local UNIT_CACHE = {}
local CACHE_DURATION = 0.25
local OPERATIONS = {}
local DBM_TIMER = {}
local ENEMY_LIST = {}

local defaultProfile = [[
unit,unit.health>0,unit.health<100,unit.health=min
unit,unit.isplayer=true
]]

local defaultDpsProfile = [[
action,action.key=hekili
]]

local lastChangeTargetTime = 0
local changeTargetTimeCooldown = 0.1
local recomendedUnit = nil
local frameDuration = 0.1
local filteredUnits = {}
local lastSoundPlayedTime = 0
local soundHandler = nil
local soundRepeatDuration = 3
local nowTime = GetTime()
local unitInfoCalledCount = 0
local unitInfoCacheMissedCount = 0

local playerName = UnitName("player")

local function GetUnitHealPercentage(unit)
  local incomingHeals = UnitGetIncomingHeals(unit)
  return (UnitHealth(unit) + (incomingHeals == nil and 0 or incomingHeals)) * 100 / UnitHealthMax(unit)
end

local function GetUnitHealLost(unit)
  local incomingHeals = UnitGetIncomingHeals(unit)
  return UnitHealthMax(unit) - (UnitHealth(unit) + (incomingHeals == nil and 0 or incomingHeals))
end

local function GetUnitBuff(unit)
  local buffs, i = { }, 1
  local buff, _, count, _, _, expTime, caster = UnitBuff(unit, i)

  while buff do
    local leftTime = expTime == 0 and 86400 or floor(expTime - GetTime())
    buffs["buff:" .. buff] = math.max(count, 1)
    buffs["buffleft:" .. buff] = leftTime
    if caster == "player" then
      buffs["bufffromplayer:" .. buff] = math.max(count, 1)
    buffs["bufffromplayerleft:" .. buff] = leftTime
    end
    i = i + 1
    buff, _, count, _, _, expTime, caster = UnitBuff(unit, i)
  end

  return buffs
end

local function GetUnitDebuff(unit)
  local debuffs, i = { }, 1
  local debuff, _, count, _, _, expTime, caster = UnitDebuff(unit, i)

  while debuff do
    local leftTime = expTime == 0 and 86400 or floor(expTime - GetTime())
    debuffs["debuff:" .. debuff] = math.max(count, 1)
    debuffs["debuffleft:" .. debuff] = leftTime
    if caster == "player" then
      debuffs["debufffromplayer:" .. debuff] = math.max(count, 1)
      debuffs["debufffromplayerleft:" .. debuff] = leftTime
    end
    i = i + 1
    debuff, _, count, _, _, expTime, caster = UnitDebuff(unit, i)
  end

  return debuffs
end

local function HasRemovableDebuff(unit)
  if UnitDebuff(unit, 1, true) then
    return true
  end

  return false
end



function HasDefensiveSpell(unit, classid)
  if not OmniCD or not OmniCD[1] or not OmniCD[1].spell_db
      or not OmniCD[1].Party or not OmniCD[1].Party.groupInfo then return nil end

  local spells = OmniCD[1].spell_db[classid]
  for _, info in pairs(OmniCD[1].Party.groupInfo) do
    if unit == info.unit or UnitIsUnit(unit, info.unit) then
      for i=1,#spells do
        if (spells[i].type == "defensive" or spells[i].type == "externalDefensive" or spells[i].type == "immunity") then
          local icons = info.bar.icons
          for j=1,#icons do
            if icons[j].spellID == spells[i].spellID
                and (not icons[j].cooldown.timer or icons[j].cooldown.timer.endCooldown < GetTime()) then
              return true
            end
          end
        end
      end

      return false
    end
  end

  return nil
end

local function GetUnitInfoValue(info, key)
  if info[key] ~= nil then
    return info[key]
  end

  unitInfoCacheMissedCount = unitInfoCacheMissedCount + 1
  if key == "role" then
    local role = string.lower(UnitGroupRolesAssigned(info.unit))
    info.role = role
  elseif key == "health" then
    info.health = GetUnitHealPercentage(info.unit)
  elseif key == "hasremovabledebuff" then
    info.hasremovabledebuff = HasRemovableDebuff(info.unit)
  elseif key == "mana" then
    info.mana = UnitPower(info.unit) * 100 / UnitPowerMax(info.unit)
  elseif key == "isdead" then
    info.isdead = UnitIsDead(info.unit) or GetUnitInfoValue(info, "buff:炉脉幻想") ~= nil or GetUnitInfoValue(info, "buff:救赎之魂") ~= nil
  elseif key == "incombat" then
    info.incombat = UnitAffectingCombat(info.unit)
  elseif key == "canattack" then
    info.canattack = UnitCanAttack("player", info.unit)
  elseif key == "canassist" then
    info.canassist = UnitCanAssist("player", info.unit)
  elseif key == "ismoving" then
    info.ismoving = GetUnitSpeed(info.unit) > 0
  elseif key == "resource" then
    info.resource = max(UnitPower(info.unit, 4), -- 连击点数，盗贼、猫德
      UnitPower(info.unit, 5),                   -- 符文，DK
      UnitPower(info.unit, 7),                   -- 灵魂碎片，术士
      UnitPower(info.unit, 9),                   -- 神圣能量，圣骑士
      UnitPower(info.unit, 12),                  -- 真气，武僧
      UnitPower(info.unit, 16),                  -- 奥术充能，奥法
      UnitPower(info.unit, 19))                  -- 精华，小龙人
  elseif key == "casting" or key == "castingleft" then
    local casting, _, _, _, castingEndTime = UnitCastingInfo(info.unit)
    info.casting = casting
    info.castingleft = castingEndTime and (castingEndTime/1000 - GetTime()) or 0
  elseif key == "isfocus" then
    info.isfocus = UnitIsUnit(info.unit, "focus")
  elseif string.sub(key, 1, 4) == "buff" and info.buffcached ~= 1 then
    local buff = GetUnitBuff(info.unit)
    for k,v in pairs(buff) do info[k] = v end
    info.buffcached = 1
  elseif string.sub(key, 1, 6) == "debuff" and info.debuffcached ~= 1 then
    local debuff = GetUnitDebuff(info.unit)
    for k,v in pairs(debuff) do info[k] = v end
    info.debuffcached = 1
  elseif key == "msg" or key == "msgchannel" then
    for i=1,#msgQueue do
      local msg = msgQueue[i]
      if msg.time >= GetTime() - 1 and msg.sender == fullname then
        info["msg"] = msg.msg
        info["msgchannel"] = msg.channel
        break
      end
    end
  elseif key == "def" then
    info.def = HasDefensiveSpell(info.unit, info.classid)
  else
    unitInfoCacheMissedCount = unitInfoCacheMissedCount - 1
  end

  return info[key]
end

local function GetUnitInfo(unit)
  if unit == "target" then
    local unitPrefix = "party"
    local groupSize = 4

    if IsInRaid() then
      unitPrefix = "raid"
      groupSize = 40
    end

    for i=1,groupSize do
      local groupUnit = unitPrefix .. i
      if UnitIsUnit(groupUnit, "target") then
        unit = groupUnit
        break
      end
    end

    if unit == "target" and UnitIsUnit(unit, "player") then
      unit = "player"
    end
  end

  unitInfoCalledCount = unitInfoCalledCount + 1

  if UNIT_CACHE[unit] and nowTime - UNIT_CACHE[unit].cacheTime < CACHE_DURATION then
    return UNIT_CACHE[unit]
  end

  local exists = UnitExists(unit)
  if not exists then
    UNIT_CACHE[unit] = nil
    return nil
  end

  local player = PlayerLocation:CreateFromUnit(unit)
  local name, realm = UnitName(unit)
  local className, classId, class = C_PlayerInfo.GetClass(player)
  local online = UnitIsConnected(unit)
  local fullname = realm == nil and name or name .. "-" .. realm
  local isplayer = playerName == fullname
  local ignore = string.sub(unit, 1, 4) == "raid" and LF_Guardian_WatchRaid[fullname] or LF_Guardian_WatchParty[fullname]

  local info = {
    unit = unit,
    color = classColor[class] or {0.62, 0.62, 0.62},
    class = className,
    classid = classId,
    name = name,
    fullname = fullname,
    online = online,
    ignore = ignore,
    isplayer = isplayer,
    keybinding = keybindings[unit],
    GetValue = GetUnitInfoValue,
    cacheTime = GetTime()
  }

  UNIT_CACHE[unit] = info
  return UNIT_CACHE[unit]
end

local function InitializeTargetButtons()
  local buttonFrame = CreateFrame("Frame", "LifaGuardianButton", UIParent)
  buttonFrame:SetSize(50, 50)
  buttonFrame:SetFrameStrata("BACKGROUND")
  buttonFrame:SetFrameLevel(10000)
  buttonFrame:SetPoint("TOPLEFT", UIParent, -100, 100)

  local MasaicTexture = buttonFrame:CreateTexture(nil, "BACKGROUND")
  MasaicTexture:SetPoint("TOPLEFT", buttonFrame, 0, 0)
  MasaicTexture:SetSize(50, 50)
  MasaicTexture:SetColorTexture(1, 0, 0)
  MasaicTexture:Show()

  for i=1,5 do
    local unit = i == 1 and "player" or "party" .. (i - 1)
    local macro = "/target " .. unit
    local button = CreateFrame("Button", "LFGuardian_" .. unit, buttonFrame, 'SecureActionButtonTemplate')
    button:RegisterForClicks("AnyUp", "AnyDown")
    button:SetAllPoints()
    button:SetAttribute("type1", "macro")
    button:SetAttribute("macrotext", macro)
    SetOverrideBindingClick(buttonFrame, true, keybindings[unit], "LFGuardian_" .. unit)
  end

  for i=1,40 do
    local unit = "raid" .. i
    local macro = "/target " .. unit
    local button = CreateFrame("Button", "LFGuardian_" .. unit, buttonFrame, 'SecureActionButtonTemplate')
    button:RegisterForClicks("AnyUp", "AnyDown")
    button:SetAllPoints()
    button:SetAttribute("type1", "macro")
    button:SetAttribute("macrotext", macro)
    SetOverrideBindingClick(buttonFrame, true, keybindings[unit], "LFGuardian_" .. unit)
  end
end

local watchTop = -16
local watchTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
watchTitle:SetPoint("TOPLEFT", 16, watchTop)
watchTitle:SetText("守护目标")

local watchPartyTop = -8
local watchPartyTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
watchPartyTitle:SetTextColor(0.67, 0.67, 1, 1)
watchPartyTitle:SetPoint("TOPLEFT", watchTitle, "BOTTOMLEFT", 0, watchPartyTop)
watchPartyTitle:SetText("小队目标")

local watchRaidTop = -40
local watchRaidTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
watchRaidTitle:SetTextColor(1, 0.5, 0, 1)
watchRaidTitle:SetPoint("TOPLEFT", watchPartyTitle, "BOTTOMLEFT", 0, watchRaidTop)
watchRaidTitle:SetText("团队目标")

local profileTop = -416
local profileTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
profileTitle:SetPoint("TOPLEFT", 16, profileTop)
profileTitle:SetText("守护规则")

local profileFrameTop = -8
local profileFrame = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
profileFrame:SetSize(550, 100)
profileFrame:SetPoint("TOPLEFT", profileTitle, "BOTTOMLEFT", 0, profileFrameTop)

local profileEditBox = CreateFrame("EditBox", nil, profileFrame)
profileEditBox:SetMultiLine(true)
profileEditBox:SetAutoFocus(false)
profileEditBox:SetFontObject(ChatFontNormal)
profileEditBox:SetWidth(525)
profileEditBox:SetScript("OnTextChanged", function(_, userInput)
  if not userInput then return end
  local specialization = GetSpecialization()
  LF_Guardian_Specialization_Profile[specialization] = profileEditBox:GetText()
end)

profileFrame:SetScrollChild(profileEditBox)

local partyCheckButtons = {}
local raidCheckButtons = {}

local function IsHealer()
  local player = PlayerLocation:CreateFromUnit("player")
  local _, _, class = C_PlayerInfo.GetClass(player)
  local specialization = GetSpecialization()

  if class == 2 and specialization == 1
    or class == 5 and specialization == 1
    or class == 5 and specialization == 2
    or class == 7 and specialization == 3
    or class == 10 and specialization == 2
    or class == 11 and specialization == 4 
    or class == 13 and specialization == 2 then
    return true
  end

  return false
end

local function UpdateProfileUI()
  local specialization = GetSpecialization()

  local profile = LF_Guardian_Specialization_Profile[specialization] or LF_Guardian_Profile
  if profile == nil then
    if IsHealer() then
      LF_Guardian_Specialization_Profile[specialization] = defaultProfile
    else
      LF_Guardian_Specialization_Profile[specialization] = defaultDpsProfile
    end
  elseif LF_Guardian_Specialization_Profile[specialization] == nil then
    if IsHealer() then
      LF_Guardian_Specialization_Profile[specialization] = LF_Guardian_Profile
    else
      LF_Guardian_Specialization_Profile[specialization] = defaultDpsProfile
    end
  end

  -- LF_Guardian_Profile = nil
  profile = LF_Guardian_Specialization_Profile[specialization]

  profileEditBox:SetText(profile)
end

local function StringSplit(inputstr, sep)
  if sep == nil then
    sep = "%s"
  end

  local t={}

  for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
    table.insert(t, str)
  end

  return t
end

function Trim(s)
  return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function GetStrWidth(str)
  local realByteCount = #str
  local length = 0
  local curBytePos = 1

  while(true) do
    local step = 1
    local byteVal = string.byte(str, curBytePos)
    if byteVal > 239 then
      step = 4
    elseif byteVal > 223 then
      step = 3
    elseif byteVal > 191 then
      step = 2
    else
      step = 1
    end
    curBytePos = curBytePos + step
    length = length + (step == 1 and 1 or 2)
    if curBytePos > realByteCount then
      break
    end
  end
  return length
end

local function CutString(str, maxWidth)
  local realByteCount = #str
  local length = 0
  local curBytePos = 1
  local endPos = 1
  local step = 1

  while(true) do
    local byteVal = string.byte(str, curBytePos)
    if byteVal > 239 then
      step = 4
    elseif byteVal > 223 then
      step = 3
    elseif byteVal > 191 then
      step = 2
    else
      step = 1
    end
    
    curBytePos = curBytePos + step
    length = length + (step == 1 and 1 or 2)
    if length > maxWidth then
      break
    end

    endPos = curBytePos - 1

    if curBytePos > realByteCount then
      break
    end
  end
  
  local newStr = endPos == 1 and step > 1 and "" or string.sub(str, 1, endPos)
  return #str == #newStr and str or newStr .. "..."
end

local function GetDisplayName(name)
  if GetStrWidth(name) > 10 then
    name = CutString(name, 9)
  end

  return name
end

local function UpdateCheckbox(index, checked, playerInfo, checkButton)
  if playerInfo == nil then
    checkButton:SetChecked(false)
    checkButton.Text:SetText("<未指定>")
    checkButton.tooltipText = "<未指定>"
    checkButton.Text:SetTextColor(0.62, 0.62, 0.62, 1)
    checkButton:Disable()
  else
    local role = CreateAtlasMarkup("roleicon-tiny-dps")
    if playerInfo.role == "tank" then
      role = CreateAtlasMarkup("roleicon-tiny-tank")
    elseif playerInfo.role == "healer" then
      role = CreateAtlasMarkup("roleicon-tiny-healer")
    end

    if playerInfo.online then
      checkButton:SetChecked(checked)
      checkButton.Text:SetTextColor(playerInfo.color[1], playerInfo.color[2], playerInfo.color[3], 1)
      checkButton:Enable()
    else
      checkButton:SetChecked(false)
      checkButton.Text:SetTextColor(0.62, 0.62, 0.62, 1)
      checkButton:Disable()
    end
    
    checkButton.Text:SetText(role .. " " .. GetDisplayName(playerInfo.name))
    checkButton.tooltipText = playerInfo.name
  end
end

local function PartyCheckBoxOnClick(party)
  local i = party.partyIndex
  local unit = "player"

  if i > 1 then
    unit = "party" .. (i - 1)
  end

  local playInfo = GetUnitInfo(unit)
  local fullname = playInfo.fullname
  
  if party:GetChecked() then
    LF_Guardian_WatchParty[fullname] = nil
  else
    LF_Guardian_WatchParty[fullname] = true
  end
end

local function RaidCheckBoxOnClick(raid)
  local i = raid.raidIndex
  local unit = "raid" .. i

  local playInfo = GetUnitInfo(unit)
  local fullname = playInfo.fullname
  
  if raid:GetChecked() then
    LF_Guardian_WatchParty[fullname] = nil
  else
    LF_Guardian_WatchParty[fullname] = true
  end
end

local function UpdateParty()
  local isInParty = IsInGroup()
  for i=1,5 do
    local playerInfo
    if not isInParty then
      playerInfo = nil
    else
      local unit = i == 1 and "player" or "party" .. (i - 1)
      playerInfo = GetUnitInfo(unit)
    end

    local checked = playerInfo and not playerInfo.ignore or false

    UpdateCheckbox(i, checked, playerInfo, partyCheckButtons[i])
  end
end

local function InitializePartyCheckButtons()
  for i=1,5 do
    partyCheckButtons[i] = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
    partyCheckButtons[i]:SetScript("OnClick", PartyCheckBoxOnClick)
    partyCheckButtons[i].partyIndex = i
    partyCheckButtons[i]:SetPoint("TOPLEFT", watchPartyTitle, "BOTTOMLEFT", (i - 1) * 120, -8)
  end

  UpdateParty()
end

local function UpdateRaid()
  local isInRaid = IsInRaid()
  for i=1,8 do
    for j=1,5 do
      local playerInfo
      if not isInRaid then
        playerInfo = nil
      else
        local unit = "raid" .. ((i - 1) * 5 + j)
        playerInfo = GetUnitInfo(unit)
      end

      local checked = playerInfo and not playerInfo.ignore or false

      UpdateCheckbox((i - 1) * 5 + j, checked, playerInfo, raidCheckButtons[(i - 1) * 5 + j])
    end
  end
end

local function InitializeRaidCheckButtons()
  for i=1,8 do
    for j=1,5 do
      raidCheckButtons[(i - 1) * 5 + j] = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
      raidCheckButtons[(i - 1) * 5 + j]:SetScript("OnClick", RaidCheckBoxOnClick)
      raidCheckButtons[(i - 1) * 5 + j].raidIndex = i
      raidCheckButtons[(i - 1) * 5 + j]:SetPoint("TOPLEFT", watchRaidTitle, "BOTTOMLEFT", (j - 1) * 120, -8 - 36 * (i - 1))
    end
  end

  UpdateRaid()
end

local function GetPlayerRaidUnit()
  for i=1,40 do
    local unitInfo = GetUnitInfo("raid" .. i)
    if unitInfo.fullname == playerName then
      return "raid" .. i
    end
  end
end

local function GetAvailableUnits()
  local groupSize = GetNumGroupMembers()
  local unitPrefix = "party"

  local units = {}

  if IsInRaid() then
    unitPrefix = "raid"
    groupSize = 40
  elseif IsInGroup() then
    groupSize = groupSize - 1
    table.insert(units, GetUnitInfo("player"))
  end

  for i=1,groupSize do
    local unit = unitPrefix .. i
    local info = GetUnitInfo(unit)

    if info ~= nil then
      local inRange, checkedRange = UnitInRange(unit)

      if info and not info.ignore and info.online and inRange and checkedRange then
        table.insert(units, info)
      end
    end
  end

  return units
end

local function SmartTypeParse(value)
  local numberValue = tonumber(value)
  local booleanValue = nil
  if value == "true" then
    booleanValue = true
  elseif value == "false" then
    booleanValue = false
  end

  if numberValue ~= nil then
    return numberValue
  elseif booleanValue ~= nil then
    return booleanValue
  end

  if value == "nil" then
    return nil
  end

  return value
end

local function GetNonNullableValue(item, key)
  local value = item[key]

  if value == nil and item.GetValue ~= nil then
    value = item.GetValue(item, key)
  end

  if value == nil then
    return 0
  end
  
  return value
end

local function GetMinValueItem(items, key)
  local minValue = nil
  local item = nil

  for i=1,#items do
    if minValue == nil or GetNonNullableValue(items[i], key) < minValue then
      item = items[i]
      minValue = GetNonNullableValue(items[i], key)
    end
  end
  return item
end

local function GetMaxValueItem(items, key)
  local maxValue = nil
  local item = nil

  for i=1,#items do
    if maxValue == nil or GetNonNullableValue(items[i], key) > maxValue then
      item = items[i]
      maxValue = GetNonNullableValue(items[i], key)
    end
  end

  return item
end

local function GetValueLessThanItems(items, key, value)
  local filteredItems = {}

  if key == count then
    local allUnits = GetAvailableUnits()
    if items ~= nil and #item < value or #allUnits == #item then
      return items
    end

    return {}
  end

  for i=1,#items do
    if GetNonNullableValue(items[i], key) < value then
      table.insert(filteredItems, items[i])
    end
  end

  return filteredItems
end

local function GetValueGreaterThanItems(items, key, value)
  local filteredItems = {}

  if key == count then
    if items ~= nil and #item > value then
      return items
    end

    return {}
  end

  for i=1,#items do
    if GetNonNullableValue(items[i], key) > value then
      table.insert(filteredItems, items[i])
    end
  end

  return filteredItems
end

local function ParseFilter(filter)
  local operator = "="

  if string.find(filter, "=") then
    operator = "="
  elseif string.find(filter, "~") then
    operator = "~"
  elseif string.find(filter, "<") then
    operator = "<"
  elseif string.find(filter, ">") then
    operator = ">"
  end

  local str = StringSplit(filter, operator)
  local key = StringSplit(str[1], ".")
  local value = SmartTypeParse(str[2])

  return {
    object = key[1],
    property = key[2],
    operator = operator,
    value = value
  }
end

local function GetMsgFilterUnits(items, msg, channel)
  for i=1,#items do
    if msgExists(tostring(msg), items[i].fullname, channel) then
      return { items[i] }
    end
  end

  return {}
end

local function GetFilteredItem(items, filter)
  if filter.value == "min" then
    local item = GetMinValueItem(items, filter.property)
    return { item }
  end

  if filter.value == "max" then
    local item = GetMaxValueItem(items, filter.property)
    return { item }
  end

  if filter.operator == "<" then
    return GetValueLessThanItems(items, filter.property, filter.value)
  end

  if filter.operator == ">" then
    return GetValueGreaterThanItems(items, filter.property, filter.value)
  end

  if filter.property == count then
    if filter.operator == "=" and #items == count
        or filter.operator == "~" and #items ~= count then
      return items
    else
      return {}
    end
  end

  if filter.property == "msg" and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "any")
  end

  if filter.property == "msg_group" and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "group")
  end

  if (filter.property == "msg_raid" or filter.property == "msg_i") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "raid")
  end

  if (filter.property == "msg_party" or filter.property == "msg_p") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "party")
  end

  if (filter.property == "msg_guild" or filter.property == "msg_g") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "guild")
  end

  if (filter.property == "msg_whisper" or filter.property == "msg_w") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "whisper")
  end

  if (filter.property == "msg_say" or filter.property == "msg_s") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "say")
  end

  if (filter.property == "msg_yell" or filter.property == "msg_y") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "yell")
  end

  local filteredItems = {}

  for i=1,#items do
    if filter.operator == "=" and GetNonNullableValue(items[i], filter.property) == filter.value
        or filter.operator == "~" and GetNonNullableValue(items[i], filter.property) ~= filter.value then
      table.insert(filteredItems, items[i])
    end
  end

  return filteredItems
end

local function GetFilteredUnit(unit, filter)
  local player = GetUnitInfo(unit)
  local items = { player }
  local filteredPlayer = GetFilteredItem(items, filter)

  if #filteredPlayer == 0 then
    return nil
  else
    return filteredPlayer[1]
  end
end

local function GetAllFilteredUnits(filter)
  if filter.property == "count" then
    local filterUnitCount = #filteredUnits
    filteredUnits = GetAvailableUnits()

    if filter.operator == "=" and filterUnitCount == filter.value
        or filter.operator == "~" and filterUnitCount ~= filter.value
        or filter.operator == "<" and filterUnitCount < filter.value
        or filter.operator == ">" and filterUnitCount > filter.value then
      return true
    end
    
    return nil
  end

  filteredUnits = GetFilteredItem(filteredUnits, filter)
  return filteredUnits
end

local function GetFilteredDBM(filter)
  local spellIdOrName = nil
  local text = nil

  if string.sub(filter.property, 1, 6) == "spell:" then
    spellIdOrName = string.sub(filter.property, 7)
  elseif string.sub(filter.property, 1, 5) == "text:" then
    text = string.sub(filter.property, 6)
  end

  if spellIdOrName or text then
    for k,v in pairs(DBM_TIMER) do
      if spellIdOrName ~= nil and (tostring(v.spellId) == spellIdOrName or v.spellName == spellIdOrName)
          or text ~= nil and v.text == text then
        local leftTime = ceil((v.expirationTime - GetTime()) * 10) / 10

        if leftTime >= 0 then
          if filter.operator == "=" and leftTime == filter.value
            or filter.operator == "~" and leftTime ~= filter.value
            or filter.operator == "<" and leftTime < filter.value
            or filter.operator == ">" and leftTime > filter.value then
            return true
          end
        end
      end
    end
  end

  return nil
end

local function GetFilteredEnemy(filter)
  local items = {}
  for _,v in pairs(ENEMY_LIST) do
    table.insert(items, v)
  end

  local filteredEnemy = GetFilteredItem(items, filter)

  if #filteredEnemy == 0 then
    return nil
  else
    return filteredEnemy[1]
  end
end

local function GetFilteredPlayer(filter)
  return GetFilteredUnit("player", filter)
end

local function GetFilteredTarget(filter)
  return GetFilteredUnit("target", filter)
end

local function GetFilteredTargettarget(filter)
  return GetFilteredUnit("targettarget", filter)
end

local function GetFilteredMouseover(filter)
  return GetFilteredUnit("mouseover", filter)
end

local function GetFilteredFocus(filter)
  return GetFilteredUnit("focus", filter)
end

local function GetFilteredSpell(filter)
  local _, duration = GetSpellCooldown(filter.property)
  local useable = IsUsableSpell(filter.property)
  local castable = useable and duration == 0
  local inRange = IsSpellInRange(filter.property, "target") ~= 0

  if filter.value == nil then
    if not useable and filter.operator == "=" or useable and filter.operator == "~" then
      return { filter.property }
    else
      return nil
    end
  end

  if castable and inRange and filter.value or not castable and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  return nil
end

local function GetItemId(itemName)
  for bag=0,NUM_BAG_SLOTS do
    for slot=1,C_Container.GetContainerNumSlots(bag) do
      local link = C_Container.GetContainerItemLink(bag, slot)
      if link ~= nil and GetItemInfo(link) == itemName then
          return C_Container.GetContainerItemID(bag, slot)
      end
    end
  end
  return nil
end

local function GetFilteredContainerItem(filter)
  local id = GetItemId(filter.property)
  if id == nil and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  local spellName, spellId = GetItemSpell(id)

  if spellId == nil then
    if filter.operator == "=" then
      return not filter.value and { filter.property } or nil
    else
      return filter.value and { filter.property } or nil
    end
  end

  local _, duration = GetSpellCooldown(spellId)

  local useable = IsUsableSpell(spellId) and duration == 0
  if useable and filter.value or not useable and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  return nil
end

local function GetTrinketInfo(slot)
  local id = GetInventoryItemID("player", slot)
  if id == nil then
    return nil, nil
  end

  local name = GetItemInfo(id)
  return name, id
end

local function GetFilteredTrinket(filter)
  local name13, id13 = GetTrinketInfo(13)
  local name14, id14 = GetTrinketInfo(14)

  if name13 ~= filter.property and name14 ~= filter.property and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  if name13 ~= filter.property and name14 ~= filter.property and filter.value then
    if filter.operator == "=" then
      return nil
    else
      return { filter.property }
    end
  end

  local id = name13 == filter.property and id13 or id14
  local _, duration, enable = GetItemCooldown(id)

  local useable = enable and duration == 0
  if useable and filter.value or not useable and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  return nil
end

local function GetFilteredTotem(filter)
  local totems, i, now = { }, 1, GetTime()
  local _, totem, start, duration = GetTotemInfo(i)
  
  while totem and totem ~= "" do
    totems[totem] = floor(start + duration - now)
    i = i + 1
    _, totem, start, duration = GetTotemInfo(i)
  end

  local filteredTotems = GetFilteredItem({ totems }, filter)

  if #filteredTotems == 0 then
    return nil
  else
    return true
  end
end

local function GetFilteredGroup(filter)
  if filter.property ~= "type" then
    return nil
  end

  local isInRaid = IsInRaid()
  local isInGroup = IsInGroup()

  if filter.operator == "=" and filter.value == "raid" and isInRaid
      or filter.operator == "~" and filter.value == "raid" and not isInRaid
      or filter.operator == "=" and filter.value == "party" and not isInRaid and isInGroup
      or filter.operator == "~" and filter.value == "party" and (isInRaid or not isInGroup) then
    return true
  end

  return nil
end

local function GetGeneralFiltered(filter)
  if filter.object == "player" and GetFilteredPlayer(filter) == nil then
    return false
  end

  if filter.object == "target" and GetFilteredTarget(filter) == nil then
    return false
  end

  if filter.object == "targettarget" and GetFilteredTargettarget(filter) == nil then
    return false
  end

  if filter.object == "mouseover" and GetFilteredMouseover(filter) == nil then
    return false
  end

  if filter.object == "focus" and GetFilteredFocus(filter) == nil then
    return false
  end

  if filter.object == "spell" and GetFilteredSpell(filter) == nil then
    return false
  end

  if filter.object == "item" and GetFilteredContainerItem(filter) == nil then
    return false
  end

  if (filter.object == "trinket" or filter.object == "sp") and GetFilteredTrinket(filter) == nil then
    return false
  end

  if filter.object == "totem" and GetFilteredTotem(filter) == nil then
    return false
  end

  if filter.object == "units" and GetAllFilteredUnits(filter) == nil then
    return false
  end

  if filter.object == "group" and GetFilteredGroup(filter) == nil then
    return false
  end

  if filter.object == "dbm" and GetFilteredDBM(filter) == nil then
    return false
  end

  if filter.object == "enemy" and GetFilteredEnemy(filter) == nil then
    return false
  end

  return true
end

local function GetFilteredActions(actions, filter)
  if not GetGeneralFiltered(filter) then
    return {}
  end

  if filter.object == "action" and filter.property == "key" then
    if (filter.value == "hekili" or filter.value == "Hekili" or filter.value == "HEKILI") and
      not (Hekili and Hekili.DisplayPool.Primary and Hekili.DisplayPool.Primary.Recommendations[1]
        and Hekili.DisplayPool.Primary.Recommendations[1].keybind) then
      return actions
    end
    
    table.insert(actions, { key = filter.value })
  end

  return actions
end

local function GetFilteredAlarms(alarms, filter)
  if not GetGeneralFiltered(filter) then
    return {}
  end

  if filter.object == "alarm" and filter.property == "sound" then
    table.insert(alarms, { sound = filter.value })
  end

  return alarms
end

local function GetKeyDefinitions(definitions, filter)
  if filter.object == "key" then
    definitions[filter.property] = filter.value
  end

  return definitions
end

local function GetFilteredUnits(units, filter)
  if not GetGeneralFiltered(filter) then
    return {}
  end

  if filter.object == "unit" then
    return GetFilteredItem(units, filter)
  else
    return units
  end
end

local function GetFilteredItems(command, items, filter)
  if command == "unit" then
    return GetFilteredUnits(items, filter)
  end

  if command == "action" then
    return GetFilteredActions(items, filter)
  end

  if command == "alarm" then
    return GetFilteredAlarms(items, filter)
  end

  if command == "key" then
    return GetKeyDefinitions(items, filter)
  end

  return {}
end

local function LineParse(line, context, filteredCommand)
  local args = StringSplit(line, ",")
  local command = args[1]

  if filteredCommand ~= nil and command ~= filteredCommand and not (filteredCommand == "action" and command == "key") then
    return nil
  end

  local items = {}
  filteredUnits = GetAvailableUnits()

  if command ~= "key" and context[command] ~= nil then
    return nil
  end

  if command == "key" then
    items = context[command] or {}
  end

  if command == "unit" then
    items = GetAvailableUnits()
  end

  for i=2,#args do
    local filter = ParseFilter(args[i])
    items = GetFilteredItems(command, items, filter)
    if #items == 0 and command ~= "key" then
      -- if LFGDEBUG and DLAPI then DLAPI.DebugLog("LifaGuardian", "[失败]" .. line .. ' 不满足条件 ' .. args[i]) end
      args[i] = "|cFFFF0000" .. args[i] .. "|r"
      return table.concat(args, ",")
    end
  end

  if #items > 0 then
    context[command] = items[1]

    -- if LFGDEBUG and DLAPI then DLAPI.DebugLog("LifaGuardian", "[成功] " .. line) end
    return "|cFF00FF00" .. line .. "|r"
  elseif command == "key" then
    context[command] = items
  end

  return nil
end

local function RuleParse(rule, filteredCommand)
  local lines = StringSplit(rule, "\n")
  local context = {}
  local operations = {}

  for i=1,#lines do
    local str = Trim(lines[i])
    if str ~= "" then
      local operationRes = LineParse(str, context, filteredCommand)
      if filteredCommand == "action" and operationRes ~= nil then
        table.insert(operations, operationRes)
      end
    end
  end

  if context.action ~= nil then
    if context.action.key == "hekili" or context.action.key == "Hekili" or context.action.key == "HEKILI" then
      context.action.key = Hekili.DisplayPool.Primary.Recommendations[1].keybind
    elseif context.key ~= nil then
      context.action.key = context.key[context.action.key] or context.action.key
    end
    OPERATIONS = operations
  end

  return context
end

local function GetRecommendation(filteredCommand)
  local specialization = GetSpecialization()
  nowTime = GetTime()
  local context = RuleParse(LF_Guardian_Specialization_Profile and LF_Guardian_Specialization_Profile[specialization] or LF_Guardian_Profile, filteredCommand)
  return context
end

local function GetRecommendationTarget()
  local context = GetRecommendation("unit")
  return context.unit
end

local function GetRecommendationAction()
  local context = GetRecommendation("action")
  return context.action
end

local function GetRecommendationAlarm()
  local context = GetRecommendation("alarm")
  return context.alarm
end

local function ShowKeyInfo(key)
  local cSpell, _, _, _, _, _, _, spellId = UnitChannelInfo("player")
  if cSpell and spellId ~= 115175 then
    LFMUC("")
    return
  end

  local info=(UnitGUID("player") and C_BattleNet.GetAccountInfoByGUID(UnitGUID("player")) or nil)
  LFMUC("key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404") .. ":key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404") .. ":key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404"))
end

local function GetNextRecomendationTarget()
  if not LFGRTDISABLED and LFHENABLED and GetTime() - lastChangeTargetTime > changeTargetTimeCooldown then
    recomendedUnit = GetRecommendationTarget()
    if recomendedUnit == nil then
      C_Timer.After(frameDuration, GetNextRecomendationTarget)
      return
    end
    
    local currentUnitInfo = GetUnitInfo("target")

    if not (recomendedUnit and currentUnitInfo and recomendedUnit.fullname == currentUnitInfo.fullname) then
      local key = keybindings[recomendedUnit.unit]:gsub("ALT", "A"):gsub("CTRL", "C"):gsub("SHIFT", "S"):gsub("NUMPAD", "N"):gsub("-", "")
      ShowKeyInfo(key)
    end
  end

  C_Timer.After(frameDuration, GetNextRecomendationTarget)
end

local function GetNextRecomendationAction()
  if LFHENABLED then
    local action = GetRecommendationAction()
    local currentUnitInfo = GetUnitInfo("target")
    
    if LFGRTDISABLED or not recomendedUnit or (recomendedUnit and currentUnitInfo and recomendedUnit.fullname == currentUnitInfo.fullname) then
      if action == nil then
        LFMUC("")
      else
        local key = action.key
        ShowKeyInfo(key)
      end
    end
  end

  C_Timer.After(frameDuration, GetNextRecomendationAction)
end

local function GetNextRecomendationAlarm()
  if LFHENABLED then
    local alarm = GetRecommendationAlarm()
    if alarm == nil then
      lastSoundPlayedTime = 0

      if soundHandle ~= nil then
        StopSound(soundHandle)
        soundHandle = nil
      end
    elseif alarm ~= nil and wasounds[alarm.sound] ~= nil then
      if (GetTime() - lastSoundPlayedTime) >= soundRepeatDuration then
        lastSoundPlayedTime = GetTime()
        soundHandler = PlaySoundFile(wasounds[alarm.sound], "Master")
      end
    end
  end

  C_Timer.After(frameDuration, GetNextRecomendationAlarm)
end

local function UpdateGroup()
  UpdateParty()
  UpdateRaid()
end

function msgQueueHandler(msg, sender, channel)
  local now = GetTime()

  table.insert(msgQueue, {
    time = now,
    msg = msg,
    sender = sender,
    channel = channel
  })

  for i=#msgQueue,1,-1 do
    local msg = msgQueue[i]
    if msg.time < now - 3 then
      table.remove(msgQueue, i)
    end
  end
end

function msgEventHandler(self, event, msg, sender, languageName, channelName, playerName2, specialFlags, zoneChannelID, channelIndex, channelBaseName, unused, lineID)
  if lastLineId >= lineID then
    return nil
  end

  lastLineId = lineID
  local channel = event

  local player, realm = strsplit("-", sender, 2)
  if realm == GetRealmName() then
    sender = player
  end

  if event == "CHAT_MSG_RAID" or event == "CHAT_MSG_RAID_LEADER" then
    channel = "raid"
  elseif event == "CHAT_MSG_PARTY" or event == "CHAT_MSG_PARTY_LEADER" then
    channel = "party"
  elseif event == "CHAT_MSG_GUILD" or event == "CHAT_MSG_OFFICER" then
    channel = "guild"
  elseif event == "CHAT_MSG_WHISPER" then
    channel = "whisper"
  elseif event == "CHAT_MSG_SAY" then
    channel = "say"
  elseif event == "CHAT_MSG_YELL" then
    channel = "yell"
  end

  msgQueueHandler(msg, sender, channel)
end

function msgEventRegister()
  ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID_LEADER", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY_LEADER", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_GUILD", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_OFFICER", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", msgEventHandler)
  ChatFrame_AddMessageEventFilter("CHAT_MSG_YELL", msgEventHandler)
end

function msgExists(content, sender, channel)
  for i=1,#msgQueue do
    local msg = msgQueue[i]
    local _msg = msg.msg
    if msg.time >= GetTime() - 3 and msg.msg == content and msg.sender == sender and 
        (msg.channel == channel or channel == "any" or
            (msg.channel == "raid" or msg.channel == "party") and channel == "group") then
      return true
    end
  end

  return false
end

function LFGDUMP()
  print(GetRecommendationTarget())
end

function LFGUICR()
  print("UNIT_INFO_CALLED - " .. unitInfoCalledCount)
  print("UNIT_INFO_CACHE_MISSED - " .. unitInfoCacheMissedCount)
  print("UNIT_INFO_CACHE_HIT_RATE - " .. tostring((unitInfoCalledCount - unitInfoCacheMissedCount) / unitInfoCalledCount))
end

function LFGENEMY()
  for k,v in pairs(ENEMY_LIST) do
    print(k, v.name)
  end
end

function DBMEventsHandler(event, ...)
  if event == "DBM_TimerStart" then
    local timerId, text, duration, icon, timerType, spellId = ...
    if not timerId then return end

    local spellName = GetSpellInfo(spellId)
    DBM_TIMER[timerId] = {
      text = text,
      expirationTime = GetTime() + duration,
      spellId = tostring(spellId),
      spellName = spellName,
      source = "DBM",
    }
  elseif event == "DBM_TimerUpdate" then
    local timerId, elapsed, duration = ...
    if not timerId then return end

    DBM_TIMER[timerId].expirationTime = GetTime() + duration - elapsed
  elseif event=="DBM_TimerStop" then
    local timerId = ...
    if not timerId then return end

    DBM_TIMER[timerId] = nil
  end

  for k,v in pairs(DBM_TIMER) do
    if v.expirationTime + 5 < GetTime() then
      DBM_TIMER[k] = nil
    end
  end
end

function BWEventsHandler(event, ...)
  if event == "BigWigs_StartBar" then
    local addon, spellId, text, duration = ...
    local expirationTime = GetTime() + duration
    local spellName = GetSpellInfo(spellId)

    DBM_TIMER[text] = {
      text = text,
      expirationTime = GetTime() + duration,
      spellId = tostring(spellId),
      spellName = spellName,
      source = "BW"
    }
  elseif event == "BigWigs_StopBar" then
    local plugin, text = ...
    DBM_TIMER[text] = nil
  elseif event == "BigWigs_StopBars" then
    for k,v in pairs(DBM_TIMER) do
      if v.source == "BW" then
        DBM_TIMER[k] = nil
      end
    end
  end

  for k,v in pairs(DBM_TIMER) do
    if v.expirationTime + 5 < GetTime() then
      DBM_TIMER[k] = nil
    end
  end
end

function RemoveEnemy(GUID)
  ENEMY_LIST[GUID] = nil

  for k,v in pairs(ENEMY_LIST) do
    if (v.lastSeen + 30) < GetTime() then
      ENEMY_LIST[k] = nil
    end
  end
end

function AddEnemy(GUID, name)
  ENEMY_LIST[GUID] = {
    name = name,
    lastSeen = GetTime()
  }
end

function frame:OnEvent(event, arg)
  if event == "ADDON_LOADED" and arg == "LifaGuardian" then
    self:UnregisterEvent("ADDON_LOADED")

    if LF_Guardian_WatchParty == nil then
      LF_Guardian_WatchParty = {}
    end

    if LF_Guardian_WatchRaid == nil then
      LF_Guardian_WatchRaid = {}
    end

    if LF_Guardian_Specialization_Profile == nil then
      LF_Guardian_Specialization_Profile = {}
    end

    C_Timer.After(1, function()
      UpdateProfileUI()

      InitializeTargetButtons()
      InitializePartyCheckButtons()
      InitializeRaidCheckButtons()

      GetNextRecomendationTarget()
      GetNextRecomendationAction()
      GetNextRecomendationAlarm()
    end)
  end

  if event == "PLAYER_SPECIALIZATION_CHANGED" then
    UpdateProfileUI()
  end

  if event == "GROUP_ROSTER_UPDATE" then
    C_Timer.After(1, UpdateGroup)
  end

  if event == "PLAYER_TARGET_CHANGED" then
    lastChangeTargetTime = GetTime()
  end

  if event == "UNIT_SPELLCAST_SENT" and arg == "player" then
    if LFGDEBUG and DLAPI then
      DLAPI.DebugLog("LifaGuardian", "===== LIFA GUARDIAN DEBUG =====")
      for i=1,#OPERATIONS do
        DLAPI.DebugLog("LifaGuardian", OPERATIONS[i])
      end
    end
  end

  if event == "COMBAT_LOG_EVENT_UNFILTERED" then
    local _, subEvent, _, _, _, sourceFlags, _, destGUID, destName = CombatLogGetCurrentEventInfo()
    if subEvent == "UNIT_DIED" then
      RemoveEnemy(destGUID)
    elseif (bit.band(sourceFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) > 0
        or bit.band(sourceFlags, COMBATLOG_OBJECT_AFFILIATION_PARTY) > 0
        or bit.band(sourceFlags, COMBATLOG_OBJECT_AFFILIATION_RAID) > 0)
        and (subEvent == "SWING_DAMAGE" or subEvent == "SPELL_DAMAGE") then
      AddEnemy(destGUID, destName)
    end
  end
end
frame:SetScript("OnEvent", frame.OnEvent)
msgEventRegister()

if DBM then
  DBM:RegisterCallback("DBM_TimerStart", DBMEventsHandler)
  DBM:RegisterCallback("DBM_TimerUpdate", DBMEventsHandler)
  DBM:RegisterCallback("DBM_TimerStop", DBMEventsHandler)
end

if BigWigsLoader then
  local plugin = {}
  BigWigsLoader.RegisterMessage(plugin, "BigWigs_StartBar", BWEventsHandler)
  BigWigsLoader.RegisterMessage(plugin, "BigWigs_StopBar", BWEventsHandler)
  BigWigsLoader.RegisterMessage(plugin, "BigWigs_StopBars", BWEventsHandler)
end