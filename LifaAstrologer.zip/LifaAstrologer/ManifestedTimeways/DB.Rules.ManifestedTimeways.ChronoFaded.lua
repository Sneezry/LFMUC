LFA.DB.Rules.ManifestedTimeways.ChronoFaded = {
  spells = LFA.DB.Spells.dispelm,
  template = [[unit,instance.type=party|group.type=party,spell.%s=true,unit.debuff:时光凋零>0,unit.debuff:加速时间>0
action,action.key=%s,instance.type=party|group.type=party,spell.%s=true,target.debuff:时光凋零>0,target.debuff:加速时间>0]],
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {}
}