local _, LFG = ...

local function GetAllFilteredEnemies(filter)
  if filter.property == "count" then
    local filteredEnemyCount = #LFG.filteredEnemies
    LFG.filteredEnemies = LFG.GetAllEnemies()

    if filter.operator == "=" and filteredEnemyCount == filter.value
        or filter.operator == "~" and filteredEnemyCount ~= filter.value
        or filter.operator == "<" and filteredEnemyCount < filter.value
        or filter.operator == ">" and filteredEnemyCount > filter.value then
      return true
    end
    
    return nil
  end

  LFG.filteredEnemies = LFG.GetFilteredItem(LFG.filteredEnemies, filter)
  return LFG.filteredEnemies
end

LFG.RegisterGeneralFilterHandler("enemies", GetAllFilteredEnemies)