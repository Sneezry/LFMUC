local _, LFG = ...

local function GetUnitTargetOfSpells(unit)
  local targetOfSpells = {}

  for k,v in pairs(LFG.CASTING_SPELLS) do
    if UnitIsUnit(v.target, unit) then
      local spellName = GetSpellInfo(v.spellID)
      targetOfSpells["targetofspell:" .. v.spellID] = true
      targetOfSpells["targetofspell:" .. spellName] = true
    end
  end

  return targetOfSpells
end

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return string.sub(key, 1, 13) == "targetofspell"
  end,
  true,
  function(key, info)
    local targetofspell = GetUnitTargetOfSpells(info.unit)
    for k,v in pairs(targetofspell) do info[k] = v end
  end
)