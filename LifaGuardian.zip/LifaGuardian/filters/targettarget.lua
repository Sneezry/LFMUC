local _, LFG = ...

local function GetFilteredTargettarget(filter)
  return LFG.GetFilteredUnit("targettarget", filter)
end

LFG.RegisterGeneralFilterHandler("targettarget", GetFilteredTargettarget)