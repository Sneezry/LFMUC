local _, LFA = ...

LFA.Subscription = {
  {
    name = "打断",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.Interrupt }
  },
  {
    name = "鼠标指向打断",
    targettype = "mouseover",
    defaultdisabled = true,
    tooltip = { "需要指定按键“鼠标指向<技能>”", "比如：key,key.鼠标指向脚踢=f8", "需要配合鼠标指向宏", "比如：/cast [@mouseover] 脚踢" },
    rules = { LFA.DB.Rules.Interrupt }
  },
  {
    name = "焦点打断",
    targettype = "focus",
    defaultdisabled = true,
    tooltip = { "需要指定按键“焦点<技能>”", "比如：key,key.焦点脚踢=f8", "需要配合焦点宏", "比如：/cast [@focus] 脚踢" },
    rules = { LFA.DB.Rules.Interrupt }
  },
  {
    name = "强控",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.CC }
  },
  {
    name = "鼠标指向强控",
    targettype = "mouseover",
    defaultdisabled = true,
    tooltip = { "需要指定按键“鼠标指向<技能>”", "比如：key,key.鼠标指向肾击=f8", "需要配合鼠标指向宏", "比如：/cast [@mouseover] 肾击" },
    rules = { LFA.DB.Rules.CC }
  },
  {
    name = "焦点强控",
    targettype = "focus",
    defaultdisabled = true,
    tooltip = { "需要指定按键“焦点<技能>”", "比如：key,key.焦点肾击=f8", "需要配合焦点宏", "比如：/cast [@focus] 肾击" },
    rules = { LFA.DB.Rules.CC }
  },
  {
    name = "虚体控制",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.IncorporealCC }
  },
  {
    name = "鼠标指向虚体控制",
    defaultdisabled = true,
    tooltip = { "需要指定按键“鼠标指向<技能>”", "比如：key,key.鼠标指向休眠=f6", "需要配合鼠标指向宏", "比如：/cast [@mouseover] 休眠" },
    rules = { LFA.DB.Rules.MouseoverIncorporealCC }
  },
  {
    name = "受难之魂",
    defaultdisabled = true,
    tooltip = { "需要指定按键“鼠标指向<技能>”", "比如：key,key.鼠标指向自然之愈=f8", "需要配合鼠标指向宏", "比如：/cast [@mouseover] 自然之愈" },
    rules = { LFA.DB.Rules.AfflictedSoulDispel }
  },
  {
    name = "驱散队友",
    targettype = "unit",
    defaultdisabled = true,
    rules = {
      LFA.DB.Rules.DispelMagic,
      LFA.DB.Rules.DispelCurse,
      LFA.DB.Rules.DispelPoison,
      LFA.DB.Rules.DispelDisease,
      LFA.DB.Rules.DispelBleed
    }
  },
  {
    name = "驱散激怒",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.DispelEnrage }
  },
  {
    name = "鼠标指向驱散激怒",
    targettype = "mouseover",
    defaultdisabled = true,
    tooltip = { "需要指定按键“鼠标指向<技能>”", "比如：key,key.鼠标指向安抚=f8", "需要配合鼠标指向宏", "比如：/cast [@mouseover] 安抚" },
    rules = { LFA.DB.Rules.DispelEnrage }
  },
  {
    name = "治疗石",
    defaultdisabled = true,
    rules = { "action,action.key=治疗石,item.治疗石=true,player.health<30,player.incombat=true" }
  },
  {
    name = "振奋治疗药水",
    defaultdisabled = true,
    tooltip = { "需要指定按键“振奋治疗药水”", "比如：key,key.振奋治疗药水=f8" },
    rules = { "action,action.key=振奋治疗药水,item.振奋治疗药水=true,player.health<30,player.incombat=true" }
  },
  {
    name = "鼠标指向切换重要目标",
    defaultdisabled = true,
    tooltip = { "需要指定按键“选择鼠标指向目标”，并且需要配合宏命令", "比如：key,key.选择鼠标指向目标=f1", "对应的宏命令：/tar [@mouseover]" },
    rules = {
      "action,action.key=选择鼠标指向目标,target.name~永恒暮光大法师,target.name~永恒治历者,target.name~凝结时刻,target.name~时流汲取者,target.name~伊律迪孔的造物,target.name~复生的巨龙,target.name~时间线掠夺者,target.name~永恒裂隙法师,target.name~永茂博学者,target.name~疯狂的奥法师,target.name~繁茂古树,target.name~纳兹夏尔神谕者,target.name~纳兹夏尔神谕者,target.name~纳兹夏尔冰霜女巫,target.name~风暴之舞图腾,target.name~无面先知,target.name~海地精水术师,target.name~秽斑,target.name~幽灵顾问,target.name~艾瑟德林·拉文凯斯领主,target.name~复活的奥术师,target.name~复活的奥术师,target.name~大法师加里昂,target.name~魔怨支配者,target.name~鸦堡织网蛛,target.name~复活的小伙伴,target.name~毒心诱魂者,target.name~贪吃的蛆虫,target.name~女巫会塑棘者,target.name~高莱克·图尔,target.name~主母阿尔玛,target.name~达萨莱占卜师,target.name~飨宴的啸天龙,target.name~赞枢利巫医,target.name~沃卡尔,target.name~精神错乱的尖啸夜枭,target.name~恐魂毁灭者,target.name~梦魇住民,target.name~腐心守护者,mouseover.name=永恒暮光大法师|mouseover.name=永恒治历者|mouseover.name=凝结时刻|mouseover.name=时流汲取者|mouseover.name=伊律迪孔的造物|mouseover.name=复生的巨龙|mouseover.name=时间线掠夺者|mouseover.name=永恒裂隙法师|mouseover.name=永茂博学者|mouseover.name=疯狂的奥法师|mouseover.name=繁茂古树|mouseover.name=纳兹夏尔神谕者|mouseover.name=纳兹夏尔神谕者|mouseover.name=纳兹夏尔冰霜女巫|mouseover.name=风暴之舞图腾|mouseover.name=无面先知|mouseover.name=海地精水术师|mouseover.name=秽斑|mouseover.name=幽灵顾问|mouseover.name=艾瑟德林·拉文凯斯领主|mouseover.name=复活的奥术师|mouseover.name=复活的奥术师|mouseover.name=大法师加里昂|mouseover.name=魔怨支配者|mouseover.name=鸦堡织网蛛|mouseover.name=复活的小伙伴|mouseover.name=毒心诱魂者|mouseover.name=贪吃的蛆虫|mouseover.name=女巫会塑棘者|mouseover.name=高莱克·图尔|mouseover.name=主母阿尔玛|mouseover.name=达萨莱占卜师|mouseover.name=飨宴的啸天龙|mouseover.name=赞枢利巫医|mouseover.name=沃卡尔|mouseover.name=精神错乱的尖啸夜枭|mouseover.name=恐魂毁灭者|mouseover.name=梦魇住民|mouseover.name=腐心守护者,mouseover.isdead=false",
      "action,action.key=选择鼠标指向目标,player.hastarget=false,mouseover.name=永恒暮光大法师|mouseover.name=永恒治历者|mouseover.name=凝结时刻|mouseover.name=时流汲取者|mouseover.name=伊律迪孔的造物|mouseover.name=复生的巨龙|mouseover.name=时间线掠夺者|mouseover.name=永恒裂隙法师|mouseover.name=永茂博学者|mouseover.name=疯狂的奥法师|mouseover.name=繁茂古树|mouseover.name=纳兹夏尔神谕者|mouseover.name=纳兹夏尔神谕者|mouseover.name=纳兹夏尔冰霜女巫|mouseover.name=风暴之舞图腾|mouseover.name=无面先知|mouseover.name=海地精水术师|mouseover.name=秽斑|mouseover.name=幽灵顾问|mouseover.name=艾瑟德林·拉文凯斯领主|mouseover.name=复活的奥术师|mouseover.name=复活的奥术师|mouseover.name=大法师加里昂|mouseover.name=魔怨支配者|mouseover.name=鸦堡织网蛛|mouseover.name=复活的小伙伴|mouseover.name=毒心诱魂者|mouseover.name=贪吃的蛆虫|mouseover.name=女巫会塑棘者|mouseover.name=高莱克·图尔|mouseover.name=主母阿尔玛|mouseover.name=达萨莱占卜师|mouseover.name=飨宴的啸天龙|mouseover.name=赞枢利巫医|mouseover.name=沃卡尔|mouseover.name=精神错乱的尖啸夜枭|mouseover.name=恐魂毁灭者|mouseover.name=梦魇住民|mouseover.name=腐心守护者,mouseover.isdead=false"
    }
  },
  {
    name = "切换推荐目标",
    defaultdisabled = true,
    tooltip = { "需要指定按键“切换目标”", "比如：key,key.切换目标=tab", "推荐目标根据 Hekili 提示" },
    rules = { "action,action.key=切换目标,hekili.targetswap=true" }
  },
  {
    name = "永恒黎明",
    defaultdisabled = true,
    rules = {
      LFA.DB.Rules.ManifestedTimeways.ChronoFaded,
      LFA.DB.Rules.ManifestedTimeways.Corrosion
    }
  },
  {
    name = "[骑士] 自由祝福",
    targettype = "unit",
    defaultdisabled = true,
    rules = {
      LFA.DB.Rules.Freedom
    }
  },
  {
    name = "[骑士] 自由祝福（坦克缠绕）",
    targettype = "unit",
    targetfilters = {
      "role=tank"
    },
    defaultdisabled = true,
    rules = {
      LFA.DB.Rules.FreedomEntangled
    }
  },
  {
    name = "[骑士] 保护祝福",
    targettype = "unit",
    targetfilters = {
      "role~tank"
    },
    defaultdisabled = true,
    rules = {
      LFA.DB.Rules.Protection
    }
  }
}
