local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "ismoving"
  end,
  true,
  function(key, info)
    info.ismoving = GetUnitSpeed(info.unit) > 0
  end
)