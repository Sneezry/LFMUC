local _, LFG = ...

local function GetFilteredMouseover(filter)
  return LFG.GetFilteredUnit("mouseover", filter)
end

LFG.RegisterGeneralFilterHandler("mouseover", GetFilteredMouseover)