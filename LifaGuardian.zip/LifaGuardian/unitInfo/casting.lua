local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "casting" or key == "castingid" or key == "castingleft" or key == "castingpast"
  end,
  true,
  function(key, info)
    local casting, _, _, castingStartTime, castingEndTime, _, _, _, _, spellId = UnitCastingInfo(info.unit)
    info.casting = casting
    info.castingid = spellId
    info.castingleft = castingEndTime and (castingEndTime/1000 - GetTime()) or 0
    info.castingpast = castingStartTime and (GetTime() - castingStartTime/1000) or 0
  end
)