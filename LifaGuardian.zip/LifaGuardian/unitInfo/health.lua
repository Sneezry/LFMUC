local _, LFG = ...

local function GetUnitHealPercentage(unit)
  local incomingHeals = UnitGetIncomingHeals(unit)
  return (UnitHealth(unit) + (incomingHeals == nil and 0 or incomingHeals)) * 100 / UnitHealthMax(unit)
end

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "health"
  end,
  true,
  function(key, info)
    info.health = GetUnitHealPercentage(info.unit)
  end
)