local _, LFA = ...

LFA.Subscription = {
  {
    name = "打断",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.Interrupt }
  },
  {
    name = "强控",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.CC }
  },
  {
    name = "虚体控制",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.IncorporealCC }
  },
  {
    name = "鼠标指向虚体控制",
    defaultdisabled = true,
    tooltip = { "需要指定按键“鼠标指向<技能>”", "比如：key,key.鼠标指向休眠=f6", "需要配合鼠标指向宏", "比如：/cast [@mouseover] 休眠" },
    rules = { LFA.DB.Rules.MouseoverIncorporealCC }
  },
  {
    name = "受难之魂",
    defaultdisabled = true,
    tooltip = { "需要指定按键“鼠标指向<技能>”", "比如：key,key.鼠标指向自然之愈=f8", "需要配合鼠标指向宏", "比如：/cast [@mouseover] 自然之愈" },
    rules = { LFA.DB.Rules.AfflictedSoulDispel }
  },
  {
    name = "驱散队友",
    targettype = "unit",
    defaultdisabled = true,
    rules = {
      LFA.DB.Rules.DispelMagic,
      LFA.DB.Rules.DispelCurse,
      LFA.DB.Rules.DispelPoison,
      LFA.DB.Rules.DispelDisease,
      LFA.DB.Rules.DispelBleed
    }
  },
  {
    name = "驱散激怒",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.DispelEnrage }
  },
  {
    name = "治疗石",
    defaultdisabled = true,
    rules = { "action,action.key=治疗石,item.治疗石=true,player.health<20,player.incombat=true" }
  },
  {
    name = "振奋治疗药水",
    defaultdisabled = true,
    tooltip = { "需要指定按键“振奋治疗药水”", "比如：key,key.振奋治疗药水=f8" },
    rules = { "action,action.key=振奋治疗药水,item.振奋治疗药水=true,player.health<20,player.incombat=true" }
  },
  {
    name = "切换推荐目标",
    defaultdisabled = true,
    tooltip = { "需要指定按键“切换目标”", "比如：key,key.切换目标=tab", "推荐目标根据 Hekili 提示" },
    rules = { "action,action.key=切换目标,hekili.targetswap=true" }
  },
  {
    name = "永恒黎明",
    defaultdisabled = true,
    rules = {
      LFA.DB.Rules.ManifestedTimeways.ChronoFaded,
      LFA.DB.Rules.ManifestedTimeways.Corrosion
    }
  }
}
