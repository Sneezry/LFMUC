local _, LFA = ...

LFA.DB.Rules.DispelMagic = {
  spells = LFA.DB.Spells.dispelm,
  casting = {},
  channel = {},
  buff = {},
  debuff = {}
}