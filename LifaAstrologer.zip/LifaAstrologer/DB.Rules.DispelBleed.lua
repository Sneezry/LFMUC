local _, LFA = ...

LFA.DB.Rules.DispelBleed = {
  spells = LFA.DB.Spells.dispelb,
  casting = {},
  channel = {},
  buff = {},
  debuff = {}
}