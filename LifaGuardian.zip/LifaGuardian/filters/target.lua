local _, LFG = ...

local function GetFilteredTarget(filter)
  return LFG.GetFilteredUnit("target", filter)
end

LFG.RegisterGeneralFilterHandler("target", GetFilteredTarget)