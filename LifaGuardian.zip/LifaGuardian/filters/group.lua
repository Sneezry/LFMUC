local _, LFG = ...

local function GetFilteredGroup(filter)
  if filter.property ~= "type" then
    return nil
  end

  local isInRaid = IsInRaid()
  local isInGroup = IsInGroup()

  if filter.operator == "=" and filter.value == "raid" and isInRaid
      or filter.operator == "~" and filter.value == "raid" and not isInRaid
      or filter.operator == "=" and filter.value == "party" and not isInRaid and isInGroup
      or filter.operator == "~" and filter.value == "party" and (isInRaid or not isInGroup) then
    return true
  end

  return nil
end

LFG.RegisterGeneralFilterHandler("group", GetFilteredGroup)