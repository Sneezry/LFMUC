local _, LFA = ...

LFA.DB.Rules.DispelCurse = {
  spells = LFA.DB.Spells.dispelc,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {
    -- 永恒黎明崛起(下)
    "永恒诅咒",
    -- 维克雷斯庄园
    -- "符文印记", "不稳定的符文印记", -- 驱散会炸团，不要自动秒驱
    -- 潮汐王座
    "妖术"
  },
  targetofspell = {}
}