local _, LFA = ...

LFA.DB.Rules.DispelEnrage = {
  spells = LFA.DB.Spells.dispele,
  name = {},
  casting = {},
  channel = {},
  buff = {
    -- 永茂林地
    "激怒",
    -- 潮汐王座
    "蛇形突击"
  },
  debuff = {},
  targetofspell = {}
}