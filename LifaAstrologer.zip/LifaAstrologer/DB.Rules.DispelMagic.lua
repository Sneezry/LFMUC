local _, LFA = ...

LFA.DB.Rules.DispelMagic = {
  spells = LFA.DB.Spells.dispelm,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {
    -- 注能大厅
    "熔火隐没","冰霜震击",
    -- 蕨皮山谷
    "腐朽感官",
    -- 旋云之巅
    "呼啸劲风",
    -- 孢子林
    "邪恶拥抱","疯狂凝视",
    -- 奥达曼
    "剧毒之牙",
    -- 自由镇
    "艾泽里特填装弹","冰霜冲击","浸油之刃"
  }
}