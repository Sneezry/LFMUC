local _, LFG = ...

local function GetFilteredSpellCharge(filter)
  local charges = GetSpellCharges(filter.property)

  if filter.operator == "=" and charges == filter.value
      or filter.operator == "~" and charges ~= filter.value
      or filter.operator == "<" and charges < filter.value
      or filter.operator == ">" and charges > filter.value then
    return true
  end
  
  return nil
end

LFG.RegisterGeneralFilterHandler("spellcharge", GetFilteredSpellCharge)