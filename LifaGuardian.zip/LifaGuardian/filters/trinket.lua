local _, LFG = ...

local function GetTrinketInfo(slot)
  local id = GetInventoryItemID("player", slot)
  if id == nil then
    return nil, nil
  end

  local name = GetItemInfo(id)
  return name, id
end

local function GetFilteredTrinket(filter)
  local name13, id13 = GetTrinketInfo(13)
  local name14, id14 = GetTrinketInfo(14)

  if name13 ~= filter.property and name14 ~= filter.property and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  if name13 ~= filter.property and name14 ~= filter.property and filter.value then
    if filter.operator == "=" then
      return nil
    else
      return { filter.property }
    end
  end

  local id = name13 == filter.property and id13 or id14
  local _, duration, enable = GetItemCooldown(id)

  local useable = enable and duration == 0
  if useable and filter.value or not useable and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  return nil
end

LFG.RegisterGeneralFilterHandler("trinket", GetFilteredTrinket)
LFG.RegisterGeneralFilterHandler("sp", GetFilteredTrinket)