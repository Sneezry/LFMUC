local _, LFA = ...

local function GetPlayerSpells(spells)
  local playerSpells = {}

  for _,spell in pairs(spells) do
    if IsPlayerSpell(spell.id) and (spell.talent == nil or IsPlayerSpell(spell.talent)) then
      table.insert(playerSpells, spell.id)
    end
  end
  return playerSpells
end

local function GenerateRuleForSingleSpell(command, rule, spell, isNoTarget)
  local spellName = GetSpellInfo(spell)

  if rule.template ~= nil then
    return string.gsub(rule.template, "%%s", spellName)
  end

  local target = command == "action" and "target" or command

  local conditions = {}
  for _,castingSpell in pairs(rule.casting) do
    table.insert(conditions, target..".casting="..castingSpell)
  end
  for _,channelSpell in pairs(rule.channel) do
    table.insert(conditions, target..".channel="..channelSpell)
  end
  for _,buff in pairs(rule.buff) do
    table.insert(conditions, target..".buff:"..buff..">0")
  end
  for _,debuff in pairs(rule.debuff) do
    table.insert(conditions, target..".debuff:"..debuff..">0")
  end
  for _,name in pairs(rule.name) do
    table.insert(conditions, target..".name="..name)
  end

  if #conditions > 0 then
    local commandWithIcon = command..","..(command == "action" and "action.key="..spellName.."," or "").."spell."..spellName.."=true,"..(not isNoTarget and (target..".spellinrange:"..spellName.."=true,") or "").."var.WatchIcon~nil,"..target..".icon=var:WatchIcon,"..table.concat(conditions, "||")
    return commandWithIcon.."\n"..command..","..(command == "action" and "action.key="..spellName.."," or "").."spell."..spellName.."=true,"..(not isNoTarget and (target..".spellinrange:"..spellName.."=true,") or "")..(rule.win and command == "action" and "player."..rule.win.."=true," or "")..table.concat(conditions, "||")
  end

  return nil
end

local function BuildRulesFromCommandAndSubscription(command, subscription)
  local rules = {}
  local win = subscription

  for _,rule in pairs(subscription.rules) do
    if type(rule) == "string" then
      table.insert(rules, rule)
    else
      local playerSpells = GetPlayerSpells(rule.spells)
      if #playerSpells > 0 then
        for _,playerSpell in pairs(playerSpells) do
          local singleRule = GenerateRuleForSingleSpell(command, rule, playerSpell, not subscription.targettype)
          if singleRule then
            table.insert(rules, singleRule)
          end
        end
      end
    end
  end

  return #rules > 0 and table.concat(rules, "\n") or nil
end

local function BuildRulesFromCommands(commands)
  LFA.Rules = {}

  for command,subscriptions in pairs(commands) do
    for _,subscription in pairs(subscriptions) do
      local rules = BuildRulesFromCommandAndSubscription(command, subscription)
      if rules then
        LFA.Rules[command..":"..subscription.name] = rules
      end
    end
  end
end

LFA.RulesBuilder = function()
  local specialization = GetSpecialization()
  local subscriptionList = LF_Astrologer_Subscription[specialization] or {}

  local commands = {
    unit = {},
    enemy = {},
    action = {}
  }

  for _,subscription in pairs(LFA.Subscription) do
    local subscribed = LF_Astrologer_Subscription[specialization][subscription.name] == nil or LF_Astrologer_Subscription[specialization][subscription.name].subscribed ~= false

    if subscribed then
      table.insert(commands.action, subscription)

      local autoSelect = LF_Astrologer_Subscription[specialization][subscription.name] and LF_Astrologer_Subscription[specialization][subscription.name].autoSelect
      if autoSelect and (subscription.targettype == "enemy" or subscription.targettype == "unit") then
        table.insert(commands[subscription.targettype], subscription)
      end
    end
  end

  return BuildRulesFromCommands(commands)
end