local _, LFA = ...

LFA.DB.Rules.DispelDisease = {
  spells = LFA.DB.Spells.dispeld,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {}
}