local _, LFG = ...

local function GetUnitBuff(unit)
  local buffs, i = { }, 1
  local buff, _, count, _, duration, expTime, caster, _, _, spellId = UnitBuff(unit, i)

  while buff do
    local leftTime = expTime == 0 and 86400 or expTime - GetTime()
    local pastTime = expTime == 0 and 86400 or (GetTime() - (expTime - duration))
    buffs["buff:" .. buff] = math.max(count, 1)
    buffs["buffleft:" .. buff] = leftTime
    buffs["buffpast:" .. buff] = pastTime
    buffs["buff:" .. tostring(spellId)] = math.max(count, 1)
    buffs["buffleft:" .. tostring(spellId)] = leftTime
    buffs["buffpast:" .. tostring(spellId)] = pastTime
    if caster == "player" then
      buffs["bufffromplayer:" .. buff] = math.max(count, 1)
      buffs["bufffromplayerleft:" .. buff] = leftTime
      buffs["bufffromplayerpast:" .. buff] = pastTime
      buffs["bufffromplayer:" .. tostring(spellId)] = math.max(count, 1)
      buffs["bufffromplayerleft:" .. tostring(spellId)] = leftTime
      buffs["bufffromplayerpast:" .. tostring(spellId)] = pastTime
    end
    i = i + 1
    buff, _, count, _, _, expTime, caster = UnitBuff(unit, i)
  end

  return buffs
end

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return string.sub(key, 1, 4) == "buff" and info.buffcached ~= 1
  end,
  true,
  function(key, info)
    local buff = GetUnitBuff(info.unit)
    for k,v in pairs(buff) do info[k] = v end
    info.buffcached = 1
  end
)