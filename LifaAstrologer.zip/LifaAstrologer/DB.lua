local _, LFA = ...

LFA.DB = {
  Rules = {}
}
