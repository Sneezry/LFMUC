local _, LFA = ...

LFA.DB.Rules.IncorporealCC = {
  spells = LFA.DB.Spells.incorporealcc,
  name = {},
  casting = {"失衡"},
  channel = {},
  buff = {},
  debuff = {},
  targetofspell = {}
}