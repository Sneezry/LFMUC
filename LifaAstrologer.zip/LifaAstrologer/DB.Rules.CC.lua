local _, LFA = ...

LFA.DB.Rules.CC = {
  spells = LFA.DB.Spells.cc,
  win = ccwin,
  name = {},
  casting = {
    "战鼓",
    -- 注能大厅
    "震地猛击",
    -- 蕨皮山谷
    "白骨箭",
    -- 孢子林
    "腐化胆汁","石雹",
    -- 巢穴
    "锯齿圆盘","蛆虫呼唤",
    -- 自由镇
    "盲目怒火","“蕉”燥狂攻",
    -- 山谷
    "恶毒爪击"
  },
  channel = {
    -- 注能大厅
    "密闭射线"
  },
  buff = {},
  debuff = {}
}