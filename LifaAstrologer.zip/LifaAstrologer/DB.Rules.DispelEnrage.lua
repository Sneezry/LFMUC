local _, LFA = ...

LFA.DB.Rules.DispelEnrage = {
  spells = LFA.DB.Spells.dispele,
  name = {},
  casting = {},
  channel = {"狂怒风暴"},
  buff = {"狂乱"},
  debuff = {},
  targetofspell = {}
}