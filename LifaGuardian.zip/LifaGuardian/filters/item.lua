local _, LFG = ...

local function GetItemId(itemName)
  for bag=0,NUM_BAG_SLOTS do
    for slot=1,C_Container.GetContainerNumSlots(bag) do
      local link = C_Container.GetContainerItemLink(bag, slot)
      if link ~= nil and GetItemInfo(link) == itemName then
          return C_Container.GetContainerItemID(bag, slot)
      end
    end
  end
  return nil
end

local function GetFilteredContainerItem(filter)
  local id = GetItemId(filter.property)
  if id == nil and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  local spellName, spellId = id and GetItemSpell(id) or nil

  if spellId == nil then
    if filter.operator == "=" then
      return not filter.value and { filter.property } or nil
    else
      return filter.value and { filter.property } or nil
    end
  end

  local _, duration = GetSpellCooldown(spellId)

  local useable = IsUsableSpell(spellId) and duration == 0
  if useable and filter.value or not useable and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  return nil
end

LFG.RegisterGeneralFilterHandler("item", GetFilteredContainerItem)