local _, LFA = ...

LFA.DB.Rules.AfflictedSoulDispel = {
  spells = LFA.DB.Spells.afflicatedsouldispel,
  name = {"受难之魂"},
  casting = {},
  channel = {},
  buff = {},
  debuff = {}
}