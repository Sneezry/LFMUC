local _, LFA = ...

-- 打断
local INTERRUPT_SPELLS = {
  { id = 6552 },            -- 战士 - 拳击
  { id = 386071 },          -- 战士 - 瓦解怒吼（天赋）
  { id = 1766 },            -- 盗贼 - 脚踢
  { id = 183752 },          -- DH - 瓦解
  { id = 116705 },          -- 武僧 - 切喉手
  { id = 47528 },           -- DK - 心灵冰冻
  { id = 187707 },          -- 猎人 - 压制（天赋）
  { id = 147362 },          -- 猎人 - 反制射击
  { id = 351338 },          -- 小龙人 - 镇压（天赋）
  { id = 106839 },          -- 德鲁伊 - 迎头痛击（天赋）
  { id = 15487 },           -- 牧师 - 沉默（天赋）
  { id = 31935 },           -- 圣骑士 - 复仇者之盾（天赋）
  { id = 96231 },           -- 圣骑士 - 责难（天赋）
  { id = 57994 },           -- 萨满 - 风剪（天赋）
  { id = 2139 },            -- 法师 - 法术反制
}

-- 硬控
local CROWD_CONTROL_SPELLS = {
  { id = 408 },             -- 盗贼 - 肾击
  { id = 2094 },            -- 盗贼 - 致盲
  { id = 1776 },            -- 盗贼 - 凿击
  { id = 5211 },            -- 德鲁伊 - 蛮力猛击
  { id = 853 },             -- 圣骑士 - 制裁之锤
  { id = 115750 },          -- 圣骑士 - 盲目之光
  { id = 360806 },          -- 小龙人 - 梦游
  { id = 221562 },          -- DK - 窒息
  { id = 19577, pet = true }, -- 猎人 - 胁迫
  { id = 115078 },          -- 武僧 - 分筋错骨
  { id = 88625 },           -- 牧师 - 圣言术：罚
  { id = 64044 },           -- 牧师 - 心灵惊骇
  { id = 107570 },          -- 战士 - 风暴之锤
  { id = 305483 },          -- 萨满 - 闪电磁索
  { id = 6789 },            -- 术士 - 死亡缠绕
  { id = 211881 }           -- DH - 邪能爆发
}

-- 虚体硬控
local INCORPOREAL_CROWD_CONTROL_SPELLS = {
  { id = 2094 },            -- 盗贼 - 致盲
  { id = 360806 },          -- 小龙人 - 梦游
  { id = 118 },             -- 法师 - 变形术
  { id = 2637 },            -- 德鲁伊 - 休眠
  { id = 9484 },            -- 牧师 - 束缚亡灵
  { id = 217832 },          -- DH - 禁锢
  { id = 710 },             -- 术士 - 放逐
  { id = 5782 },            -- 术士 - 恐惧
  { id = 14326 },           -- 猎人 - 恐吓野兽
  { id = 115078 },          -- 武僧 - 分筋错骨
  { id = 20066 },           -- 圣骑士 - 忏悔
  { id = 10326 },           -- 圣骑士 - 超度邪恶
  { id = 51514 }            -- 萨满 - 妖术
}

-- 驱散魔法
local DISPEL_MAGIC_SPELLS = {
  { id = 528 },             -- 牧师 - 驱散魔法
  { id = 4987 },            -- 圣骑士 - 清洁术
  { id = 88423 },           -- 德鲁伊 - 自然之愈
  { id = 115450 },          -- 武僧 - 清创生血
  { id = 77130 }            -- 萨满 - 净化灵魂
}

-- 驱散疾病
local DISPEL_DISEASE_SPELLS = {
  { id = 213634 },          -- 牧师 - 净化疾病
  { id = 4987, talent = 393024 }, -- 圣骑士 - 强化清洁术
  { id = 213644 },          -- 圣骑士 - 清毒术
  { id = 218164 },          -- 武僧 - 清创生血
  { id = 374251 }           -- 小龙人 - 灼烧之焰
}

-- 驱散中毒
local DISPEL_POISON_SPELLS = {
  { id = 4987, talent = 393024 }, -- 圣骑士 - 强化清洁术
  { id = 213644 },          -- 圣骑士 - 清毒术
  { id = 88423, talent = 392378 }, -- 德鲁伊 - 强化自然之愈
  { id = 218164 },          -- 武僧 - 清创生血
  { id = 374251 },          -- 小龙人 - 灼烧之焰
  { id = 365585 }           -- 小龙人 - 净除
}

-- 驱散诅咒
local DISPEL_CURSE_SPELLS = {
  { id = 88423, talent = 392378 }, -- 德鲁伊 - 强化自然之愈
  { id = 374251 },          -- 小龙人 - 灼烧之焰
  { id = 51886 },           -- 萨满 - 净化灵魂
  { id = 475 }              -- 法师 - 解除诅咒
}

-- 驱散流血
local DISPEL_BLEED_SPELLS = {
  { id = 374251 }           -- 小龙人 - 灼烧之焰
}

-- 驱散激怒
local DISPEL_ENRAGE_SPELLS = {
  { id = 19801 },           -- 猎人 - 宁神射击
  { id = 2908 },            -- 德鲁伊 - 安抚
  { id = 5938 }             -- 盗贼 - 毒刃
}

-- 驱散受难之魂
local AFFLICTED_SOUL_DISPEL_SPELLS = {
  { id = 4987 },            -- 圣骑士 - 清洁术
  { id = 88423 },           -- 德鲁伊 - 自然之愈
  { id = 115450 },          -- 武僧 - 清创生血
  { id = 77130 },           -- 萨满 - 净化灵魂
  { id = 213634 },          -- 牧师 - 净化疾病
  { id = 213644 },          -- 圣骑士 - 清毒术
  { id = 218164 },          -- 武僧 - 清创生血
  { id = 374251 },          -- 小龙人 - 灼烧之焰
  { id = 365585 },          -- 小龙人 - 净除
  { id = 51886 },           -- 萨满 - 净化灵魂
  { id = 475 }              -- 法师 - 解除诅咒
}

LFA.DB.Spells = {
  interrupt = INTERRUPT_SPELLS,
  cc = CROWD_CONTROL_SPELLS,
  incorporealcc = INCORPOREAL_CROWD_CONTROL_SPELLS,
  dispelm = DISPEL_MAGIC_SPELLS,
  dispeld = DISPEL_DISEASE_SPELLS,
  dispelp = DISPEL_POISON_SPELLS,
  dispelc = DISPEL_CURSE_SPELLS,
  dispelb = DISPEL_BLEED_SPELLS,
  dispele = DISPEL_ENRAGE_SPELLS,
  afflicatedsouldispel = AFFLICTED_SOUL_DISPEL_SPELLS
}