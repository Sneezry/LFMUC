local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "msg" or key == "msgchannel"
  end,
  true,
  function(key, info)
    local msgQueue = LFG.msgQueue
    for i=1,#msgQueue do
      local msg = msgQueue[i]
      if msg.time >= GetTime() - 1 and msg.sender == fullname then
        info["msg"] = msg.msg
        info["msgchannel"] = msg.channel
        break
      end
    end
  end
)