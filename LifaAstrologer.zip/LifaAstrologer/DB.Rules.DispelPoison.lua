local _, LFA = ...

LFA.DB.Rules.DispelPoison = {
  spells = LFA.DB.Spells.dispelp,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {
    -- 蕨皮山谷
    "枯萎毒药","腐朽感官","腐朽根须",
    -- 注能大厅
    "巨口蛙毒:7"
  },
  targetofspell = {}
}