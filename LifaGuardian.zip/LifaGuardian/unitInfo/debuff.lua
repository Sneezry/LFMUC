local _, LFG = ...

local function GetUnitDebuff(unit)
  local debuffs, i = { }, 1
  local debuff, _, count, _, duration, expTime, caster, _, _, spellId = UnitDebuff(unit, i)

  while debuff do
    local leftTime = expTime == 0 and 86400 or floor(expTime - GetTime())
    local pastTime = expTime == 0 and 86400 or (GetTime() - (expTime - duration))
    debuffs["debuff:" .. debuff] = math.max(count, 1)
    debuffs["debuffleft:" .. debuff] = leftTime
    debuffs["debuffpast:" .. debuff] = pastTime
    debuffs["debuff:" .. tostring(spellId)] = math.max(count, 1)
    debuffs["debuffleft:" .. tostring(spellId)] = leftTime
    debuffs["debuffpast:" .. tostring(spellId)] = pastTime
    if caster == "player" then
      debuffs["debufffromplayer:" .. debuff] = math.max(count, 1)
      debuffs["debufffromplayerleft:" .. debuff] = leftTime
      debuffs["debufffromplayerpast:" .. debuff] = pastTime
      debuffs["debufffromplayer:" .. tostring(spellId)] = math.max(count, 1)
      debuffs["debufffromplayerleft:" .. tostring(spellId)] = leftTime
      debuffs["debufffromplayerpast:" .. tostring(spellId)] = pastTime
    end
    i = i + 1
    debuff, _, count, _, _, expTime, caster = UnitDebuff(unit, i)
  end

  return debuffs
end

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return string.sub(key, 1, 6) == "debuff" and info.debuffcached ~= 1
  end,
  true,
  function(key, info)
    local debuff = GetUnitDebuff(info.unit)
    for k,v in pairs(debuff) do info[k] = v end
    info.debuffcached = 1
  end
)