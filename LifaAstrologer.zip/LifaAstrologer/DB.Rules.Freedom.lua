local _, LFA = ...

LFA.DB.Rules.Freedom = {
  spells = LFA.DB.Spells.freedom,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {
    -- 蕨皮山谷
    "腐朽根须", "诱捕陷阱",
    -- 注能大厅
    "密闭射线", "熔火隐没", "极寒冰冻",
    -- 奥达曼
    "时光渗陷", "羁石诅咒",
    -- 自由镇
    "眩晕酒桶", "捕鼠陷阱",
    -- 孢子林
    "抓钩诱捕"
  },
  targetofspell = {}
}