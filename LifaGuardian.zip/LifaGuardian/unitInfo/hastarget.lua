local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "hastarget"
  end,
  true,
  function(key, info)
    info.hastarget = UnitExists((info.unit == "player" and "" or info.unit) .. "target")
  end
)