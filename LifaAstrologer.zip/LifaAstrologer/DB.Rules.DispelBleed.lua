local _, LFA = ...

LFA.DB.Rules.DispelBleed = {
  spells = LFA.DB.Spells.dispelb,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {}
}