local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "incombat"
  end,
  true,
  function(key, info)
    info.incombat = UnitAffectingCombat(info.unit)
  end
)