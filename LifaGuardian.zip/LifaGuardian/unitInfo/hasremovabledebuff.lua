local _, LFG = ...

local function HasRemovableDebuff(unit)
  if UnitDebuff(unit, 1, true) then
    return true
  end

  return false
end

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "hasremovabledebuff"
  end,
  true,
  function(key, info)
    info.hasremovabledebuff = HasRemovableDebuff(info.unit)
  end
)