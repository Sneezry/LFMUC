local _, LFA = ...

LFA.DB.Rules.Protection = {
  spells = LFA.DB.Spells.protection,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {},
  targetofspell = {}
}