LFA.DB.Rules.ManifestedTimeways.Corrosion = {
  spells = {},
  template = [[alarm,alarm.sound=Banana Peel Slip,instance.type=party|group.type=party,player.debuff:腐蚀>0,enemies.casting=荒芜回收,enemies.count>0
alarm,alarm.sound=Xylophone,instance.type=party|group.type=party,player.debuffleft:腐蚀<5]],
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {}
}