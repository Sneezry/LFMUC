local _, LFA = ...

LFA.Subscription = {
  {
    name = "打断",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.Interrupt }
  },
  {
    name = "强控",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.CC }
  },
  {
    name = "虚体控制",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.IncorporealCC }
  },
  {
    name = "受难之魂",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.AfflictedSoulDispel }
  },
  {
    name = "驱散队友",
    targettype = "unit",
    defaultdisabled = true,
    rules = {
      LFA.DB.Rules.DispelMagic,
      LFA.DB.Rules.DispelCurse,
      LFA.DB.Rules.DispelPoison,
      LFA.DB.Rules.DispelDisease,
      LFA.DB.Rules.DispelBleed
    }
  },
  {
    name = "驱散激怒",
    targettype = "enemy",
    defaultdisabled = true,
    rules = { LFA.DB.Rules.DispelEnrage }
  },
  {
    name = "治疗石",
    defaultdisabled = true,
    rules = { "action,action.key=治疗石,item.治疗石=true,player.health<20,player.incombat=true" }
  },
  {
    name = "振奋治疗药水（需要指定按键）",
    defaultdisabled = true,
    rules = { "action,action.key=振奋治疗药水,item.振奋治疗药水=true,player.health<20,player.incombat=true" }
  }
}
