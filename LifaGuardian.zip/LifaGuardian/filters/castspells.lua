local _, LFG = ...

local function GetFilteredCastSpells(filter)
  if filter.property == "count" then
    local filteredCastSpellCount = #LFG.filteredCastSpells
    LFG.filteredCastSpells = LFG.GetAllCastSpells()

    if filter.operator == "=" and filteredCastSpellCount == filter.value
        or filter.operator == "~" and filteredCastSpellCount ~= filter.value
        or filter.operator == "<" and filteredCastSpellCount < filter.value
        or filter.operator == ">" and filteredCastSpellCount > filter.value then
      return true
    end

    return nil
  end

  LFG.filteredCastSpells = LFG.GetFilteredItem(LFG.filteredCastSpells, filter)
  return LFG.filteredCastSpells
end

LFG.RegisterGeneralFilterHandler("castspells", GetFilteredCastSpells)