local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "canattack"
  end,
  true,
  function(key, info)
    info.canattack = UnitCanAttack("player", info.unit)
  end
)