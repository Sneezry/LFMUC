local _, LFA = ...

LFA.DB.Rules.CC = {
  spells = LFA.DB.Spells.cc,
  casting = {"战鼓"},
  channel = {
    -- 注能大厅
    "密闭射线",
    -- 孢子林
    "腐化胆汁"
  },
  buff = {},
  debuff = {}
}