local _, LFG = ...

function HasCCSpell(unit, classid)
  return LFG.HasCastableSpell(unit, classid, nil, {408, 2094, 1776, 5211, 853, 115750, 360806, 221562, 19577, 115078, 88625, 64044, 107570, 305483, 6789, 211881})
end

function IsWinnerToCC()
  if not UnitExists("target") then
    return false
  end

  local _, playerClassId = C_PlayerInfo.GetClass(PlayerLocation:CreateFromUnit("player"))
  if not HasCCSpell("player", playerClassId) then
    return false
  end

  local units = GetUnitWithSameTarget()
  local unitsCanCC = {}

  for i=1,#units do
    local _, unitClassId = C_PlayerInfo.GetClass(PlayerLocation:CreateFromUnit(units[i]))
    if HasCCSpell(units[i], unitClassId) then
      table.insert(unitsCanCC, units[i])
    end
  end

  if #unitsCanCC == 0 then
    return true
  end

  return IsWinnerToTakeAction(unitsCanCC)
end

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "ccwin"
  end,
  true,
  function(key, info)
    info.ccwin = info.unit == "player" and IsWinnerToCC() or false
  end
)