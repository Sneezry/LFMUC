local _, LFA = ...

LFA.DB.Rules.DispelMagic = {
  spells = LFA.DB.Spells.dispelm,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {
    -- 永恒黎明陨落(上)
    "时光斩", "绽放",
    -- 永恒黎明崛起(下)
    "提尔之火",
    -- 黑鸭堡垒
    "灵魂毒液",
    -- 阿塔达萨
    "熔化的黄金",
    -- 维克雷斯庄园
    -- "污秽攻击", -- 不要自动秒驱，会传染
  },
  targetofspell = {}
}