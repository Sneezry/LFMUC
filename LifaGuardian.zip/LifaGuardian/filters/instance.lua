local _, LFG = ...

local function GetFilteredInstance(filter)
  if filter.property ~= "type" then
    return nil
  end

  local _, instanceType = IsInInstance()

  if filter.operator == "=" and filter.value == instanceType
      or filter.operator == "~" and filter.value ~= instanceType then
    return true
  end

  return nil
end

LFG.RegisterGeneralFilterHandler("instance", GetFilteredInstance)