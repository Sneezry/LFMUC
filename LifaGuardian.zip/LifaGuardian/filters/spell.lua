local _, LFG = ...

local function GetFilteredSpell(filter)
  local _, duration = GetSpellCooldown(filter.property)
  local _, gcdDuration = GetSpellCooldown(61304)
  local useable = IsUsableSpell(filter.property)
  local castable = useable and ((duration - gcdDuration) <= 0 and not LFG.IsHealer() or duration == 0 and LFG.IsHealer())
  local inRange = IsSpellInRange(filter.property, "target") ~= 0
  local channelingSpell, _, _, _, _, _, _, channelingspellId, _, totalStage = UnitChannelInfo("player")
  local isChanneling = totalStage and (filter.property == channelingspellId or filter.property == channelingSpell)

  if filter.value == nil then
    if not useable and filter.operator == "=" or useable and filter.operator == "~" then
      return { filter.property }
    else
      return nil
    end
  end

  if( castable and inRange or isChanneling) and filter.value or not (castable or isChanneling) and not filter.value then
    if filter.operator == "=" then
      return { filter.property }
    else
      return nil
    end
  end

  return nil
end

LFG.RegisterGeneralFilterHandler("spell", GetFilteredSpell)