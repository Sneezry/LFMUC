local frame = CreateFrame("FRAME")
frame:RegisterEvent("ADDON_LOADED")

local panel = CreateFrame("FRAME")
panel.name = "力法神奇马赛克"
InterfaceOptions_AddCategory(panel)

local sizeTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
sizeTitle:SetPoint("TOPLEFT", 16, -16)
sizeTitle:SetText("马赛克尺寸")

local posTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
posTitle:SetPoint("TOPLEFT", 16, -96)
posTitle:SetText("马赛克位置")

local posXTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
posXTitle:SetPoint("TOPLEFT", 16, -120)
posXTitle:SetText("X轴偏移量")

local posYTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
posYTitle:SetPoint("TOPLEFT", 16, -180)
posYTitle:SetText("Y轴偏移量")

local typeTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
typeTitle:SetPoint("TOPLEFT", 16, -260)
typeTitle:SetText("马赛克类型")

local warnTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontRedLarge")
warnTitle:SetPoint("TOPLEFT", 16, -400)
warnTitle:SetText("注意：更改配置后需要重新启动“力法已上线”！")

local MasaicFrame = CreateFrame("Frame", "LifaMosaic", UIParent)
MasaicFrame:SetFrameStrata("BACKGROUND")
MasaicFrame:SetFrameLevel(10000)
MasaicFrame:SetSize(520, 520)
MasaicFrame:SetPoint("TOPLEFT", UIParent, 300, -200)

local MasaicAnchorFrame = CreateFrame("Frame", "LifaMosaicAnchor", UIParent)
MasaicAnchorFrame:SetFrameStrata("BACKGROUND")
MasaicAnchorFrame:SetFrameLevel(10000)
MasaicAnchorFrame:SetSize(520, 520)
MasaicAnchorFrame:SetPoint("TOPLEFT", UIParent, 300, -200)

local MasaicTextureList = {}
local XMasaicTextureList = {}
local YMasaicTextureList = {}
local TextureSize = 1
for y = 1,64
do
  for x = 1,64
  do
    local MasaicTexture = MasaicFrame:CreateTexture(nil, "BACKGROUND")
    MasaicTexture:SetPoint("TOPLEFT", MasaicFrame, x * TextureSize, -y * TextureSize)
    MasaicTexture:SetSize(TextureSize, TextureSize)
    MasaicTextureList[(y - 1) * 64 + x] = MasaicTexture
  end
end

for x = 1,64
do
  local i = (x - 1) % 8
  local MasaicTexture = MasaicAnchorFrame:CreateTexture(nil, "BACKGROUND")
  MasaicTexture:SetPoint("TOPLEFT", MasaicAnchorFrame, x * TextureSize, 0)
  MasaicTexture:SetSize(TextureSize, TextureSize)
  MasaicTexture:SetColorTexture(math.floor(i / 4), math.floor(i / 2) % 2, i % 2)
  MasaicTexture:Show()
  XMasaicTextureList[x] = MasaicTexture
end

for y = 1,64
do
  local i = (y - 1) % 8
  local MasaicTexture = MasaicAnchorFrame:CreateTexture(nil, "BACKGROUND")
  MasaicTexture:SetPoint("TOPLEFT", MasaicAnchorFrame, 0, -y * TextureSize)
  MasaicTexture:SetSize(TextureSize, TextureSize)
  MasaicTexture:SetColorTexture(math.floor(i / 4), math.floor(i / 2) % 2, i % 2)
  MasaicTexture:Show()
  YMasaicTextureList[y] = MasaicTexture
end

local function UpdateMosaicSize()
  local TextureSize = LF_Mosaic_Size
  for y = 1,64
  do
    for x = 1,64
    do
      local MasaicTexture = MasaicTextureList[(y - 1) * 64 + x]
      MasaicTexture:SetPoint("TOPLEFT", MasaicFrame, x * TextureSize, -y * TextureSize)
      MasaicTexture:SetSize(TextureSize, TextureSize)
    end
  end

  for x = 1,64
  do
    local i = (x - 1) % 8
    local MasaicTexture = XMasaicTextureList[x]
    MasaicTexture:SetPoint("TOPLEFT", MasaicAnchorFrame, x * TextureSize, 0)
    MasaicTexture:SetSize(TextureSize, TextureSize)

    if LF_Mosaic_Micro and x > 32 or LF_Mosaic_Nano and x > 16 then
      MasaicTexture:Hide()
    else
      MasaicTexture:Show()
    end
  end

  for y = 1,64
  do
    local i = (y - 1) % 8
    local MasaicTexture = YMasaicTextureList[y]
    MasaicTexture:SetPoint("TOPLEFT", MasaicAnchorFrame, 0, -y * TextureSize)
    MasaicTexture:SetSize(TextureSize, TextureSize)

    if LF_Mosaic_Micro and y > 32 or LF_Mosaic_Nano and y > 16 then
      MasaicTexture:Hide()
    else
      MasaicTexture:Show()
    end
  end
end

local function UpdateMosaicPos()
  MasaicFrame:SetPoint("TOPLEFT", UIParent, LF_Mosaic_Pos_X, 0 - LF_Mosaic_Pos_Y)
  MasaicAnchorFrame:SetPoint("TOPLEFT", UIParent, LF_Mosaic_Pos_X, 0 - LF_Mosaic_Pos_Y)
end

local sizeSlider = CreateFrame("Slider", "LF_Mosaic_Size_Slider", panel, "OptionsSliderTemplate")
sizeSlider:SetMinMaxValues(1, 8)
sizeSlider:SetWidth(320)
sizeSlider:SetValue(TextureSize)
getglobal(sizeSlider:GetName() .. 'Low'):SetText('小')
getglobal(sizeSlider:GetName() .. 'High'):SetText('大')
sizeSlider:SetScript("OnValueChanged", 
	function (self, value)
		LF_Mosaic_Size = floor(value)
    UpdateMosaicSize()
	end
)
sizeSlider:SetPoint("TOPLEFT", sizeTitle, "BOTTOMLEFT", 0, -8)

local posXSlider = CreateFrame("Slider", "LF_Mosaic_Pos_X_Slider", panel, "OptionsSliderTemplate")
posXSlider:SetMinMaxValues(0, 3200)
posXSlider:SetWidth(320)
posXSlider:SetValue(300)
getglobal(posXSlider:GetName() .. 'Low'):SetText('0')
getglobal(posXSlider:GetName() .. 'High'):SetText('3200')
getglobal(posXSlider:GetName() .. 'Text'):SetText('300')
posXSlider:SetScript("OnValueChanged", 
	function (self, value)
		LF_Mosaic_Pos_X = floor(value)
    getglobal(posXSlider:GetName() .. 'Text'):SetText(floor(value))
    UpdateMosaicPos()
	end
)
posXSlider:SetPoint("TOPLEFT", posXTitle, "BOTTOMLEFT", 0, -8)

local posYSlider = CreateFrame("Slider", "LF_Mosaic_Pos_Y_Slider", panel, "OptionsSliderTemplate")
posYSlider:SetMinMaxValues(0, 1600)
posYSlider:SetWidth(320)
posYSlider:SetValue(200)
getglobal(posYSlider:GetName() .. 'Low'):SetText('0')
getglobal(posYSlider:GetName() .. 'High'):SetText('1600')
getglobal(posYSlider:GetName() .. 'Text'):SetText('200')
posYSlider:SetScript("OnValueChanged", 
	function (self, value)
		LF_Mosaic_Pos_Y = floor(value)
    getglobal(posYSlider:GetName() .. 'Text'):SetText(floor(value))
    UpdateMosaicPos()
	end
)
posYSlider:SetPoint("TOPLEFT", posYTitle, "BOTTOMLEFT", 0, -8)

local normalMosaicCheckbutton, microMosaicCheckbutton, nanoMosaicCheckbutton

local function NormalMosaicCheckbuttonOnClick()
  LF_Mosaic_Normal = true
  LF_Mosaic_Micro = false
  LF_Mosaic_Nano = false
  normalMosaicCheckbutton:SetChecked(LF_Mosaic_Normal)
  microMosaicCheckbutton:SetChecked(LF_Mosaic_Micro)
  nanoMosaicCheckbutton:SetChecked(LF_Mosaic_Nano)
  UpdateMosaicSize()
end

normalMosaicCheckbutton = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
normalMosaicCheckbutton:SetPoint("TOPLEFT", typeTitle, "BOTTOMLEFT", 0, -8)
normalMosaicCheckbutton.Text:SetText("正常马赛克")
normalMosaicCheckbutton:SetScript("OnClick", NormalMosaicCheckbuttonOnClick)

local function MicroMosaicCheckbuttonOnClick()
  LF_Mosaic_Normal = false
  LF_Mosaic_Micro = true
  LF_Mosaic_Nano = false
  normalMosaicCheckbutton:SetChecked(LF_Mosaic_Normal)
  microMosaicCheckbutton:SetChecked(LF_Mosaic_Micro)
  nanoMosaicCheckbutton:SetChecked(LF_Mosaic_Nano)
  UpdateMosaicSize()
end

microMosaicCheckbutton = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
microMosaicCheckbutton:SetPoint("TOPLEFT", typeTitle, "BOTTOMLEFT", 0, -32)
microMosaicCheckbutton.Text:SetText("迷你马赛克")
microMosaicCheckbutton:SetScript("OnClick", MicroMosaicCheckbuttonOnClick)

local function NanoMosaicCheckbuttonOnClick()
  LF_Mosaic_Normal = false
  LF_Mosaic_Micro = false
  LF_Mosaic_Nano = true
  normalMosaicCheckbutton:SetChecked(LF_Mosaic_Normal)
  microMosaicCheckbutton:SetChecked(LF_Mosaic_Micro)
  nanoMosaicCheckbutton:SetChecked(LF_Mosaic_Nano)
  UpdateMosaicSize()
end

nanoMosaicCheckbutton = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
nanoMosaicCheckbutton:SetPoint("TOPLEFT", typeTitle, "BOTTOMLEFT", 0, -56)
nanoMosaicCheckbutton.Text:SetText("微型马赛克（慎用）")
nanoMosaicCheckbutton:SetScript("OnClick", NanoMosaicCheckbuttonOnClick)

local function ConvertTextToBinList(text)
  text = 'LF:' .. text
  local binList = {}
  for i = 1,string.len(text),1
  do
    local char = string.byte(text, i)
    for j = 1,8
    do
      binList[i * 8 - j + 1] = char % 2
      char = math.floor(char / 2)
    end
  end

  local pad = #binList%3
  if (pad > 0)
  then
    pad = 3 - pad
    for j = 1,pad
    do
      binList[#binList + 1] = 0
    end
  end
  return binList, pad
end

local function ListConcat(t1,t2)
  for i=1,#t2
  do
      t1[#t1+1] = t2[i]
  end
  return t1
end

local function GetBinData(text)
  if not text or text == "" then
    return {}
  end

  local binListEnd = {1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0,
                      1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0,
                      1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0,
                      1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0,
                      1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0}
  local binList, pad = ConvertTextToBinList(text)
  local binData = ListConcat(binList, binListEnd)

  local binDataLen = #binData
  for j = 3,1,-1
  do
    binData[binDataLen + j] = pad % 2
    pad = math.floor(pad / 2)
  end
  return binData
end

local busy = false
local incooldown = false

function LifaMosaicUpdateCanvas(text, priority, cooldown)
  if busy then
    return
  end

  if priority then
    if incooldown then
      return
    end
    busy = true
    C_Timer.After(priority, function() busy = false LifaMosaicUpdateCanvas("") end)
    if cooldown then
      incooldown = true
      C_Timer.After(cooldown, function() incooldown = false end)
    end
  end

  local binData = GetBinData(text)
  local size = 8
  for y = 1,64
  do
    for x = 1,64
    do
      local index = (y - 1) * 64 + x
      local microIndex = (y - 1) * 32 + x
      local nanoIndex = (y - 1) * 16 + x
      local dataIndex = LF_Mosaic_Nano and nanoIndex or (LF_Mosaic_Micro and microIndex or index)
      if (dataIndex <= #binData / 3 and
          (not LF_Mosaic_Micro and not LF_Mosaic_Nano or
            LF_Mosaic_Micro and x <= 32 and y <= 32 or
            LF_Mosaic_Nano and x <= 16 and y <= 16
          )
        ) then
        MasaicTextureList[index]:SetColorTexture(binData[dataIndex * 3 - 2], binData[dataIndex * 3 - 1], binData[dataIndex * 3])
        MasaicTextureList[index]:Show()
      else
        MasaicTextureList[index]:Hide()
      end
    end
  end
end

function LifaMosaicHideCanvas()
  MasaicFrame:Hide()
  MasaicAnchorFrame:Hide()
end

function LifaMosaicShowAnchor()
  MasaicAnchorFrame:Show()
  C_Timer.After(10, function() MasaicAnchorFrame:Hide() end)
end

function LifaMosaicShowCanvas()
  MasaicFrame:Show()
  LifaMosaicShowAnchor()
end

function LifaMosaicHideAnchor()
  MasaicAnchorFrame:Hide()
end

function LifaMosaicStop()
  LFHENABLED=nil
  LifaMosaicHideAnchor()
  LifaMosaicUpdateCanvas("")
end

function LifaMosaicStart()
  C_ClubFinder.RequestMembershipToClub("ClubFinder-2-167161-0000000033C19679", "", {})

  local channelId = GetChannelName("Community:868324985:1")
  if channelId > 0 then
    ChangeChatColor("CHANNEL" .. tostring(channelId), 1, 0, 0.8)
  else
    ChatFrame_AddNewCommunitiesChannel(1, 868324985, 1)
  end
  
  LFHENABLED=1
  LFMSA()
end

SLASH_LIFAMOSAIC1 = "/lifa"
SLASH_LIFAMOSAIC2 = "/lf"
SlashCmdList["LIFAMOSAIC"] = function (msg)
  if LFHENABLED then
    LifaMosaicStop()
  else
    LifaMosaicStart()
  end
end

LFMUC = LifaMosaicUpdateCanvas
LFMHC = LifaMosaicHideCanvas
LFMSC = LifaMosaicShowCanvas
LFMSA = LifaMosaicShowAnchor
LFMHA = LifaMosaicHideAnchor
LFMSP = LifaMosaicStop
LFMST = LifaMosaicStart

function frame:OnEvent(event, arg)
  if event == "ADDON_LOADED" and arg == "LifaMosaic" then
    self:UnregisterEvent("ADDON_LOADED")

    if LF_Mosaic_Pos_X == nil then
      LF_Mosaic_Pos_X = 300
    end

    if LF_Mosaic_Pos_Y == nil then
      LF_Mosaic_Pos_Y = 200
    end

    if LF_Mosaic_Size == nil then
      LF_Mosaic_Size = 8
    end

    if LF_Mosaic_Normal == nil then
      LF_Mosaic_Normal = true
    end

    if LF_Mosaic_Micro == nil then
      LF_Mosaic_Micro = false
    end

    if LF_Mosaic_Nano == nil then
      LF_Mosaic_Nano = false
    end

    posXSlider:SetValue(LF_Mosaic_Pos_X)
    posYSlider:SetValue(LF_Mosaic_Pos_Y)
    UpdateMosaicPos()

    sizeSlider:SetValue(LF_Mosaic_Size)
    normalMosaicCheckbutton:SetChecked(LF_Mosaic_Normal)
    microMosaicCheckbutton:SetChecked(LF_Mosaic_Micro)
    nanoMosaicCheckbutton:SetChecked(LF_Mosaic_Nano)
    UpdateMosaicSize()
  end
end
frame:SetScript("OnEvent", frame.OnEvent)

-- LifaMosaicUpdateCanvas("hello world!")
MasaicAnchorFrame:Hide()
-- LifaMosaicHideCanvas()
