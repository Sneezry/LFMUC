local _, LFG = ...

local function GetFilteredPet(filter)
  return LFG.GetFilteredUnit("pet", filter)
end

LFG.RegisterGeneralFilterHandler("pet", GetFilteredPet)