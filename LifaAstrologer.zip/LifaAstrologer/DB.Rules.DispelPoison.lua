local _, LFA = ...

LFA.DB.Rules.DispelPoison = {
  spells = LFA.DB.Spells.dispelp,
  casting = {},
  channel = {},
  buff = {},
  debuff = {"枯萎毒药","腐朽感官","腐朽根须"}
}