local _, LFA = ...

LFA.DB.Rules.Freedom = {
  spells = LFA.DB.Spells.freedom,
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {},
  targetofspell = {}
}