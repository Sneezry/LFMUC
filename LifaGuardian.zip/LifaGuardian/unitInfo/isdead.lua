local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return key == "isdead"
  end,
  true,
  function(key, info)
    info.isdead = UnitIsDead(info.unit)
      or LFG.GetUnitInfoValue(info, "buff:炉脉幻想") ~= nil
      or LFG.GetUnitInfoValue(info, "buff:救赎之魂") ~= nil
  end
)