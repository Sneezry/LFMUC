local frame = CreateFrame("FRAME")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterEvent("PLAYER_TARGET_CHANGED")

local panel = CreateFrame("FRAME")
panel.name = "力法神奇守护者"
InterfaceOptions_AddCategory(panel)

local classColor = {
  {0.78, 0.61, 0.43}, --Warrior
  {0.96, 0.55, 0.73}, --Paladin
  {0.67, 0.83, 0.45}, --Hunter
  {1.00, 0.96, 0.41}, --Rogue
  {1.00, 1.00, 1.00}, --Priest
  {0.77, 0.12, 0.23}, --Death Knight
  {0.00, 0.44, 0.87}, --Shaman
  {0.25, 0.78, 0.92}, --Mage
  {0.53, 0.53, 0.93}, --Warlock
  {0.00, 1.00, 0.60}, --Monk
  {1.00, 0.49, 0.04}, --Druid
  {0.64, 0.19, 0.79}  --Demon Hunter
}

local keybindings = {
  player = "ALT-CTRL-NUMPAD0",
  party1 = "ALT-CTRL-NUMPAD1",
  party2 = "ALT-CTRL-NUMPAD2",
  party3 = "ALT-CTRL-NUMPAD3",
  party4 = "ALT-CTRL-NUMPAD4",
  raid1 = "ALT-CTRL-NUMPAD5",
  raid2 = "ALT-CTRL-NUMPAD6",
  raid3 = "ALT-CTRL-NUMPAD7",
  raid4 = "ALT-CTRL-NUMPAD8",
  raid5 = "ALT-CTRL-NUMPAD9",
  raid6 = "ALT-CTRL-F1",
  raid7 = "ALT-CTRL-F2",
  raid8 = "ALT-CTRL-F3",
  raid9 = "ALT-CTRL-F5",
  raid10 = "ALT-CTRL-F6",
  raid11 = "ALT-CTRL-F7",
  raid12 = "ALT-CTRL-F8",
  raid13 = "ALT-CTRL-F9",
  raid14 = "ALT-CTRL-F10",
  raid15 = "ALT-CTRL-F11",
  raid16 = "ALT-CTRL-F12",
  raid17 = "ALT-SHIFT-F1",
  raid18 = "ALT-SHIFT-F2",
  raid19 = "ALT-SHIFT-F3",
  raid20 = "ALT-SHIFT-F5",
  raid21 = "ALT-SHIFT-F6",
  raid22 = "ALT-SHIFT-F7",
  raid23 = "ALT-SHIFT-F8",
  raid24 = "ALT-SHIFT-F9",
  raid25 = "ALT-SHIFT-F10",
  raid26 = "ALT-SHIFT-F11",
  raid27 = "ALT-SHIFT-F12",
  raid28 = "CTRL-SHIFT-F1",
  raid29 = "CTRL-SHIFT-F2",
  raid30 = "CTRL-SHIFT-F3",
  raid31 = "CTRL-SHIFT-F4",
  raid32 = "CTRL-SHIFT-F5",
  raid33 = "CTRL-SHIFT-F6",
  raid34 = "CTRL-SHIFT-F7",
  raid35 = "CTRL-SHIFT-F8",
  raid36 = "CTRL-SHIFT-F9",
  raid37 = "CTRL-SHIFT-F10",
  raid38 = "CTRL-SHIFT-F11",
  raid39 = "CTRL-SHIFT-F12",
  raid40 = "CTRL-SHIFT-="
}

local msgQueue = {}
local lastLineId = 0

local defaultProfile = [[
unit,unit.health>0,unit.health<100,unit.health=min
unit,unit.isplayer=true
]]

local lastChangeTargetTime = 0
local changeTargetTimeCooldown = 0.1
local recomendedUnit = nil
local frameDuration = 0.1
local recommendationUnitCount = 0

local playerName = UnitName("player")

local function GetUnitHealPercentage(unit)
  local incomingHeals = UnitGetIncomingHeals(unit)
  return (UnitHealth(unit) + (incomingHeals == nil and 0 or incomingHeals)) * 100 / UnitHealthMax(unit)
end

local function GetUnitHealLost(unit)
  local incomingHeals = UnitGetIncomingHeals(unit)
  return UnitHealthMax(unit) - (UnitHealth(unit) + (incomingHeals == nil and 0 or incomingHeals))
end

local function GetUnitBuff(unit)
  local buffs, i = { }, 1;
  local buff, _, count, _, _, expTime = UnitBuff(unit, i)

  while buff do
    local leftTime = expTime == 0 and 86400 or floor(expTime - GetTime())
    buffs["buff:" .. buff] = math.max(count, 1)
    buffs["buffleft:" .. buff] = leftTime
    i = i + 1;
    buff, _, count, _, _, expTime = UnitBuff(unit, i);
  end;

  return buffs
end

local function GetUnitDebuff(unit)
  local debuffs, i = { }, 1;
  local debuff, _, count, _, _, expTime = UnitDebuff(unit, i)

  while debuff do
    local leftTime = expTime == 0 and 86400 or floor(expTime - GetTime())
    debuffs["debuff:" .. debuff] = math.max(count, 1)
    debuffs["debuffleft:" .. debuff] = leftTime
    i = i + 1;
    debuff, _, count, _, _, expTime = UnitDebuff(unit, i)
  end;

  return debuffs
end

local function HasRemovableDebuff(unit)
  if UnitDebuff(unit, 1, true) then
    return true
  end

  return false
end

local function GetUnitInfo(unit)
  local exists = UnitExists(unit)
  if not exists then
    return nil
  end

  local player = PlayerLocation:CreateFromUnit(unit)
  local name, realm = UnitName(unit)
  local _, _, class = C_PlayerInfo.GetClass(player)
  local role = string.lower(UnitGroupRolesAssigned(unit))
  local online = UnitIsConnected(unit)
  local health = GetUnitHealPercentage(unit)
  local healthlost = GetUnitHealLost(unit)
  local mana = UnitPower(unit) * 100 / UnitPowerMax(unit);
  local fullname = realm == nil and name or name .. "-" .. realm
  local ignore = string.sub(unit, 1, 4) == "raid" and LF_Guardian_WatchRaid[fullname] or LF_Guardian_WatchParty[fullname]
  local isplayer = playerName == fullname
  local buff = GetUnitBuff(unit)
  local debuff = GetUnitDebuff(unit)
  local hasremovabledebuff = HasRemovableDebuff(unit)
  local isdead = UnitIsDead(unit) or buff["buff:炉脉幻想"] ~= nil
  local incombat = UnitAffectingCombat(unit)
  local canattack = UnitCanAttack("player", unit)
  local ismoving = GetUnitSpeed(unit) > 0

  local info = {
    unit = unit,
    color = classColor[class],
    name = name,
    fullname = fullname,
    role = role,
    online = online,
    health = health,
    mana = mana,
    ignore = ignore,
    isplayer = isplayer,
    keybinding = keybindings[unit],
    hasremovabledebuff = hasremovabledebuff,
    isdead = isdead,
    incombat = incombat,
    canattack = canattack,
    ismoving = ismoving
  }
  for k,v in pairs(buff) do info[k] = v end
  for k,v in pairs(debuff) do info[k] = v end

  for i=1,#msgQueue do
    local msg = msgQueue[i]
    if msg.time >= GetTime() - 1 and msg.sender == fullname then
      info["msg"] = msg.msg
      info["msgchannel"] = msg.channel
      break
    end
  end

  return info
end

local function InitializeTargetButtons()
  local buttonFrame = CreateFrame("Frame", "LifaGuardianButton", UIParent)
  buttonFrame:SetSize(50, 50)
  buttonFrame:SetFrameStrata("BACKGROUND")
  buttonFrame:SetFrameLevel(10000)
  buttonFrame:SetPoint("TOPLEFT", UIParent, -100, 100)

  local MasaicTexture = buttonFrame:CreateTexture(nil, "BACKGROUND")
  MasaicTexture:SetPoint("TOPLEFT", buttonFrame, 0, 0)
  MasaicTexture:SetSize(50, 50)
  MasaicTexture:SetColorTexture(1, 0, 0)
  MasaicTexture:Show()

  for i=1,5 do
    local unit = i == 1 and "player" or "party" .. (i - 1)
    local macro = "/target " .. unit
    local button = CreateFrame("Button", "LFGuardian_" .. unit, buttonFrame, 'SecureActionButtonTemplate')
    button:SetAllPoints()
    button:SetAttribute("type1", "macro")
    button:SetAttribute("macrotext", macro)
    SetOverrideBindingClick(buttonFrame, true, keybindings[unit], "LFGuardian_" .. unit)
  end

  for i=1,40 do
    local unit = "raid" .. i
    local macro = "/target " .. unit
    local button = CreateFrame("Button", "LFGuardian_" .. unit, buttonFrame, 'SecureActionButtonTemplate')
    button:SetAllPoints()
    button:SetAttribute("type1", "macro")
    button:SetAttribute("macrotext", macro)
    SetOverrideBindingClick(buttonFrame, true, keybindings[unit], "LFGuardian_" .. unit)
  end
end

local watchTop = -16
local watchTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
watchTitle:SetPoint("TOPLEFT", 16, watchTop)
watchTitle:SetText("守护目标")

local watchPartyTop = -8
local watchPartyTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
watchPartyTitle:SetTextColor(0.67, 0.67, 1, 1)
watchPartyTitle:SetPoint("TOPLEFT", watchTitle, "BOTTOMLEFT", 0, watchPartyTop)
watchPartyTitle:SetText("小队目标")

local watchRaidTop = -40
local watchRaidTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
watchRaidTitle:SetTextColor(1, 0.5, 0, 1)
watchRaidTitle:SetPoint("TOPLEFT", watchPartyTitle, "BOTTOMLEFT", 0, watchRaidTop)
watchRaidTitle:SetText("团队目标")

local profileTop = -416
local profileTitle = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
profileTitle:SetPoint("TOPLEFT", 16, profileTop)
profileTitle:SetText("守护规则")

local profileFrameTop = -8
local profileFrame = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
profileFrame:SetSize(550, 100)
profileFrame:SetPoint("TOPLEFT", profileTitle, "BOTTOMLEFT", 0, profileFrameTop)

local profileEditBox = CreateFrame("EditBox", nil, profileFrame)
profileEditBox:SetMultiLine(true)
profileEditBox:SetAutoFocus(false)
profileEditBox:SetFontObject(ChatFontNormal)
profileEditBox:SetWidth(525)
profileEditBox:SetScript("OnTextChanged", function() LF_Guardian_Profile = profileEditBox:GetText() end)

profileFrame:SetScrollChild(profileEditBox)

local partyCheckButtons = {}
local raidCheckButtons = {}

local function UpdateProfileUI()
  profileEditBox:SetText(LF_Guardian_Profile)
end

local function StringSplit(inputstr, sep)
  if sep == nil then
    sep = "%s"
  end

  local t={}

  for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
    table.insert(t, str)
  end

  return t
end

function Trim(s)
  return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function GetStrWidth(str)
  local realByteCount = #str
  local length = 0
  local curBytePos = 1

  while(true) do
    local step = 1
    local byteVal = string.byte(str, curBytePos)
    if byteVal > 239 then
      step = 4
    elseif byteVal > 223 then
      step = 3
    elseif byteVal > 191 then
      step = 2
    else
      step = 1
    end
    curBytePos = curBytePos + step
    length = length + (step == 1 and 1 or 2)
    if curBytePos > realByteCount then
      break
    end
  end
  return length
end

local function CutString(str, maxWidth)
  local realByteCount = #str
  local length = 0
  local curBytePos = 1
  local endPos = 1
  local step = 1

  while(true) do
    local byteVal = string.byte(str, curBytePos)
    if byteVal > 239 then
      step = 4
    elseif byteVal > 223 then
      step = 3
    elseif byteVal > 191 then
      step = 2
    else
      step = 1
    end
    
    curBytePos = curBytePos + step
    length = length + (step == 1 and 1 or 2)
    if length > maxWidth then
      break
    end

    endPos = curBytePos - 1

    if curBytePos > realByteCount then
      break
    end
  end
  
  local newStr = endPos == 1 and step > 1 and "" or string.sub(str, 1, endPos)
  return #str == #newStr and str or newStr .. "..."
end

local function GetDisplayName(name)
  if GetStrWidth(name) > 10 then
    name = CutString(name, 9)
  end

  return name
end

local function UpdateCheckbox(index, checked, playerInfo, checkButton)
  if playerInfo == nil then
    checkButton:SetChecked(false)
    checkButton.Text:SetText("<未指定>")
    checkButton.tooltipText = "<未指定>"
    checkButton.Text:SetTextColor(0.62, 0.62, 0.62, 1)
    checkButton:Disable()
  else
    local role = CreateAtlasMarkup("roleicon-tiny-dps")
    if playerInfo.role == "tank" then
      role = CreateAtlasMarkup("roleicon-tiny-tank")
    elseif playerInfo.role == "healer" then
      role = CreateAtlasMarkup("roleicon-tiny-healer")
    end

    if playerInfo.online then
      checkButton:SetChecked(checked)
      checkButton.Text:SetTextColor(playerInfo.color[1], playerInfo.color[2], playerInfo.color[3], 1)
      checkButton:Enable()
    else
      checkButton:SetChecked(false)
      checkButton.Text:SetTextColor(0.62, 0.62, 0.62, 1)
      checkButton:Disable()
    end
    
    checkButton.Text:SetText(role .. " " .. GetDisplayName(playerInfo.name))
    checkButton.tooltipText = playerInfo.name
  end
end

local function GroupOnlyCheckbuttonOnClick(groupOnlyCheckbutton)
  LF_Guardian_GroupOnly = not LF_Guardian_GroupOnly
  groupOnlyCheckbutton:SetChecked(LF_Guardian_GroupOnly)
end

local function PartyCheckBoxOnClick(party)
  local i = party.partyIndex
  local unit = "player"

  if i > 1 then
    unit = "party" .. (i - 1)
  end

  local playInfo = GetUnitInfo(unit)
  local fullname = playInfo.fullname
  
  if party:GetChecked() then
    LF_Guardian_WatchParty[fullname] = nil
  else
    LF_Guardian_WatchParty[fullname] = true
  end
end

local function RaidCheckBoxOnClick(raid)
  local i = raid.raidIndex
  local unit = "raid" .. i

  local playInfo = GetUnitInfo(unit)
  local fullname = playInfo.fullname
  
  if raid:GetChecked() then
    LF_Guardian_WatchParty[fullname] = nil
  else
    LF_Guardian_WatchParty[fullname] = true
  end
end

local function UpdateParty()
  local isInParty = IsInGroup()
  for i=1,5 do
    local playerInfo
    if not isInParty then
      playerInfo = nil
    else
      local unit = i == 1 and "player" or "party" .. (i - 1)
      playerInfo = GetUnitInfo(unit)
    end

    local checked = playerInfo and not playerInfo.ignore or false

    UpdateCheckbox(i, checked, playerInfo, partyCheckButtons[i])
  end
end

local function InitializeGroupOnlyCheckButton()
  local groupOnlyTop = -410
  local groupOnlyCheckbutton = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
  groupOnlyCheckbutton:SetPoint("TOPLEFT", 400, groupOnlyTop)
  groupOnlyCheckbutton.Text:SetText("仅在小队或团队中生效")
  groupOnlyCheckbutton:SetChecked(LF_Guardian_GroupOnly)
  groupOnlyCheckbutton:SetScript("OnClick", GroupOnlyCheckbuttonOnClick)
end

local function InitializePartyCheckButtons()
  for i=1,5 do
    partyCheckButtons[i] = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
    partyCheckButtons[i]:SetScript("OnClick", PartyCheckBoxOnClick)
    partyCheckButtons[i].partyIndex = i
    partyCheckButtons[i]:SetPoint("TOPLEFT", watchPartyTitle, "BOTTOMLEFT", (i - 1) * 120, -8)
  end

  UpdateParty()
end

local function UpdateRaid()
  local isInRaid = IsInRaid()
  for i=1,8 do
    for j=1,5 do
      local playerInfo
      if not isInRaid then
        playerInfo = nil
      else
        local unit = "raid" .. ((i - 1) * 5 + j)
        playerInfo = GetUnitInfo(unit)
      end

      local checked = playerInfo and not playerInfo.ignore or false

      UpdateCheckbox((i - 1) * 5 + j, checked, playerInfo, raidCheckButtons[(i - 1) * 5 + j])
    end
  end
end

local function InitializeRaidCheckButtons()
  for i=1,8 do
    for j=1,5 do
      raidCheckButtons[(i - 1) * 5 + j] = CreateFrame("CheckButton", nil, panel, "InterfaceOptionsCheckButtonTemplate")
      raidCheckButtons[(i - 1) * 5 + j]:SetScript("OnClick", RaidCheckBoxOnClick)
      raidCheckButtons[(i - 1) * 5 + j].raidIndex = i
      raidCheckButtons[(i - 1) * 5 + j]:SetPoint("TOPLEFT", watchRaidTitle, "BOTTOMLEFT", (j - 1) * 120, -8 - 36 * (i - 1))
    end
  end

  UpdateRaid()
end

local function GetPlayerRaidUnit()
  for i=1,40 do
    local unitInfo = GetUnitInfo("raid" .. i)
    if unitInfo.fullname == playerName then
      return "raid" .. i
    end
  end
end

local function GetAvailableUnits()
  local groupSize = GetNumGroupMembers()
  local unitPrefix = "party"

  local units = {}

  if IsInRaid() then
    unitPrefix = "raid"
  elseif IsInGroup() then
    groupSize = groupSize - 1
    table.insert(units, GetUnitInfo("player"))
  elseif not LF_Guardian_GroupOnly then
    groupSize = 0
    table.insert(units, GetUnitInfo("player"))
  end

  for i=1,groupSize do
    local unit = unitPrefix .. i
    local info = GetUnitInfo(unit)
    local inRange, checkedRange = UnitInRange(unit)

    if info and not info.ignore and info.online and inRange and checkedRange then
      table.insert(units, info)
    end
  end

  return units
end

local function SmartTypeParse(value)
  local numberValue = tonumber(value)
  local booleanValue = nil
  if value == "true" then
    booleanValue = true
  elseif value == "false" then
    booleanValue = false
  end

  if numberValue ~= nil then
    return numberValue
  elseif booleanValue ~= nil then
    return booleanValue
  else
    return value
  end
end

local function GetNonNullableValue(value)
  if value == nil then
    return 0
  end
  
  return value
end

local function GetMinValueItem(items, key)
  local minValue = nil
  local item = nil

  for i=1,#items do
    if minValue == nil or items[i][key] < minValue then
      item = items[i]
      minValue = GetNonNullableValue(items[i][key])
    end
  end
  return item
end

local function GetMaxValueItem(items, key)
  local maxValue = nil
  local item = nil

  for i=1,#items do
    if maxValue == nil or items[i][key] > maxValue then
      item = items[i]
      maxValue = GetNonNullableValue(items[i][key])
    end
  end

  return item
end

local function GetValueLessThanItems(items, key, value)
  local filteredItems = {}

  if key == count then
    local allUnits = GetAvailableUnits()
    if items ~= nil and #item < value or #allUnits == #item then
      return items
    end

    return {}
  end

  for i=1,#items do
    if GetNonNullableValue(items[i][key]) < value then
      table.insert(filteredItems, items[i])
    end
  end

  return filteredItems
end

local function GetValueGreaterThanItems(items, key, value)
  local filteredItems = {}

  if key == count then
    if items ~= nil and #item > value then
      return items
    end

    return {}
  end

  for i=1,#items do
    if GetNonNullableValue(items[i][key]) > value then
      table.insert(filteredItems, items[i])
    end
  end

  return filteredItems
end

local function ParseFilter(filter)
  local operator = "="

  if string.find(filter, "=") then
    operator = "="
  elseif string.find(filter, "~") then
    operator = "~"
  elseif string.find(filter, "<") then
    operator = "<"
  elseif string.find(filter, ">") then
    operator = ">"
  end

  local str = StringSplit(filter, operator)
  local key = StringSplit(str[1], ".")
  local value = SmartTypeParse(str[2])

  return {
    object = key[1],
    property = key[2],
    operator = operator,
    value = value
  }
end

local function GetMsgFilterUnits(items, msg, channel)
  for i=1,#items do
    if msgExists(tostring(msg), items[i].fullname, channel) then
      return { items[i] }
    end
  end

  return {}
end

local function GetFilteredItem(items, filter)
  if filter.value == "min" then
    local item = GetMinValueItem(items, filter.property)
    return { item }
  end

  if filter.value == "max" then
    local item = GetMaxValueItem(items, filter.property)
    return { item }
  end

  if filter.operator == "<" then
    return GetValueLessThanItems(items, filter.property, filter.value)
  end

  if filter.operator == ">" then
    return GetValueGreaterThanItems(items, filter.property, filter.value)
  end

  if filter.property == count then
    if filter.operator == "=" and #items == count
        or filter.operator == "~" and #items ~= count then
      return items
    else
      return {}
    end
  end

  if filter.property == "msg" and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "any")
  end

  if filter.property == "msg_group" and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "group")
  end

  if (filter.property == "msg_raid" or filter.property == "msg_i") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "raid")
  end

  if (filter.property == "msg_party" or filter.property == "msg_p") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "party")
  end

  if (filter.property == "msg_guild" or filter.property == "msg_g") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "guild")
  end

  if (filter.property == "msg_whisper" or filter.property == "msg_w") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "whisper")
  end

  if (filter.property == "msg_say" or filter.property == "msg_s") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "say")
  end

  if (filter.property == "msg_yell" or filter.property == "msg_y") and filter.operator == "=" then
    return GetMsgFilterUnits(items, filter.value, "yell")
  end

  local filteredItems = {}

  for i=1,#items do
    if filter.operator == "=" and GetNonNullableValue(items[i][filter.property]) == filter.value
        or filter.operator == "~" and GetNonNullableValue(items[i][filter.property]) ~= filter.value then
      table.insert(filteredItems, items[i])
    end
  end

  return filteredItems
end

local function GetFilteredUnit(unit, filter)
  local player = GetUnitInfo(unit)
  local items = { player }
  local filteredPlayer = GetFilteredItem(items, filter)

  if #filteredPlayer == 0 then
    return nil
  else
    return filteredPlayer[1]
  end
end

local function GetFilteredPlayer(filter)
  return GetFilteredUnit("player", filter)
end

local function GetFilteredTarget(filter)
  return GetFilteredUnit("target", filter)
end

local function GetFilteredTargettarget(filter)
  return GetFilteredUnit("targettarget", filter)
end

local function GetFilteredSpell(filter)
  local _, duration = GetSpellCooldown(filter.property)
  local useable = IsUsableSpell(filter.property) and duration == 0
  local inRange = IsSpellInRange(filter.property, "target") ~= 0
  if useable and inRange and filter.value or not useable and not filter.value then
    return { filter.property }
  end

  return nil
end

local function GetItemId(itemName)
  for bag=0,NUM_BAG_SLOTS do
    for slot=1,GetContainerNumSlots(bag) do
      local link = GetContainerItemLink(bag, slot)
      local name = GetItemInfo(link)
      if name == itemName then
          return GetContainerItemID(bag, slot)
      end
    end
  end
  return nil
end

local function GetFilteredContainerItem(filter)
  local id = GetItemId(filter.property)
  if id == nil and not filter.value then
    return { filter.property }
  end

  local spellName, spellId = GetItemSpell(id)

  if spellId == nil and not filter.value then
    return { filter.property }
  end

  local _, duration = GetSpellCooldown(spellId)
  local useable = IsUsableSpell(spellId) and duration == 0
  if useable and filter.value or not useable and not filter.value then
    return { filter.property }
  end

  return nil
end

local function GetFilteredTotem(filter)
  local totems, i, now = { }, 1, GetTime()
  local _, totem, start, duration = GetTotemInfo(i)
  
  while totem and totem ~= "" do
    totems[totem] = floor(start + duration - now)
    i = i + 1
    _, totem, start, duration = GetTotemInfo(i)
  end

  local filteredTotems = GetFilteredItem({ totems }, filter)

  if #filteredTotems == 0 then
    return nil
  else
    return true
  end
end

local function GetFilteredUnitsCount(filter)
  if filter.property ~= "count" then
    return nil
  end

  if filter.operator == "=" and recommendationUnitCount == filter.value
      or filter.operator == "~" and recommendationUnitCount ~= filter.value
      or filter.operator == "<" and recommendationUnitCount < filter.value
      or filter.operator == ">" and recommendationUnitCount > filter.value then
    return recommendationUnitCount
  end

  return nil
end

local function GetFilteredGroup(filter)
  if filter.property ~= "type" then
    return nil
  end

  local isInRaid = IsInRaid()
  local isInGroup = IsInGroup()

  if filter.operator == "=" and filter.value == "raid" and isInRaid
      or filter.operator == "~" and filter.value == "raid" and not isInRaid
      or filter.operator == "=" and filter.value == "party" and not isInRaid and isInGroup
      or filter.operator == "~" and filter.value == "party" and (isInRaid or not isInGroup) then
    return true
  end

  return nil
end

local function GetGeneralFiltered(filter)
  if filter.object == "player" and GetFilteredPlayer(filter) == nil then
    return false
  end

  if filter.object == "target" and GetFilteredTarget(filter) == nil then
    return false
  end

  if filter.object == "targettarget" and GetFilteredTargettarget(filter) == nil then
    return false
  end

  if filter.object == "spell" and GetFilteredSpell(filter) == nil then
    return false
  end

  if filter.object == "item" and GetFilteredContainerItem(filter) == nil then
    return false
  end

  if filter.object == "totem" and GetFilteredTotem(filter) == nil then
    return false
  end

  if filter.object == "units" and GetFilteredUnitsCount(filter) == nil then
    return false
  end

  if filter.object == "group" and GetFilteredGroup(filter) == nil then
    return false
  end

  return true
end

local function GetFilteredActions(actions, filter)
  if not GetGeneralFiltered(filter) then
    return {}
  end

  if filter.object == "action" and filter.property == "key" then
    table.insert(actions, { key = filter.value })
  end

  return actions
end

local function GetFilteredUnits(units, filter)
  if not GetGeneralFiltered(filter) then
    return {}
  end

  if filter.object == "unit" then
    return GetFilteredItem(units, filter)
  else
    return units
  end
end

local function GetFilteredItems(command, items, filter)
  if command == "units" or command == "unit" then
    return GetFilteredUnits(items, filter)
  end

  if command == "action" then
    return GetFilteredActions(items, filter)
  end

  return {}
end

local function LineParse(line, context)
  local args = StringSplit(line, ",")
  local command = args[1]
  local items = {}

  if context[command] ~= nil then
    return
  end

  if command == "units" or command == "unit" then
    items = GetAvailableUnits()
  end

  local filteredItems = {}

  for i=2,#args do
    local filter = ParseFilter(args[i])
    items = GetFilteredItems(command, items, filter)
  end

  if #items > 0 then
    context[command] = items[1]
    
    if command == "units" then
      context[command] = items
      recommendationUnitCount = #items
    end

    return
  end
end

local function RuleParse(rule)
  local lines = StringSplit(rule, "\n")
  local context = {}
  recommendationUnitCount = 0

  for i=1,#lines do
    local str = Trim(lines[i])
    if str ~= "" then
      LineParse(str, context)
    end
  end

  return context
end

local function IsHealer()
  local player = PlayerLocation:CreateFromUnit("player")
  local _, _, class = C_PlayerInfo.GetClass(player)
  local specialization = GetSpecialization()

  if class == 2 and specialization == 1
    or class == 5 and specialization == 1
    or class == 5 and specialization == 2
    or class == 7 and specialization == 3
    or class == 10 and specialization == 2
    or class == 11 and specialization == 4 then
    return true
  end

  return false
end

local function GetRecommendation()
  local context = RuleParse(LF_Guardian_Profile)
  return context
end

local function GetRecommendationTarget()
  local context = GetRecommendation()
  return context.unit
end

local function GetRecommendationAction()
  local context = GetRecommendation()
  return context.action
end

local function ShowKeyInfo(key)
  local cSpell, _, _, _, _, _, _, spellId = UnitChannelInfo("player")
  if cSpell and spellId ~= 115175 then
    LFMUC("")
    return
  end

  local info=(BNGetInfo() and C_BattleNet.GetAccountInfoByID(select(3, BNGetInfo())) or nil)
  LFMUC("key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404") .. ":key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404") .. ":key:" .. key .. ":tag:" .. (info and info.battleTag or "NPE#0404"))
end

local function GetNextRecomendationTarget()
  if LFHENABLED and IsHealer() and (IsInGroup() or not LF_Guardian_GroupOnly) and GetTime() - lastChangeTargetTime > changeTargetTimeCooldown then
    recomendedUnit = GetRecommendationTarget()
    if recomendedUnit == nil then
      C_Timer.After(frameDuration, GetNextRecomendationTarget)
      return
    end
    
    local currentUnitInfo = GetUnitInfo("target")

    if not (recomendedUnit and currentUnitInfo and recomendedUnit.fullname == currentUnitInfo.fullname) then
      local key = keybindings[recomendedUnit.unit]:gsub("ALT", "A"):gsub("CTRL", "C"):gsub("SHIFT", "S"):gsub("NUMPAD", "N"):gsub("-", "")
      ShowKeyInfo(key)
    end
  end

  C_Timer.After(frameDuration, GetNextRecomendationTarget)
end

local function GetNextRecomendationAction()
  if LFHENABLED and IsHealer() and (IsInGroup() or not LF_Guardian_GroupOnly) then
    local action = GetRecommendationAction()
    local currentUnitInfo = GetUnitInfo("target")
    
    if not recomendedUnit or (recomendedUnit and currentUnitInfo and recomendedUnit.fullname == currentUnitInfo.fullname) then
      if action == nil then
        LFMUC("")
      else
        local key = action.key
        ShowKeyInfo(key)
      end
    end
  end

  C_Timer.After(frameDuration, GetNextRecomendationAction)
end

local function UpdateGroup()
  UpdateParty()
  UpdateRaid()
end

function msgQueueHandler(msg, sender, channel)
  local now = GetTime()

  table.insert(msgQueue, {
    time = now,
    msg = msg,
    sender = sender,
    channel = channel
  })

  for i=#msgQueue,1,-1 do
    local msg = msgQueue[i]
    if msg.time < now - 1 then
      table.remove(msgQueue, i)
    end
  end
end

function msgEventHandler(self, event, msg, sender, languageName, channelName, playerName2, specialFlags, zoneChannelID, channelIndex, channelBaseName, unused, lineID)
  if lastLineId >= lineID then
    return nil
  end

  lastLineId = lineID
  local channel = event

  local player, realm = strsplit("-", sender, 2)
  if realm == GetRealmName() then
    sender = player
  end

  if event == "CHAT_MSG_RAID" or event == "CHAT_MSG_RAID_LEADER" then
    channel = "raid"
  elseif event == "CHAT_MSG_PARTY" or event == "CHAT_MSG_PARTY_LEADER" then
    channel = "party"
  elseif event == "CHAT_MSG_GUILD" or event == "CHAT_MSG_OFFICER" then
    channel = "guild"
  elseif event == "CHAT_MSG_WHISPER" then
    channel = "whisper"
  elseif event == "CHAT_MSG_SAY" then
    channel = "say"
  elseif event == "CHAT_MSG_YELL" then
    channel = "yell"
  end

  msgQueueHandler(msg, sender, channel)
end

function msgEventRegister()
  ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID", msgEventHandler);
  ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID_LEADER", msgEventHandler);
  ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY", msgEventHandler);
  ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY_LEADER", msgEventHandler);
  ChatFrame_AddMessageEventFilter("CHAT_MSG_GUILD", msgEventHandler);
  ChatFrame_AddMessageEventFilter("CHAT_MSG_OFFICER", msgEventHandler);
  ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", msgEventHandler);
  ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", msgEventHandler);
  ChatFrame_AddMessageEventFilter("CHAT_MSG_YELL", msgEventHandler);
end

function msgExists(content, sender, channel)
  for i=1,#msgQueue do
    local msg = msgQueue[i]
    local _msg = msg.msg
    if msg.time >= GetTime() - 1 and msg.msg == content and msg.sender == sender and 
        (msg.channel == channel or channel == "any" or
            (msg.channel == "raid" or msg.channel == "party") and channel == "group") then
      return true
    end
  end

  return false
end

function LFGDUMP()
  print(GetRecommendationTarget())
end

function frame:OnEvent(event, arg)
  if event == "ADDON_LOADED" and arg == "LifaGuardian" then
    self:UnregisterEvent("ADDON_LOADED")

    if LF_Guardian_GroupOnly == nil then
      LF_Guardian_GroupOnly = true
    end

    if LF_Guardian_WatchParty == nil then
      LF_Guardian_WatchParty = {}
    end

    if LF_Guardian_WatchRaid == nil then
      LF_Guardian_WatchRaid = {}
    end

    if LF_Guardian_Profile == nil then
      LF_Guardian_Profile = defaultProfile
    end

    UpdateProfileUI()

    InitializeTargetButtons()
    InitializeGroupOnlyCheckButton()
    InitializePartyCheckButtons()
    InitializeRaidCheckButtons()

    GetNextRecomendationTarget()
    GetNextRecomendationAction()
  end

  if event == "GROUP_ROSTER_UPDATE" then
    C_Timer.After(1, UpdateGroup)
  end

  if event == "PLAYER_TARGET_CHANGED" then
    lastChangeTargetTime = GetTime()
  end
end
frame:SetScript("OnEvent", frame.OnEvent)
msgEventRegister()
