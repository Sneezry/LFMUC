local _, LFA = ...

LFA.DB.Rules.DispelCurse = {
  spells = LFA.DB.Spells.dispelc,
  casting = {},
  channel = {},
  buff = {},
  debuff = {
    -- 奈萨鲁斯
    "巨龙宝藏诅咒"
  }
}