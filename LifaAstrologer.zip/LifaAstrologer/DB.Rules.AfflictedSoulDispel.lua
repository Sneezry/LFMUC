local _, LFA = ...

LFA.DB.Rules.AfflictedSoulDispel = {
  spells = LFA.DB.Spells.afflicatedsouldispel,
  template = "action,action.key=鼠标指向%s,instance.type=party|group.type=party,spell.%s=true,mouseover.name=受难之魂",
  name = {},
  casting = {},
  channel = {},
  buff = {},
  debuff = {},
  targetofspell = {}
}