local _, LFG = ...

LFG.RegisterUnitInfoHandler(
  function(key, info)
    return string.sub(key, 1, 13) == "spellinrange:"
  end,
  true,
  function(key, info)
    local spellName = string.sub(key, 14)
    info[key] = IsSpellInRange(spellName, info.unit) == 1
  end
)